import { useState } from "react";
import { PenLine, BookOpen, Sparkles, Plus, Save, ChevronLeft, Calendar, History, Star, Heart, Trophy } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { useNavigate } from "react-router";
import { useRewards } from "../RewardContext";

type JournalType = "sleep" | "nightmare" | "general";

export function Journal() {
  const navigate = useNavigate();
  const { addPoints, processJournalEntry } = useRewards();
  const [type, setType] = useState<JournalType>("sleep");
  const [text, setText] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [rating, setRating] = useState(0);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      
      // Analyze text for rewards
      processJournalEntry(text);
      
      // Points for just logging
      addPoints(10, "Daily Log Entry");
      
      if (type === "nightmare") {
        addPoints(15, "Imagery Rehearsal Bonus");
      }
      
      toast.success("Entry saved successfully");
      setText("");
      setRating(0);
    }, 1500);
  };

  return (
    <div className="flex flex-col gap-8 pb-12">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold text-foreground tracking-tight leading-none">Journal</h1>
        <p className="text-muted-foreground font-normal leading-relaxed">Reflect and process your thoughts.</p>
      </header>

      {/* Selector */}
      <div className="flex bg-card border border-border p-1.5 rounded-3xl">
        <JournalSelector 
          active={type === "sleep"} 
          onClick={() => setType("sleep")} 
          label="Sleep Log" 
          icon={<History className="w-4 h-4" />} 
        />
        <JournalSelector 
          active={type === "nightmare"} 
          onClick={() => setType("nightmare")} 
          label="Rewrite Dream" 
          icon={<Sparkles className="w-4 h-4" />} 
        />
        <JournalSelector 
          active={type === "general"} 
          onClick={() => setType("general")} 
          label="General" 
          icon={<PenLine className="w-4 h-4" />} 
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={type}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="flex flex-col gap-6"
        >
          {type === "sleep" && (
            <div className="flex flex-col gap-6 bg-card border border-border rounded-[2.5rem] p-8">
              <div className="flex items-center justify-between">
                <div className="flex flex-col gap-1">
                  <h3 className="text-xl font-semibold tracking-tight leading-none">How did you sleep?</h3>
                  <span className="text-xs text-muted-foreground font-normal leading-none uppercase tracking-widest italic">Today, Feb 21</span>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                  <Calendar className="w-6 h-6" />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider leading-none">Rating</span>
                <div className="flex gap-4 justify-between bg-background/50 border border-border/50 p-4 rounded-2xl">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      onClick={() => setRating(s)}
                      className={cn(
                        "text-3xl transition-transform hover:scale-125 active:scale-95",
                        rating >= s ? "text-primary drop-shadow-[0_0_10px_rgba(167,139,250,0.5)]" : "text-muted-foreground/30 grayscale"
                      )}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider leading-none">Notes</span>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Did you wake up during the night? How do you feel this morning?"
                  className="w-full h-40 bg-background border border-border rounded-2xl p-4 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all font-normal leading-relaxed resize-none"
                />
              </div>

              <button
                disabled={isSaving || !text}
                onClick={handleSave}
                className="w-full h-14 bg-primary text-primary-foreground font-semibold rounded-2xl flex items-center justify-center gap-2 transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? (
                  <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    <span>Save Log</span>
                  </>
                )}
              </button>
            </div>
          )}

          {type === "nightmare" && (
            <div className="flex flex-col gap-6 bg-card border border-border rounded-[2.5rem] p-8">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold tracking-tight leading-none italic">Imagery Rehearsal</h3>
                  <p className="text-xs text-muted-foreground font-normal leading-relaxed mt-1">Change the narrative of your dream.</p>
                </div>
              </div>

              <div className="flex flex-col gap-4 bg-background/50 border border-purple-500/20 p-5 rounded-2xl">
                <p className="text-sm font-medium text-foreground italic leading-relaxed">
                  "Write down the nightmare as you remember it, then change one small detail to make it feel safe."
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider leading-none">The Story</span>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Describe the dream and your new positive ending..."
                  className="w-full h-64 bg-background border border-border rounded-2xl p-4 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-purple-400/40 transition-all font-normal leading-relaxed resize-none"
                />
              </div>

              <button
                disabled={isSaving || !text}
                onClick={handleSave}
                className="w-full h-14 bg-purple-500 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 transition-all hover:bg-purple-600 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_20px_rgba(168,85,247,0.3)]"
              >
                {isSaving ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    <span>Save Revision</span>
                  </>
                )}
              </button>
            </div>
          )}

          {type === "general" && (
            <div className="flex flex-col gap-6 bg-card border border-border rounded-[2.5rem] p-8">
              <div className="flex items-center justify-between">
                <div className="flex flex-col gap-1">
                  <h3 className="text-xl font-semibold tracking-tight leading-none">What's on your mind?</h3>
                  <span className="text-xs text-muted-foreground font-normal leading-none uppercase tracking-widest italic">Clear your head</span>
                </div>
                <PenLine className="w-6 h-6 text-muted-foreground opacity-30" />
              </div>

              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Write whatever is bothering you or what you're grateful for..."
                className="w-full h-80 bg-background border border-border rounded-2xl p-4 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all font-normal leading-relaxed resize-none"
              />

              <div className="flex items-center justify-between bg-background/50 border border-border/50 p-4 rounded-2xl">
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm font-semibold tracking-tight leading-none">Keep Private</span>
                  <p className="text-xs text-muted-foreground font-normal leading-none italic">Local storage only</p>
                </div>
                <div className="w-6 h-6 rounded-full border border-primary flex items-center justify-center p-1">
                  <div className="w-full h-full bg-primary rounded-full" />
                </div>
              </div>

              <button
                disabled={isSaving || !text}
                onClick={handleSave}
                className="w-full h-14 bg-primary text-primary-foreground font-semibold rounded-2xl flex items-center justify-center gap-2 transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? (
                  <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    <span>Save Entry</span>
                  </>
                )}
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function JournalSelector({ active, onClick, label, icon }: { active: boolean; onClick: () => void; label: string; icon: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl transition-all font-semibold tracking-tight leading-none",
        active ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {icon}
      <span className="text-xs">{label}</span>
    </button>
  );
}
