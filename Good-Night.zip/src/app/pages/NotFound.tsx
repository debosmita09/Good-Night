import { useNavigate } from "react-router";
import { Home, Search } from "lucide-react";

export function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center gap-8">
      <div className="w-24 h-24 bg-primary/10 rounded-[2rem] flex items-center justify-center text-primary">
        <Search className="w-12 h-12" />
      </div>
      
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-black italic uppercase tracking-widest text-foreground">
          Page Not Found
        </h1>
        <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
          The page you're looking for doesn't exist.
        </p>
      </div>
      
      <button 
        onClick={() => navigate("/")}
        className="w-full max-w-xs h-16 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-3"
      >
        <Home className="w-5 h-5" />
        Return Home
      </button>
    </div>
  );
}
