import React, { useState, useRef } from "react";
import { User, Activity, Heart, Info, ChevronRight, Save, Plus, X, Stethoscope, Baby, Moon, Clock, ShieldCheck, ActivitySquare, AlertCircle, Sparkles, Phone, UserPlus, Trash2, Smartphone, Upload, FileText, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { useNavigate } from "react-router";

interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
}

export function HealthProfile() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({
    age: "28",
    lifestyle: "Sedentary / Office Work",
    screenTime: "8h+",
    activityLevel: "Low",
    conditions: ["Insomnia", "Anxiety"],
    medications: [
      { name: "Melatonin", time: "21:30", dose: "5mg" },
      { name: "Magnesium", time: "20:00", dose: "200mg" }
    ],
    appointments: [
      { title: "Sleep Clinic Follow-up", date: "2026-03-10", time: "10:30 AM", location: "City Health Center" }
    ],
    goal: "8 hours of deep sleep",
  });

  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([
    { id: "1", name: "Sarah Doe", relationship: "Sister", phone: "555-0123" }
  ]);

  const [isSaving, setIsSaving] = useState(false);

  // Upload states
  const [healthFiles, setHealthFiles] = useState<{ name: string; size: string; date: string }[]>(() => {
    const saved = localStorage.getItem("nightlight_health_files");
    return saved ? JSON.parse(saved) : [];
  });
  const [prescriptionFiles, setPrescriptionFiles] = useState<{ name: string; size: string; date: string }[]>(() => {
    const saved = localStorage.getItem("nightlight_prescription_files");
    return saved ? JSON.parse(saved) : [];
  });
  const [isHealthSyncing, setIsHealthSyncing] = useState(false);

  const healthFileRef = useRef<HTMLInputElement>(null);
  const prescriptionFileRef = useRef<HTMLInputElement>(null);

  const handleHealthFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const newFiles = Array.from(files).map(f => ({
      name: f.name,
      size: formatFileSize(f.size),
      date: new Date().toLocaleDateString(),
    }));
    const updated = [...healthFiles, ...newFiles];
    setHealthFiles(updated);
    localStorage.setItem("nightlight_health_files", JSON.stringify(updated));
    toast.success(`${newFiles.length} health file${newFiles.length > 1 ? "s" : ""} uploaded successfully`);
    e.target.value = "";
  };

  const handlePrescriptionUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const newFiles = Array.from(files).map(f => ({
      name: f.name,
      size: formatFileSize(f.size),
      date: new Date().toLocaleDateString(),
    }));
    const updated = [...prescriptionFiles, ...newFiles];
    setPrescriptionFiles(updated);
    localStorage.setItem("nightlight_prescription_files", JSON.stringify(updated));
    toast.success(`${newFiles.length} prescription${newFiles.length > 1 ? "s" : ""} uploaded successfully`);
    e.target.value = "";
  };

  const removeHealthFile = (index: number) => {
    const updated = healthFiles.filter((_, i) => i !== index);
    setHealthFiles(updated);
    localStorage.setItem("nightlight_health_files", JSON.stringify(updated));
    toast.error("Health file removed");
  };

  const removePrescriptionFile = (index: number) => {
    const updated = prescriptionFiles.filter((_, i) => i !== index);
    setPrescriptionFiles(updated);
    localStorage.setItem("nightlight_prescription_files", JSON.stringify(updated));
    toast.error("Prescription removed");
  };

  const simulateHealthSync = () => {
    setIsHealthSyncing(true);
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 2500)),
      {
        loading: "Syncing with Apple Health...",
        success: () => {
          setIsHealthSyncing(false);
          const mockSyncFile = {
            name: "Apple Health Export - " + new Date().toLocaleDateString(),
            size: "2.4 MB",
            date: new Date().toLocaleDateString(),
          };
          const updated = [...healthFiles, mockSyncFile];
          setHealthFiles(updated);
          localStorage.setItem("nightlight_health_files", JSON.stringify(updated));
          return "Apple Health data synced successfully!";
        },
        error: () => {
          setIsHealthSyncing(false);
          return "Sync failed. Please try again.";
        },
      }
    );
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      toast.success("Profile updated successfully");
      navigate("/");
    }, 1500);
  };

  const toggleCondition = (c: string) => {
    setProfile(prev => ({ 
      ...prev, 
      conditions: prev.conditions.includes(c) 
        ? prev.conditions.filter(item => item !== c) 
        : [...prev.conditions, c] 
    }));
  };

  const addEmergencyContact = () => {
    const newContact: EmergencyContact = {
      id: Date.now().toString(),
      name: "New Contact",
      relationship: "Family",
      phone: ""
    };
    setEmergencyContacts([...emergencyContacts, newContact]);
    toast.success("Added new contact placeholder");
  };

  const removeContact = (id: string) => {
    setEmergencyContacts(emergencyContacts.filter(c => c.id !== id));
    toast.error("Contact removed");
  };

  return (
    <div className="flex flex-col gap-8 pb-12 px-1">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Health Profile</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Calibrate your sleep AI experience.</p>
      </header>

      {/* Basic Info */}
      <section className="bg-card border-2 border-primary/20 rounded-[2.5rem] p-8 flex flex-col gap-8 relative overflow-hidden shadow-[0_0_50px_rgba(167,139,250,0.1)]">
        <div className="absolute top-0 right-0 p-6 opacity-5">
          <User className="w-20 h-20 text-primary fill-current" />
        </div>
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-14 h-14 bg-primary/10 rounded-[1.25rem] flex items-center justify-center text-primary shadow-[0_0_20px_rgba(167,139,250,0.2)]">
            <User className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Personal Info</h3>
        </div>

        <div className="grid grid-cols-1 gap-6 relative z-10">
          <ProfileField 
            label="Current Age" 
            value={profile.age} 
            onChange={(v) => setProfile(p => ({ ...p, age: v }))} 
            placeholder="e.g., 28"
          />
          <ProfileField 
            label="Work Lifestyle" 
            value={profile.lifestyle} 
            onChange={(v) => setProfile(p => ({ ...p, lifestyle: v }))} 
            placeholder="e.g., Active / Shift Work"
          />
        </div>
      </section>

      {/* Emergency Contacts */}
      <section className="bg-red-500/5 border-2 border-red-500/20 rounded-[2.5rem] p-8 flex flex-col gap-8 relative overflow-hidden">
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-red-500/10 rounded-[1.25rem] flex items-center justify-center text-red-500 shadow-sm">
              <Phone className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Emergency Contacts</h3>
          </div>
          <button 
            onClick={addEmergencyContact}
            className="w-10 h-10 bg-red-500 text-white rounded-xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 shadow-md"
          >
            <UserPlus className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col gap-4 relative z-10">
          <AnimatePresence>
            {emergencyContacts.map((contact) => (
              <motion.div 
                key={contact.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-card border border-red-500/10 p-5 rounded-3xl flex items-center justify-between group transition-all hover:border-red-500/30"
              >
                <div className="flex flex-col">
                  <span className="text-base font-bold italic tracking-tight">{contact.name}</span>
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-1 italic leading-none">{contact.relationship} • {contact.phone || "No phone added"}</p>
                </div>
                <button 
                  onClick={() => removeContact(contact.id)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/30 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          <div className="bg-red-500/5 border border-dashed border-red-500/20 p-5 rounded-2xl flex items-start gap-4 transition-all hover:bg-red-500/10">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <p className="text-[10px] text-red-700/60 font-bold uppercase tracking-widest leading-relaxed italic">
              These contacts will be notified automatically if you trigger the "SOS" function during a nightmare recovery.
            </p>
          </div>
        </div>
      </section>

      {/* Health Conditions */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-blue-500/10 rounded-[1.25rem] flex items-center justify-center text-blue-400">
            <ActivitySquare className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Health Status</h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <QuickToggle 
            icon={<Baby className="w-4 h-4" />} 
            label="Pregnancy" 
            active={profile.conditions.includes("Pregnancy")}
            onClick={() => toggleCondition("Pregnancy")}
          />
          <QuickToggle 
            icon={<Moon className="w-4 h-4" />} 
            label="Insomnia" 
            active={profile.conditions.includes("Insomnia")}
            onClick={() => toggleCondition("Insomnia")}
          />
          <QuickToggle 
            icon={<ActivitySquare className="w-4 h-4" />} 
            label="Anxiety" 
            active={profile.conditions.includes("Anxiety")}
            onClick={() => toggleCondition("Anxiety")}
          />
          <QuickToggle 
            icon={<Sparkles className="w-4 h-4" />} 
            label="Stress" 
            active={profile.conditions.includes("Stress")}
            onClick={() => toggleCondition("Stress")}
          />
        </div>
      </section>

      {/* Medications & Appointments */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-amber-500/10 rounded-[1.25rem] flex items-center justify-center text-amber-500">
            <Stethoscope className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Medical Management</h3>
        </div>

        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground italic px-1">Daily Medications</h4>
            {profile.medications.map((med, i) => (
              <div key={i} className="bg-background/40 border border-border/50 p-4 rounded-2xl flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-sm font-bold italic tracking-tight">{med.name} ({med.dose})</span>
                  <span className="text-[9px] text-primary font-bold uppercase tracking-widest italic mt-0.5">Time: {med.time}</span>
                </div>
                <div className="w-8 h-8 bg-amber-400/10 rounded-lg flex items-center justify-center text-amber-500">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground italic px-1">Upcoming Appointments</h4>
            {profile.appointments.map((app, i) => (
              <div key={i} className="bg-background/40 border border-border/50 p-4 rounded-2xl flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div className="flex flex-col gap-1 min-w-0">
                  <span className="text-sm font-bold italic tracking-tight truncate">{app.title}</span>
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest italic leading-none">{app.date} @ {app.time}</span>
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest italic leading-none opacity-60">{app.location}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Apple Health Data & Upload */}
      <section className="bg-card border-2 border-red-500/20 rounded-[2.5rem] p-8 flex flex-col gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-5">
          <Heart className="w-20 h-20 text-red-500 fill-current" />
        </div>
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-14 h-14 bg-red-500 rounded-[1.25rem] flex items-center justify-center text-white shadow-[0_10px_20px_rgba(239,68,68,0.3)]">
            <Heart className="w-8 h-8 fill-current" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Apple Health Data</h3>
            <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1.5 italic opacity-60">Sync or upload your health exports</p>
          </div>
        </div>

        <div className="flex flex-col gap-4 relative z-10">
          {/* Sync Button */}
          <button 
            onClick={simulateHealthSync}
            disabled={isHealthSyncing}
            className="w-full h-16 bg-red-500/10 border-2 border-dashed border-red-500/20 rounded-2xl flex items-center justify-center gap-3 transition-all hover:bg-red-500/15 active:scale-98 disabled:opacity-50 group"
          >
            {isHealthSyncing ? (
              <div className="w-5 h-5 border-2 border-red-500/30 border-t-red-500 rounded-full animate-spin" />
            ) : (
              <Heart className="w-5 h-5 text-red-500 fill-current group-hover:scale-110 transition-transform" />
            )}
            <span className="text-sm font-bold text-red-500 italic tracking-tight">
              {isHealthSyncing ? "Syncing..." : "Sync from Apple Health"}
            </span>
          </button>

          {/* Upload Button */}
          <input 
            ref={healthFileRef}
            type="file" 
            className="hidden" 
            accept=".xml,.zip,.json,.csv" 
            multiple
            onChange={handleHealthFileUpload}
          />
          <button 
            onClick={() => healthFileRef.current?.click()}
            className="w-full h-16 bg-background/40 border border-border/50 rounded-2xl flex items-center justify-center gap-3 transition-all hover:bg-background/60 active:scale-98 group"
          >
            <Upload className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            <span className="text-sm font-bold text-muted-foreground italic tracking-tight group-hover:text-foreground transition-colors">
              Upload Health Export File
            </span>
          </button>
          <p className="text-[9px] text-muted-foreground/60 font-bold uppercase tracking-widest italic px-1">
            Accepts .xml, .zip, .json, .csv from Apple Health, Samsung Health, Google Fit, etc.
          </p>

          {/* Uploaded Files */}
          <AnimatePresence>
            {healthFiles.map((file, index) => (
              <motion.div
                key={`health-${index}-${file.name}`}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-background/40 border border-green-500/20 p-4 rounded-2xl flex items-center justify-between"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 bg-green-500/10 rounded-lg flex items-center justify-center text-green-500 shrink-0">
                    <CheckCircle className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold italic tracking-tight truncate">{file.name}</span>
                    <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest italic leading-none mt-0.5">{file.size} • {file.date}</span>
                  </div>
                </div>
                <button 
                  onClick={() => removeHealthFile(index)}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground/30 hover:text-red-500 transition-colors shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </section>

      {/* Prescriptions Upload */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-6 opacity-5">
          <FileText className="w-20 h-20 text-primary fill-current" />
        </div>
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-14 h-14 bg-primary/10 rounded-[1.25rem] flex items-center justify-center text-primary shadow-sm">
            <FileText className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Prescriptions</h3>
            <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1.5 italic opacity-60">Upload medication & treatment docs</p>
          </div>
        </div>

        <div className="flex flex-col gap-4 relative z-10">
          <input 
            ref={prescriptionFileRef}
            type="file" 
            className="hidden" 
            accept=".pdf,.jpg,.jpeg,.png,.heic,.doc,.docx" 
            multiple
            onChange={handlePrescriptionUpload}
          />
          <button 
            onClick={() => prescriptionFileRef.current?.click()}
            className="w-full h-20 bg-primary/5 border-2 border-dashed border-primary/20 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all hover:bg-primary/10 active:scale-98 group"
          >
            <Upload className="w-6 h-6 text-primary/60 group-hover:text-primary transition-colors group-hover:scale-110" />
            <span className="text-xs font-bold text-primary/60 italic tracking-tight group-hover:text-primary transition-colors">
              Tap to upload prescriptions
            </span>
          </button>
          <p className="text-[9px] text-muted-foreground/60 font-bold uppercase tracking-widest italic px-1">
            Accepts PDF, images (JPG, PNG, HEIC), and documents. Photos of prescriptions work too.
          </p>

          {/* Uploaded Prescriptions */}
          <AnimatePresence>
            {prescriptionFiles.map((file, index) => (
              <motion.div
                key={`rx-${index}-${file.name}`}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-background/40 border border-primary/20 p-4 rounded-2xl flex items-center justify-between"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-primary shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold italic tracking-tight truncate">{file.name}</span>
                    <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest italic leading-none mt-0.5">{file.size} • {file.date}</span>
                  </div>
                </div>
                <button 
                  onClick={() => removePrescriptionFile(index)}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground/30 hover:text-red-500 transition-colors shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>

          {prescriptionFiles.length === 0 && (
            <div className="bg-primary/5 border border-primary/10 p-4 rounded-2xl flex items-start gap-3">
              <Info className="w-4 h-4 text-primary/40 shrink-0 mt-0.5" />
              <p className="text-[10px] text-muted-foreground/60 font-bold italic leading-relaxed">
                Uploading prescriptions helps Nightlight remind you about medication times and potential sleep interactions. Your files stay on your device.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Save Button */}
      <button
        onClick={handleSave}
        disabled={isSaving}
        className="w-full h-18 bg-primary text-primary-foreground font-black rounded-[2rem] flex items-center justify-center gap-3 transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 shadow-[0_10px_30px_rgba(167,139,250,0.3)]"
      >
        {isSaving ? (
          <div className="w-6 h-6 border-3 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
        ) : (
          <>
            <Save className="w-6 h-6" />
            <span className="uppercase tracking-widest italic">Save Profile</span>
          </>
        )}
      </button>
    </div>
  );
}

function ProfileField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="flex flex-col gap-3">
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest leading-none px-1 italic">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-16 bg-background border border-border rounded-[1.5rem] px-6 text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all font-bold italic tracking-tight"
      />
    </div>
  );
}

function QuickToggle({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "h-14 flex items-center gap-3 px-5 rounded-[1.25rem] border transition-all active:scale-95 text-left group",
        active ? "bg-red-500/10 border-red-500/30 text-red-400 shadow-inner" : "bg-background/50 border-border text-muted-foreground hover:bg-border/20"
      )}
    >
      <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:rotate-6", active ? "bg-red-500/20" : "bg-muted/50")}>
        {icon}
      </div>
      <span className="text-[10px] font-bold tracking-widest leading-none uppercase italic">{label}</span>
    </button>
  );
}

function formatFileSize(size: number): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i++;
  }
  return size.toFixed(1) + ' ' + units[i];
}