import { useState, useEffect, useRef, useCallback } from "react";
import { Moon, Star, Music, X, Play, Pause, Volume2, Heart, Sparkles, Cloud, Sun, Tv, BookOpen } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

// Helper function to shuffle an array
function shuffleArray<T>(array: T[]): T[] {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

const cuteImages = [
  {
    id: "kitten",
    src: "https://images.unsplash.com/photo-1761124287188-cb537c75c8b1?auto=format&fit=crop&q=80&w=500",
    label: "Sleepy Kitten",
    emoji: "🐱",
  },
  {
    id: "puppy",
    src: "https://images.unsplash.com/photo-1599853654456-30790cacf322?auto=format&fit=crop&q=80&w=500",
    label: "Cozy Puppy",
    emoji: "🐶",
  },
  {
    id: "teddy",
    src: "https://images.unsplash.com/photo-1761891949914-0e5c70cb6bc4?auto=format&fit=crop&q=80&w=500",
    label: "Teddy Dreams",
    emoji: "🧸",
  },
  {
    id: "baby",
    src: "https://images.unsplash.com/photo-1542387960-f8197d82db42?auto=format&fit=crop&q=80&w=500",
    label: "Sweet Baby",
    emoji: "👶",
  },
  {
    id: "clouds",
    src: "https://images.unsplash.com/photo-1761166478784-dc565cffb472?auto=format&fit=crop&q=80&w=500",
    label: "Dreamy Clouds",
    emoji: "☁️",
  },
  {
    id: "stars",
    src: "https://images.unsplash.com/photo-1769038856816-929ab03648bc?auto=format&fit=crop&q=80&w=500",
    label: "Starry Night",
    emoji: "✨",
  },
];

export function KidsMode() {
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeContent, setActiveContent] = useState<"music" | "visuals" | "video">("music");
  const [exitProgress, setExitProgress] = useState(0);
  const exitTimer = useRef<NodeJS.Timeout | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  // Shuffled images state
  const [shuffledImages, setShuffledImages] = useState(() => shuffleArray([...cuteImages]));

  const reshuffleImages = useCallback(() => {
    setShuffledImages(prev => {
      const newOrder = shuffleArray([...prev]);
      // Ensure at least one position changed
      if (newOrder.every((img, i) => img.id === prev[i].id)) {
        // Swap first two if shuffle returned same order
        [newOrder[0], newOrder[1]] = [newOrder[1], newOrder[0]];
      }
      return newOrder;
    });
  }, []);

  // Auto-shuffle every 30 seconds when on the visuals tab
  useEffect(() => {
    if (activeContent !== "visuals") return;
    const interval = setInterval(reshuffleImages, 30000);
    return () => clearInterval(interval);
  }, [activeContent, reshuffleImages]);

  const [currentTheme, setCurrentTheme] = useState<string>("deep-navy");

  useEffect(() => {
    const theme = document.body.className || "deep-navy";
    setCurrentTheme(theme);
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === "class") {
          setCurrentTheme(document.body.className || "deep-navy");
        }
      });
    });
    observer.observe(document.body, { attributes: true });
    return () => observer.disconnect();
  }, []);

  const lullabies = [
    { id: "1", title: "Twinkle Twinkle", type: "Popular Lullaby", emoji: "⭐" },
    { id: "2", title: "Brahms' Lullaby", type: "Classic Sleep", emoji: "🎵" },
    { id: "3", title: "Rock-a-bye Baby", type: "Traditional", emoji: "🌙" },
    { id: "4", title: "Hush Little Baby", type: "Soft Vocal", emoji: "💤" }
  ];

  const babyVideos = [
    { id: "v1", title: "Sleeping Animals", duration: "10:00", thumbnail: "https://images.unsplash.com/photo-1761124287188-cb537c75c8b1?auto=format&fit=crop&q=80&w=500", emoji: "🦊" },
    { id: "v2", title: "Galaxy Dream", duration: "15:00", thumbnail: "https://images.unsplash.com/photo-1769038856816-929ab03648bc?auto=format&fit=crop&q=80&w=500", emoji: "🌌" },
    { id: "v3", title: "Teddy's Night", duration: "12:30", thumbnail: "https://images.unsplash.com/photo-1761891949914-0e5c70cb6bc4?auto=format&fit=crop&q=80&w=500", emoji: "🧸" }
  ];

  const handleExitStart = () => {
    const start = Date.now();
    exitTimer.current = setInterval(() => {
      const elapsed = Date.now() - start;
      const progress = Math.min((elapsed / 2000) * 100, 100);
      setExitProgress(progress);
      if (progress >= 100) {
        clearInterval(exitTimer.current!);
        navigate("/");
      }
    }, 50);
  };

  const handleExitEnd = () => {
    if (exitTimer.current) clearInterval(exitTimer.current);
    setExitProgress(0);
  };

  const getThemeStyles = () => {
    switch(currentTheme) {
      case "soft-lavender":
        return {
          bg: "bg-[#F3F0FF]",
          text: "text-[#4C1D95]",
          card: "bg-white/80 border-purple-200/60",
          accent: "text-purple-400",
          floating: "opacity-40",
          cardBg: "bg-white",
        };
      case "charcoal":
        return {
          bg: "bg-[#F0F5F0]",
          text: "text-[#2D3B2D]",
          card: "bg-white/80 border-green-200/60",
          accent: "text-green-500",
          floating: "opacity-30",
          cardBg: "bg-white",
        };
      default:
        return {
          bg: "bg-[#0A0C16]",
          text: "text-white",
          card: "bg-white/5 border-white/10",
          accent: "text-primary",
          floating: "opacity-20",
          cardBg: "bg-white/5",
        };
    }
  };

  const styles = getThemeStyles();

  return (
    <div className={cn("fixed inset-0 z-[200] overflow-y-auto flex flex-col items-center p-6 select-none transition-colors duration-700", styles.bg, styles.text)}>
      {/* Floating background sparkles */}
      <div className={cn("absolute inset-0 overflow-hidden pointer-events-none transition-opacity duration-700", styles.floating)}>
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: `${Math.random() * 100}%`, 
              y: `${Math.random() * 100}%`,
              opacity: 0 
            }}
            animate={{ 
              x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              opacity: [0, 0.8, 0],
              scale: [0.5, 1.2, 0.5]
            }}
            transition={{ 
              duration: 15 + Math.random() * 10, 
              repeat: Infinity, 
              delay: i * 1.5,
              ease: "easeInOut" 
            }}
            className="absolute"
          >
            {i % 3 === 0 ? (
              <Star className="w-6 h-6 text-yellow-300 fill-current" />
            ) : i % 3 === 1 ? (
              <Heart className="w-5 h-5 text-pink-300 fill-current" />
            ) : (
              <Moon className="w-5 h-5 text-purple-300 fill-current" />
            )}
          </motion.div>
        ))}
      </div>

      {/* Header */}
      <header className="w-full max-w-md flex justify-between items-center pt-6 pb-4 relative z-10">
        <div className="flex items-center gap-3">
          <motion.div 
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="w-12 h-12 bg-pink-400/20 rounded-2xl flex items-center justify-center text-pink-400 shadow-sm border border-pink-400/20"
          >
            <Heart className="w-6 h-6 fill-current" />
          </motion.div>
          <div>
            <h1 className="text-xl font-black tracking-tight leading-none italic uppercase">Sleepy Baby</h1>
            <p className="text-[9px] opacity-60 font-black uppercase tracking-widest mt-1 italic">Gentle Dreams Only</p>
          </div>
        </div>

        <div className="relative">
          <button 
            onMouseDown={handleExitStart}
            onMouseUp={handleExitEnd}
            onTouchStart={handleExitStart}
            onTouchEnd={handleExitEnd}
            className={cn(
              "w-12 h-12 backdrop-blur-md rounded-2xl flex items-center justify-center border transition-all hover:scale-110 active:scale-95 overflow-hidden",
              styles.card
            )}
          >
            <div 
              className="absolute bottom-0 left-0 right-0 bg-red-400/40 transition-all duration-100" 
              style={{ height: `${exitProgress}%` }}
            />
            <X className="w-5 h-5 relative z-10" />
          </button>
          <div className="absolute top-full mt-1 left-1/2 -translate-x-1/2 whitespace-nowrap">
             <span className="text-[7px] font-black uppercase tracking-widest italic text-red-400/60">Hold</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-md flex flex-col gap-6 relative z-10 pb-32">
        <AnimatePresence mode="wait">
          {activeContent === "music" && (
            <motion.div 
              key="music"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              {/* Now Playing Visual */}
              <div className="relative flex flex-col items-center gap-4">
                <motion.div 
                  animate={{ scale: [1, 1.03, 1] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="w-full aspect-[16/9] rounded-3xl overflow-hidden relative border-2 border-pink-300/20 shadow-lg"
                >
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1761124287188-cb537c75c8b1?auto=format&fit=crop&q=80&w=600" 
                    className="w-full h-full object-cover"
                    alt="Sleeping kitten"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                    <div>
                      <p className="text-white text-xs font-black uppercase tracking-widest italic">Now Playing</p>
                      <p className="text-white/60 text-[9px] font-bold uppercase tracking-widest italic mt-1">Sweet Lullabies</p>
                    </div>
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <Music className="w-8 h-8 text-pink-300" />
                    </motion.div>
                  </div>
                </motion.div>

                <div className="absolute -top-2 -right-2 bg-yellow-400 text-black px-3 py-1.5 rounded-2xl text-[8px] font-black uppercase tracking-widest italic shadow-lg animate-bounce">
                  Sweet Melodies
                </div>
              </div>

              {/* Lullaby Grid - Rectangular Cards */}
              <div className="grid grid-cols-2 gap-3">
                {lullabies.map((track) => (
                  <motion.button
                    key={track.id}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => {
                      setIsPlaying(true);
                      toast.success(`Playing ${track.title} for Baby`);
                    }}
                    className={cn(
                      "p-4 rounded-2xl flex flex-col gap-2 text-left transition-all border relative overflow-hidden",
                      styles.card
                    )}
                  >
                    <span className="text-2xl">{track.emoji}</span>
                    <span className="text-xs font-black italic tracking-tight">{track.title}</span>
                    <span className="text-[8px] font-bold opacity-50 uppercase tracking-widest italic">{track.type}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {activeContent === "visuals" && (
            <motion.div 
              key="visuals"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              <div className="flex flex-col gap-2 px-1">
                <h2 className="text-lg font-black italic uppercase tracking-widest">Dreamy Gallery</h2>
                <p className="text-[9px] opacity-50 font-bold uppercase tracking-widest italic">Tap a picture for calming full-screen view</p>
              </div>

              {/* Cute Image Grid - Rectangular Cards */}
              <div className="grid grid-cols-2 gap-3">
                {shuffledImages.map((img) => (
                  <motion.button
                    key={img.id}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setSelectedImage(img.id)}
                    className="relative rounded-2xl overflow-hidden aspect-[4/3] border-2 border-pink-200/20 shadow-md group"
                  >
                    <ImageWithFallback 
                      src={img.src} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      alt={img.label}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute bottom-2 left-2 right-2 flex items-center gap-1.5">
                      <span className="text-base">{img.emoji}</span>
                      <span className="text-white text-[9px] font-black uppercase tracking-widest italic">{img.label}</span>
                    </div>
                    {/* Sparkle decoration */}
                    <div className="absolute top-2 right-2">
                      <Sparkles className="w-4 h-4 text-yellow-300/60" />
                    </div>
                  </motion.button>
                ))}
              </div>

              {/* Ambient visual */}
              <motion.div 
                animate={{ 
                  y: [0, -10, 0],
                  scale: [1, 1.05, 1],
                }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="w-full aspect-[16/9] rounded-3xl overflow-hidden relative border-2 border-blue-300/20 shadow-lg"
              >
                <ImageWithFallback 
                  src="https://images.unsplash.com/photo-1765645651302-81867f707532?auto=format&fit=crop&q=80&w=600" 
                  className="w-full h-full object-cover"
                  alt="Calm ocean"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent flex items-end p-4">
                  <div className="flex items-center gap-2">
                    <Cloud className="w-5 h-5 text-white/60 fill-current" />
                    <p className="text-white text-[9px] font-black uppercase tracking-widest italic">Soft Colors for Tiny Eyes</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}

          {activeContent === "video" && (
            <motion.div 
              key="video"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              <div className="flex flex-col gap-2 px-1">
                <h2 className="text-lg font-black italic uppercase tracking-widest">Sleepy TV</h2>
                <p className="text-[9px] opacity-50 font-bold uppercase tracking-widest italic">Curated Bedtime Videos</p>
              </div>
              
              <div className="flex flex-col gap-4">
                {babyVideos.map((video) => (
                  <motion.button 
                    key={video.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => toast.info(`Starting ${video.title}...`)}
                    className="w-full rounded-2xl overflow-hidden relative border-2 border-white/10 shadow-lg group"
                  >
                    <div className="aspect-[16/9] relative">
                      <ImageWithFallback src={video.thumbnail} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={video.title} />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <motion.div
                          whileHover={{ scale: 1.1 }}
                          className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30"
                        >
                          <Play className="w-6 h-6 text-white fill-current ml-0.5" />
                        </motion.div>
                      </div>
                      <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{video.emoji}</span>
                          <div>
                            <span className="text-white font-black text-xs italic uppercase tracking-widest block">{video.title}</span>
                            <span className="text-white/50 text-[8px] font-bold uppercase tracking-widest italic">{video.duration}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Full Screen Image Viewer */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/90 flex items-center justify-center p-6"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="w-full max-w-md rounded-3xl overflow-hidden relative"
            >
              <ImageWithFallback
                src={cuteImages.find(i => i.id === selectedImage)?.src || ""}
                className="w-full aspect-[4/3] object-cover"
                alt="Full screen view"
              />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div className="bg-black/40 backdrop-blur-sm px-4 py-2 rounded-2xl">
                  <span className="text-white text-xs font-black uppercase tracking-widest italic">
                    {cuteImages.find(i => i.id === selectedImage)?.emoji} {cuteImages.find(i => i.id === selectedImage)?.label}
                  </span>
                </div>
                <button 
                  className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center"
                  onClick={() => setSelectedImage(null)}
                >
                  <X className="w-5 h-5 text-white" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tab Switcher */}
      <nav className="fixed bottom-0 left-0 right-0 px-6 pb-8 pt-4 z-10 bg-gradient-to-t from-black/30 via-black/10 to-transparent">
        <div className="max-w-md mx-auto flex justify-center gap-4">
          <KidsTab 
            active={activeContent === "music"} 
            icon={<Music className="w-6 h-6" />} 
            label="Lullabies" 
            onClick={() => setActiveContent("music")}
            color="text-pink-400"
            emoji="🎵"
            styles={styles}
          />
          <KidsTab 
            active={activeContent === "visuals"} 
            icon={<Heart className="w-6 h-6" />} 
            label="Gallery" 
            onClick={() => setActiveContent("visuals")}
            color="text-blue-400"
            emoji="🖼️"
            styles={styles}
          />
          <KidsTab 
            active={activeContent === "video"} 
            icon={<Tv className="w-6 h-6" />} 
            label="Sleepy TV" 
            onClick={() => setActiveContent("video")}
            color="text-yellow-400"
            emoji="📺"
            styles={styles}
          />
        </div>
      </nav>
    </div>
  );
}

function KidsTab({ active, icon, label, onClick, color, emoji, styles }: { active: boolean; icon: React.ReactNode; label: string; onClick: () => void; color: string; emoji: string; styles: any }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-2 transition-all duration-500",
        active ? "scale-110 " + color : "opacity-40 hover:opacity-70"
      )}
    >
      <motion.div 
        animate={active ? { y: [0, -3, 0] } : {}}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        className={cn(
          "w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg border",
          active ? "bg-white/15 border-current" : styles.card
        )}
      >
        <span className="text-xl">{emoji}</span>
      </motion.div>
      <span className="text-[8px] font-black uppercase tracking-widest italic">{label}</span>
    </button>
  );
}