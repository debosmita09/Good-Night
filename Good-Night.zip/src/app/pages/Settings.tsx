import { useState } from "react";
import { Settings as SettingsIcon, Moon, Sun, Smartphone, Bell, ShieldCheck, User, LogOut, ChevronRight, Palette, Lock, Eye, Trash2, Heart, Sparkles, Zap, SmartphoneNfc, Ban, Leaf, Activity, Mic, MapPin, Pencil, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import * as Switch from "@radix-ui/react-switch";
import { useNavigate } from "react-router";

export function Settings() {
  const navigate = useNavigate();
  const [theme, setTheme] = useState<"deep-navy" | "soft-lavender" | "charcoal" | "baby-blue" | "light-pink">("deep-navy");
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true);
  const [isPrivacyEnabled, setIsPrivacyEnabled] = useState(false);
  const [showPrivacyReview, setShowPrivacyReview] = useState(false);

  // Display name state
  const [displayName, setDisplayName] = useState(() => {
    return localStorage.getItem("nightlight_display_name") || "";
  });
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(displayName);

  const handleSaveName = () => {
    const trimmed = nameInput.trim();
    setDisplayName(trimmed);
    if (trimmed) {
      localStorage.setItem("nightlight_display_name", trimmed);
    } else {
      localStorage.removeItem("nightlight_display_name");
    }
    setIsEditingName(false);
    toast.success(trimmed ? `Display name updated to "${trimmed}"` : "Display name cleared");
  };

  // Load saved permissions
  const [savedPermissions, setSavedPermissions] = useState(() => {
    const saved = localStorage.getItem("nightlight_permissions");
    return saved ? JSON.parse(saved) : { tracking: false, health: false, microphone: false, notifications: false, location: false };
  });

  // App Lock state
  const [lockedApps, setLockedApps] = useState<string[]>(() => {
    const saved = localStorage.getItem("nightlight_locked_apps");
    return saved ? JSON.parse(saved) : [];
  });
  const [showAppLock, setShowAppLock] = useState(false);
  const [showUnlockWarning, setShowUnlockWarning] = useState<string | null>(null);

  const socialApps = [
    { id: "instagram", name: "Instagram", icon: "📸", color: "bg-pink-500/10 text-pink-500" },
    { id: "tiktok", name: "TikTok", icon: "🎵", color: "bg-cyan-500/10 text-cyan-500" },
    { id: "twitter", name: "X (Twitter)", icon: "🐦", color: "bg-blue-500/10 text-blue-500" },
    { id: "snapchat", name: "Snapchat", icon: "👻", color: "bg-yellow-500/10 text-yellow-500" },
    { id: "facebook", name: "Facebook", icon: "📘", color: "bg-blue-600/10 text-blue-600" },
    { id: "reddit", name: "Reddit", icon: "🔶", color: "bg-orange-500/10 text-orange-500" },
    { id: "youtube", name: "YouTube", icon: "▶️", color: "bg-red-500/10 text-red-500" },
  ];

  const handleToggleAppLock = (appId: string) => {
    if (lockedApps.includes(appId)) {
      setShowUnlockWarning(appId);
    } else {
      const newLocked = [...lockedApps, appId];
      setLockedApps(newLocked);
      localStorage.setItem("nightlight_locked_apps", JSON.stringify(newLocked));
      toast.success(`${socialApps.find(a => a.id === appId)?.name} locked for better sleep!`);
    }
  };

  const confirmUnlock = (appId: string) => {
    const newLocked = lockedApps.filter(id => id !== appId);
    setLockedApps(newLocked);
    localStorage.setItem("nightlight_locked_apps", JSON.stringify(newLocked));
    setShowUnlockWarning(null);
    toast.warning("App unlocked. Remember: screen time before bed hurts sleep quality.");
  };

  const themes = [
    { id: "deep-navy", name: "Deep Navy", bg: "bg-[#0F1220]", text: "text-white", border: "border-[#1A1E33]" },
    { id: "soft-lavender", name: "Soft Lavender", bg: "bg-[#F3F0FF]", text: "text-[#4C1D95]", border: "border-[#DDD6FE]" },
    { id: "charcoal", name: "Light Sage", bg: "bg-[#F0F5F0]", text: "text-[#2D3B2D]", border: "border-[#D4E5D4]" },
    { id: "baby-blue", name: "Baby Blue", bg: "bg-[#EBF4FA]", text: "text-[#1E3A5F]", border: "border-[#B8D8F0]" },
    { id: "light-pink", name: "Light Pink", bg: "bg-[#FDF0F4]", text: "text-[#5C1A33]", border: "border-[#F0C0D0]" },
  ];

  const handleUpdateTheme = (id: any) => {
    setTheme(id);
    toast.success(`Theme updated to ${id.replace('-', ' ')}`);
    // Logic to change CSS variables or body classes
    document.body.className = id;
  };

  const handleLogout = () => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1500)),
      {
        loading: "Logging out...",
        success: "See you later, sleep well! 🌙",
        error: "Logout failed",
      }
    );
  };

  return (
    <div className="flex flex-col gap-8 pb-12 px-1">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Settings & Customize</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Make the experience yours.</p>
      </header>

      {/* Theme Customization */}
      <section className="bg-card border border-border rounded-[2.5rem] p-6 flex flex-col gap-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shadow-sm">
            <Palette className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold tracking-tight leading-none italic uppercase tracking-widest">Appearance</h3>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {themes.map((t) => (
            <button
              key={t.id}
              onClick={() => handleUpdateTheme(t.id)}
              className={cn(
                "h-14 rounded-2xl border-2 flex items-center justify-between px-4 transition-all active:scale-95 group",
                theme === t.id ? "border-primary bg-primary/5" : "border-border hover:border-border/60"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn("w-8 h-8 rounded-lg border border-white/10 shadow-sm transition-transform group-hover:rotate-6", t.bg)} />
                <span className="font-bold tracking-tight leading-none italic text-sm uppercase tracking-widest">{t.name}</span>
              </div>
              <div className={cn(
                "w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all",
                theme === t.id ? "border-primary bg-primary" : "border-border"
              )}>
                {theme === t.id && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* System Preferences */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-secondary/10 rounded-[1.25rem] flex items-center justify-center text-secondary shadow-sm">
            <Smartphone className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">System</h3>
        </div>

        <div className="flex flex-col gap-4">
          <PreferenceToggle 
            icon={<Bell className="w-5 h-5" />}
            label="Push Notifications"
            description="Reminders to wind down and log sleep"
            checked={isNotificationsEnabled}
            onCheckedChange={setIsNotificationsEnabled}
          />
          <PreferenceToggle 
            icon={<Lock className="w-5 h-5" />}
            label="Privacy Lock"
            description="Require FaceID/TouchID to enter app"
            checked={isPrivacyEnabled}
            onCheckedChange={setIsPrivacyEnabled}
          />
        </div>
      </section>

      {/* Account & Safety */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-red-500/10 rounded-[1.25rem] flex items-center justify-center text-red-500 shadow-sm">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">Account & Data</h3>
        </div>

        {/* Display Name Editor */}
        <div className="bg-background/40 border border-border/50 p-5 rounded-3xl">
          <div className="flex items-center justify-between mb-2">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">Display Name</label>
            {!isEditingName && (
              <button
                onClick={() => { setNameInput(displayName); setIsEditingName(true); }}
                className="text-primary hover:text-primary/80 transition-colors"
              >
                <Pencil className="w-4 h-4" />
              </button>
            )}
          </div>
          {isEditingName ? (
            <div className="flex gap-2">
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="Enter your name..."
                autoFocus
                onKeyDown={(e) => { if (e.key === "Enter") handleSaveName(); }}
                className="flex-1 h-12 bg-card border border-border rounded-2xl px-4 text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all text-sm"
              />
              <button
                onClick={handleSaveName}
                className="h-12 w-12 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-sm"
              >
                <Check className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <p className="text-base font-bold italic tracking-tight text-foreground">
              {displayName || <span className="text-muted-foreground/50 italic">No name set — tap edit to add one</span>}
            </p>
          )}
        </div>

        <div className="flex flex-col gap-3">
          <SettingsLink 
            icon={<User className="w-5 h-5" />}
            label="Edit Health Profile"
            onClick={() => navigate("/health-profile")}
          />
          <SettingsLink 
            icon={<ShieldCheck className="w-5 h-5" />}
            label="Privacy & Permissions"
            onClick={() => setShowPrivacyReview(true)}
          />
          <SettingsLink 
            icon={<Heart className="w-5 h-5" />}
            label="Emergency Family Alert"
            onClick={() => navigate("/health-profile")}
          />
          <SettingsLink 
            icon={<Trash2 className="w-5 h-5" />}
            label="Clear Data"
            onClick={() => toast.error("This will permanently delete all logs. Are you sure?")}
            color="text-red-400"
          />
        </div>

        <button 
          onClick={handleLogout}
          className="w-full h-16 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl flex items-center justify-center gap-3 transition-all hover:bg-red-500/20 active:scale-95 font-black uppercase tracking-widest italic"
        >
          <LogOut className="w-6 h-6" />
          Logout
        </button>
      </section>

      {/* App Lock */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-8">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-blue-500/10 rounded-[1.25rem] flex items-center justify-center text-blue-500 shadow-sm">
            <Lock className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">App Lock</h3>
        </div>

        <div className="flex flex-col gap-3">
          {socialApps.map(app => (
            <div key={app.id} className="flex items-center justify-between p-5 bg-background/20 rounded-2xl border border-border transition-all hover:bg-background/40 active:scale-98 group">
              <div className="flex items-center gap-4">
                <div className={cn("w-10 h-10 bg-muted rounded-xl flex items-center justify-center", app.color)}>
                  {app.icon}
                </div>
                <span className="text-sm font-bold tracking-tight italic uppercase tracking-widest">{app.name}</span>
              </div>
              <Switch.Root
                checked={lockedApps.includes(app.id)}
                onCheckedChange={() => handleToggleAppLock(app.id)}
                className="w-12 h-7 bg-border/40 rounded-full relative shadow-inner focus:outline-none data-[state=checked]:bg-primary transition-colors"
              >
                <Switch.Thumb className="block w-5 h-5 bg-white rounded-full transition-transform duration-200 translate-x-1 will-change-transform data-[state=checked]:translate-x-6 shadow-md" />
              </Switch.Root>
            </div>
          ))}
        </div>

        {showUnlockWarning && (
          <AnimatePresence>
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-card border-2 border-amber-500/20 p-8 rounded-[2.5rem] shadow-2xl max-w-sm w-full flex flex-col items-center text-center gap-5"
              >
                <div className="w-14 h-14 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 shadow-sm">
                  <Ban className="w-7 h-7" />
                </div>
                <div className="flex flex-col gap-2">
                  <h3 className="text-xl font-black italic tracking-tight uppercase tracking-widest">Unlock Warning</h3>
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest leading-relaxed italic opacity-80">
                    Unlocking {socialApps.find(a => a.id === showUnlockWarning)?.name} may disrupt your sleep routine. Screen time before bed reduces melatonin production.
                  </p>
                </div>
                <div className="bg-red-500/10 border border-red-500/20 p-3 rounded-xl">
                  <p className="text-[10px] text-red-400 font-bold uppercase tracking-widest italic">
                    Studies show 30+ min of social media before bed delays sleep onset by 20-45 minutes.
                  </p>
                </div>
                <div className="flex flex-col gap-3 w-full">
                  <button 
                    onClick={() => confirmUnlock(showUnlockWarning)}
                    className="w-full h-12 bg-amber-500/20 text-amber-500 border border-amber-500/30 font-black rounded-2xl flex items-center justify-center gap-2 transition-all hover:bg-amber-500/30 active:scale-95 uppercase tracking-widest italic text-xs"
                  >
                    <Ban className="w-4 h-4" />
                    Unlock Anyway
                  </button>
                  <button 
                    onClick={() => setShowUnlockWarning(null)}
                    className="w-full h-12 bg-primary text-primary-foreground font-black rounded-2xl flex items-center justify-center transition-all active:scale-95 uppercase tracking-widest italic text-xs"
                  >
                    Keep Locked
                  </button>
                </div>
              </motion.div>
            </div>
          </AnimatePresence>
        )}
      </section>

      <div className="text-center pb-8 flex flex-col gap-1">
        <p className="text-[10px] text-muted-foreground font-black uppercase tracking-widest italic">Nightlight v2.1.0</p>
        <p className="text-[10px] text-muted-foreground/40 font-bold uppercase tracking-widest italic">Made with 💜 for better rest.</p>
      </div>

      {/* Privacy & Permissions Review Modal */}
      <AnimatePresence>
        {showPrivacyReview && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-card border border-border p-6 rounded-[2.5rem] shadow-2xl max-w-sm w-full flex flex-col gap-5 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-black italic uppercase tracking-widest">Privacy</h3>
                </div>
                <button
                  onClick={() => setShowPrivacyReview(false)}
                  className="w-8 h-8 bg-muted rounded-xl flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Ban className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-primary/10 border border-primary/20 p-4 rounded-2xl">
                <p className="text-xs text-muted-foreground italic leading-relaxed">
                  Nightlight never sells your data. Your sleep logs and health info stay on your device unless you choose to sync.
                </p>
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">Tracking</p>
                <div className={`p-3 rounded-xl border ${!savedPermissions.tracking ? "border-primary/30 bg-primary/5" : "border-amber-500/30 bg-amber-500/5"}`}>
                  <p className="text-xs font-bold italic">
                    {savedPermissions.tracking ? "Tracking Allowed" : "Ask App Not to Track"}
                  </p>
                  <p className="text-[9px] text-muted-foreground italic mt-0.5">
                    {savedPermissions.tracking ? "Personalized features enabled" : "Maximum privacy - recommended"}
                  </p>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">Permissions</p>
                <PermissionStatus icon={<Activity className="w-4 h-4" />} label="Health Data" enabled={savedPermissions.health} onToggle={() => {
                  const updated = { ...savedPermissions, health: !savedPermissions.health };
                  setSavedPermissions(updated);
                  localStorage.setItem("nightlight_permissions", JSON.stringify(updated));
                  toast.success(`Health Data ${!savedPermissions.health ? "enabled" : "disabled"}`);
                }} />
                <PermissionStatus icon={<Mic className="w-4 h-4" />} label="Microphone" enabled={savedPermissions.microphone} onToggle={() => {
                  const updated = { ...savedPermissions, microphone: !savedPermissions.microphone };
                  setSavedPermissions(updated);
                  localStorage.setItem("nightlight_permissions", JSON.stringify(updated));
                  toast.success(`Microphone ${!savedPermissions.microphone ? "enabled" : "disabled"}`);
                }} />
                <PermissionStatus icon={<Bell className="w-4 h-4" />} label="Notifications" enabled={savedPermissions.notifications} onToggle={() => {
                  const updated = { ...savedPermissions, notifications: !savedPermissions.notifications };
                  setSavedPermissions(updated);
                  localStorage.setItem("nightlight_permissions", JSON.stringify(updated));
                  toast.success(`Notifications ${!savedPermissions.notifications ? "enabled" : "disabled"}`);
                }} />
                <PermissionStatus icon={<MapPin className="w-4 h-4" />} label="Location" enabled={savedPermissions.location} onToggle={() => {
                  const updated = { ...savedPermissions, location: !savedPermissions.location };
                  setSavedPermissions(updated);
                  localStorage.setItem("nightlight_permissions", JSON.stringify(updated));
                  toast.success(`Location ${!savedPermissions.location ? "enabled" : "disabled"}`);
                }} />
              </div>

              <button
                onClick={() => {
                  const updated = { ...savedPermissions, tracking: !savedPermissions.tracking };
                  setSavedPermissions(updated);
                  localStorage.setItem("nightlight_permissions", JSON.stringify(updated));
                  toast.success(`Tracking ${!savedPermissions.tracking ? "allowed" : "disabled"}`);
                }}
                className="w-full h-12 bg-muted border border-border text-foreground font-bold italic uppercase tracking-widest rounded-2xl text-xs transition-all active:scale-95"
              >
                {savedPermissions.tracking ? "Disable Tracking" : "Allow Tracking"}
              </button>

              <button
                onClick={() => setShowPrivacyReview(false)}
                className="w-full h-12 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl text-xs transition-all active:scale-95 shadow-lg"
              >
                Done
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PermissionStatus({ icon, label, enabled, onToggle }: { icon: React.ReactNode; label: string; enabled: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className={`flex items-center justify-between p-3 rounded-xl border transition-all active:scale-98 ${enabled ? "border-primary/20 bg-primary/5" : "border-border"}`}
    >
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${enabled ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"}`}>
          {icon}
        </div>
        <span className="text-xs font-bold italic">{label}</span>
      </div>
      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${enabled ? "border-primary bg-primary" : "border-border"}`}>
        {enabled && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
      </div>
    </button>
  );
}

function PreferenceToggle({ icon, label, description, checked, onCheckedChange }: { icon: React.ReactNode; label: string; description: string; checked: boolean; onCheckedChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between bg-background/40 border border-border/50 p-5 rounded-3xl group transition-all hover:bg-background/60">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-muted rounded-2xl flex items-center justify-center text-muted-foreground group-hover:rotate-6 transition-transform">
          {icon}
        </div>
        <div className="flex flex-col gap-0.5">
          <span className="text-base font-bold tracking-tight leading-none italic">{label}</span>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic opacity-60 truncate">{description}</p>
        </div>
      </div>
      <Switch.Root
        checked={checked}
        onCheckedChange={onCheckedChange}
        className="w-12 h-7 bg-border/40 rounded-full relative shadow-inner focus:outline-none data-[state=checked]:bg-primary transition-colors"
      >
        <Switch.Thumb className="block w-5 h-5 bg-white rounded-full transition-transform duration-200 translate-x-1 will-change-transform data-[state=checked]:translate-x-6 shadow-md" />
      </Switch.Root>
    </div>
  );
}

function SettingsLink({ icon, label, onClick, color }: { icon: React.ReactNode; label: string; onClick: () => void; color?: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center justify-between p-5 bg-background/20 rounded-2xl border border-border transition-all hover:bg-background/40 active:scale-98 group",
        color
      )}
    >
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center">
          {icon}
        </div>
        <span className="text-sm font-bold tracking-tight italic uppercase tracking-widest">{label}</span>
      </div>
      <ChevronRight className="w-5 h-5 text-muted-foreground/30 group-hover:translate-x-1 transition-transform" />
    </button>
  );
}