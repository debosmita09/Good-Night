import { useState, useEffect } from "react";
import { Bell, Sparkles, Brain, Moon, ShieldCheck, Heart, Info, Clock, Check, Trash2, ChevronLeft, Lightbulb, Zap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { getDailyWisdom } from "../lib/sleep-logic";

export function Notifications() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([
    { id: "1", type: "fact", title: "Sleep Trivia", text: "Humans are the only mammals that willingly delay sleep, often ignoring their biological clocks.", category: "Biology", read: false, time: "Just Now" },
    { id: "2", type: "tip", title: "Healthy Habit", text: "Drinking a glass of water first thing in the morning kicks starts your metabolism.", category: "Health", read: false, time: "2h ago" },
    { id: "3", type: "alert", title: "Wind Down Reminder", text: "It's almost 10 PM. Dimming your lights now can help prepare your brain for sleep.", category: "Routine", read: true, time: "Yesterday" },
    { id: "4", type: "fact", title: "Brain Power", text: "Your brain is actually more active during REM sleep than it is while you are awake.", category: "Neurology", read: true, time: "Yesterday" },
    { id: "5", type: "tip", title: "Night Tip", text: "Sleeping on your left side can help with digestion and reduce acid reflux during the night.", category: "Health", read: true, time: "2d ago" }
  ]);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast.success("All notifications marked as read");
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getIcon = (type: string) => {
    switch(type) {
      case "fact": return <Lightbulb className="w-5 h-5 text-amber-400" />;
      case "tip": return <Brain className="w-5 h-5 text-blue-400" />;
      case "alert": return <Bell className="w-5 h-5 text-primary" />;
      default: return <Info className="w-5 h-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="flex flex-col gap-8 pb-12 px-1">
      <header className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Notification Center</h1>
          <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Daily wisdom & health alerts.</p>
        </div>
        <button 
          onClick={markAllRead}
          className="p-3 bg-muted/50 rounded-2xl hover:bg-muted transition-all active:scale-95"
          title="Mark all as read"
        >
          <Check className="w-5 h-5 text-muted-foreground" />
        </button>
      </header>

      <div className="flex flex-col gap-4">
        {notifications.filter(n => !n.read).length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-4 opacity-40">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
              <Bell className="w-10 h-10 text-muted-foreground" />
            </div>
            <p className="text-sm font-bold uppercase tracking-widest italic leading-none">All clear for now</p>
          </div>
        ) : (
          <AnimatePresence initial={false}>
            {notifications.filter(n => !n.read).map((n) => (
              <motion.div
                key={n.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={cn(
                  "p-6 rounded-[2.5rem] border flex flex-col gap-4 transition-all relative group overflow-hidden",
                  n.read ? "bg-card border-border opacity-70" : "bg-primary/5 border-primary/20 shadow-lg"
                )}
              >
                {!n.read && (
                  <div className="absolute top-6 left-6 w-2 h-2 bg-primary rounded-full animate-pulse z-10" />
                )}
                
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:rotate-6 shadow-sm",
                      n.read ? "bg-muted" : "bg-background/80"
                    )}>
                      {getIcon(n.type)}
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <span className="text-sm font-black italic uppercase tracking-widest">{n.title}</span>
                      <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic leading-none mt-0.5 opacity-60">{n.category} • {n.time}</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => deleteNotification(n.id)}
                    className="p-2 opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-xs font-bold text-foreground italic leading-relaxed pl-1">
                  "{n.text}"
                </p>

                {n.type === "alert" && (
                  <button 
                    onClick={() => navigate("/wind-down")}
                    className="mt-2 w-full h-12 bg-primary text-primary-foreground font-black rounded-xl text-[10px] uppercase tracking-widest italic shadow-lg active:scale-95 transition-all"
                  >
                    Set Wind Down Ritual
                  </button>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Daily Fact Promo */}
      <section className="bg-amber-400/5 border-2 border-dashed border-amber-400/20 p-8 rounded-[3rem] flex items-center gap-6 group">
        <div className="w-16 h-16 bg-amber-400/10 rounded-[1.5rem] flex items-center justify-center text-amber-500 shadow-sm group-hover:rotate-12 transition-transform">
          <Sparkles className="w-8 h-8 fill-current" />
        </div>
        <div className="flex flex-col gap-1">
          <h3 className="text-lg font-black italic uppercase tracking-widest">Knowledge is Power</h3>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic opacity-60">Daily sleep facts help you rest smarter.</p>
        </div>
      </section>
    </div>
  );
}
