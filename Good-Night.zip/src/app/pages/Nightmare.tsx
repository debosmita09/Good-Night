import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Moon, Heart, ChevronLeft, Volume2, X, ShieldCheck, Sparkles, Brain, Info, Timer } from "lucide-react";
import { useNavigate } from "react-router";
import { cn } from "../lib/utils";

export function Nightmare() {
  const navigate = useNavigate();
  const [step, setStep] = useState<"initial" | "breathing" | "recovery">("initial");
  const [timer, setTimer] = useState(60);
  const [isExhaling, setIsExhaling] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === "breathing") {
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            setStep("recovery");
            return 60;
          }
          return prev - 1;
        });
        setIsExhaling((prev) => !prev);
      }, 4000); // 4s inhale, 4s exhale
    }
    return () => clearInterval(interval);
  }, [step]);

  const handleReturn = () => {
    navigate("/");
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black text-foreground flex flex-col items-center justify-center p-8 overflow-hidden">
      {/* Background Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-95" />

      {/* Close/Back Button (Subtle but reachable) */}
      <button 
        onClick={handleReturn}
        className="absolute top-10 left-8 z-[110] flex items-center gap-3 text-muted-foreground hover:text-foreground transition-all group p-4 rounded-[1.5rem] bg-white/5 border border-white/5 shadow-xl active:scale-95"
      >
        <X className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase tracking-widest leading-none italic">Exit Mode</span>
      </button>

      <AnimatePresence mode="wait">
        {step === "initial" && (
          <motion.div
            key="initial"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="flex flex-col items-center gap-12 z-[110] text-center max-w-sm"
          >
            <div className="flex flex-col gap-6">
              <div className="w-20 h-20 bg-primary/10 rounded-[2rem] flex items-center justify-center text-primary mx-auto shadow-[0_0_40px_rgba(167,139,250,0.2)] animate-pulse">
                <Moon className="w-10 h-10 fill-current" />
              </div>
              <h1 className="text-4xl font-black tracking-tight text-white italic leading-tight">
                Are you feeling unsettled?
              </h1>
              <p className="text-muted-foreground font-medium text-sm leading-relaxed max-w-xs mx-auto italic uppercase tracking-widest opacity-60">
                Take a breath. We're here to help you feel safe and calm.
              </p>
            </div>

            <button
              onClick={() => setStep("breathing")}
              className="group relative w-64 h-64 bg-primary/10 rounded-full border-2 border-primary/20 flex flex-col items-center justify-center gap-4 transition-all hover:scale-105 active:scale-95 shadow-[0_0_100px_rgba(167,139,250,0.15)]"
            >
              <div className="absolute inset-0 bg-primary/10 rounded-full animate-ping opacity-20" />
              <Sparkles className="w-12 h-12 text-primary fill-current transition-transform group-hover:rotate-12" />
              <div className="flex flex-col gap-2">
                <span className="text-xl font-black text-white tracking-tight leading-none italic uppercase tracking-widest">Help me calm down</span>
                <span className="text-[10px] text-primary font-bold uppercase tracking-widest leading-none mt-1 italic opacity-80">tap to start breathing</span>
              </div>
            </button>
          </motion.div>
        )}

        {step === "breathing" && (
          <motion.div
            key="breathing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-16 z-[110] text-center w-full"
          >
            <div className="flex flex-col gap-4">
              <h2 className="text-sm font-black tracking-widest text-muted-foreground uppercase leading-none italic">
                Focus on the rhythm
              </h2>
              <p className="text-3xl font-black text-white italic tracking-tight leading-none uppercase">
                {isExhaling ? "Exhale slowly..." : "Inhale deeply..."}
              </p>
            </div>

            {/* Breathing Circle Animation */}
            <div className="relative flex items-center justify-center w-80 h-80">
              <motion.div
                animate={{
                  scale: isExhaling ? 0.6 : 1.3,
                  opacity: isExhaling ? 0.3 : 0.7,
                }}
                transition={{
                  duration: 4,
                  ease: "easeInOut",
                }}
                className="absolute inset-0 bg-primary/20 rounded-full blur-[80px] shadow-[0_0_100px_rgba(167,139,250,0.3)]"
              />
              <motion.div
                animate={{
                  scale: isExhaling ? 0.8 : 1.2,
                }}
                transition={{
                  duration: 4,
                  ease: "easeInOut",
                }}
                className="w-56 h-56 bg-card border-4 border-primary/40 rounded-full flex items-center justify-center relative overflow-hidden group shadow-2xl"
              >
                <div className="flex flex-col items-center gap-2">
                  <Heart className={cn(
                    "w-12 h-12 text-primary transition-all duration-[4s] ease-in-out fill-current",
                    isExhaling ? "scale-90 opacity-40" : "scale-110 opacity-100"
                  )} />
                </div>
              </motion.div>
            </div>

            <div className="flex flex-col gap-6">
              <p className="text-2xl font-bold text-white leading-relaxed italic uppercase tracking-widest opacity-80">
                You are safe. You are in your room.
              </p>
              <div className="flex items-center gap-3 justify-center bg-white/5 px-6 py-3 rounded-2xl border border-white/5">
                <Timer className="w-5 h-5 text-primary" />
                <span className="text-sm font-black text-muted-foreground tracking-[0.2em] leading-none italic">
                  {timer}S REMAINING
                </span>
              </div>
            </div>
          </motion.div>
        )}

        {step === "recovery" && (
          <motion.div
            key="recovery"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-10 z-[110] text-center w-full max-w-sm"
          >
            <div className="flex flex-col gap-4">
              <h2 className="text-3xl font-black text-white italic tracking-tight leading-none uppercase">How are you feeling?</h2>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest leading-relaxed italic opacity-60 px-6">
                Nightmares are a way your brain processes stress. You've grounded yourself perfectly.
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-4 w-full px-4">
              <RecoveryButton 
                onClick={() => setStep("breathing")}
                icon={<Moon className="w-6 h-6 fill-current" />}
                label="Continue Breathing"
                color="primary"
              />
              <RecoveryButton 
                onClick={() => {}}
                icon={<Volume2 className="w-6 h-6 fill-current" />}
                label="Play Calm Brown Noise"
                color="secondary"
              />
              <RecoveryButton 
                onClick={handleReturn}
                icon={<ChevronLeft className="w-6 h-6" />}
                label="Return to Sleep Mode"
                variant="outline"
                color="white"
              />
            </div>

            <div className="flex items-center gap-3 bg-white/5 p-5 rounded-[2rem] border border-white/5 transition-all hover:bg-white/10">
              <Info className="w-5 h-5 text-primary shrink-0" />
              <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-relaxed italic text-left">
                The screen will auto-dim in 20 minutes to preserve your melatonin.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function RecoveryButton({ 
  icon, 
  label, 
  onClick, 
  variant = "primary",
  color = "primary"
}: { 
  icon: React.ReactNode; 
  label: string; 
  onClick: () => void; 
  variant?: "primary" | "outline";
  color?: "primary" | "secondary" | "white";
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full h-18 rounded-[2rem] flex items-center justify-center gap-4 font-black uppercase tracking-widest italic transition-all active:scale-95 shadow-lg",
        variant === "primary" && color === "primary" && "bg-primary text-primary-foreground",
        variant === "primary" && color === "secondary" && "bg-secondary text-secondary-foreground",
        variant === "outline" && "bg-transparent border-2 border-white/20 text-white hover:bg-white/10"
      )}
    >
      {icon}
      <span className="text-sm">{label}</span>
    </button>
  );
}
