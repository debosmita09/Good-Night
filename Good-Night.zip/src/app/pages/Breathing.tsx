import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronRight, ArrowLeft, Wind, Play, Check, Moon, Zap } from "lucide-react";
import { useNavigate } from "react-router";
import { useRewards } from "../RewardContext";
import { toast } from "sonner";
import { cn } from "../lib/utils";

export function Breathing() {
  const navigate = useNavigate();
  const { completeRitual } = useRewards();
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"Inhale" | "Exhale" | "Hold">("Inhale");
  const [countdown, setCountdown] = useState(4);
  const [reps, setReps] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    let timer: any;
    if (isActive && reps < 5) {
      timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev === 1) {
            if (phase === "Inhale") {
              setPhase("Hold");
              return 4;
            } else if (phase === "Hold") {
              setPhase("Exhale");
              return 6;
            } else {
              setPhase("Inhale");
              setReps((r) => r + 1);
              return 4;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else if (reps >= 5 && !isFinished) {
      setIsFinished(true);
      setIsActive(false);
      completeRitual("breath");
      toast.success("Breathing exercise complete. Your heart rate is lowering.", { icon: "🫀" });
    }
    return () => clearInterval(timer);
  }, [isActive, phase, reps, isFinished]);

  if (isFinished) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center gap-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-400"
        >
          <Moon className="w-12 h-12 fill-current" />
        </motion.div>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black italic uppercase tracking-widest text-foreground">Deeply Calm</h1>
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
            Your nervous system is settled.
          </p>
        </div>
        <button 
          onClick={() => navigate("/wind-down")}
          className="w-full max-w-xs h-16 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all"
        >
          Return to Ritual
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col p-6 overflow-hidden">
      <header className="flex items-center gap-4 mb-12">
        <button onClick={() => navigate("/wind-down")} className="p-2 hover:bg-muted rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Breathing</h1>
          <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">The 4-4-6 Method</p>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center gap-12">
        <div className="relative flex items-center justify-center w-64 h-64">
          <AnimatePresence>
            <motion.div
              key={phase}
              initial={{ scale: phase === "Inhale" ? 1 : phase === "Hold" ? 1.5 : 1.5 }}
              animate={{ 
                scale: phase === "Inhale" ? 1.5 : phase === "Hold" ? 1.5 : 1,
              }}
              transition={{ 
                duration: phase === "Inhale" ? 4 : phase === "Hold" ? 4 : 6,
                ease: "easeInOut"
              }}
              className="absolute inset-0 bg-blue-500/10 rounded-full border-4 border-blue-500/20"
            />
          </AnimatePresence>
          
          <div className="flex flex-col items-center gap-2 relative z-10">
            <h2 className="text-5xl font-black italic uppercase tracking-tighter text-foreground">{countdown}</h2>
            <p className="text-lg font-black uppercase tracking-widest text-blue-400 italic">{phase}</p>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex gap-2 justify-center">
            {[...Array(5)].map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "w-2 h-2 rounded-full transition-all duration-500",
                  i < reps ? "bg-blue-400" : "bg-muted"
                )} 
              />
            ))}
          </div>
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest italic opacity-60">5 Cycles Remaining</p>
        </div>

        {!isActive && (
          <button 
            onClick={() => setIsActive(true)}
            className="w-full max-w-xs h-16 bg-blue-500 text-white font-black italic uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            <Play className="w-6 h-6 fill-current" />
            Begin Exercise
          </button>
        )}
      </main>

      <footer className="mt-auto py-8 text-center px-8">
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
          Inhale for 4s, Hold for 4s, Exhale for 6s. This rhythm activates your parasympathetic nervous system.
        </p>
      </footer>
    </div>
  );
}
