import { useState, useEffect } from "react";
import { Timer, Wind, Scan, PenLine, BookOpen, Sparkles, ChevronRight, Play, Check, ShieldCheck, Smartphone, Moon, X, Info, Zap, AlertTriangle, AlertCircle, Phone, Heart } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import * as Slider from "@radix-ui/react-slider";
import * as Switch from "@radix-ui/react-switch";
import { toast } from "sonner";
import { useNavigate } from "react-router";
import { useRewards } from "../RewardContext";

export function WindDown() {
  const navigate = useNavigate();
  const { completedRituals } = useRewards();
  const [timerValue, setTimerValue] = useState([30]);
  const [isDimming, setIsDimming] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [showOverride, setShowOverride] = useState(false);

  const activities = [
    { 
      id: "breath", 
      icon: <Wind className="w-5 h-5" />, 
      title: "4-4-6 Breathing", 
      desc: "Settle your nervous system", 
      color: "bg-blue-500/10 text-blue-400",
      path: "/breathing"
    },
    { 
      id: "scan", 
      icon: <Scan className="w-5 h-5" />, 
      title: "Snuggle Stretch", 
      desc: "Release physical tension", 
      color: "bg-purple-500/10 text-purple-400",
      path: "/snuggle-stretch"
    },
    { 
      id: "journal", 
      icon: <PenLine className="w-5 h-5" />, 
      title: "Night Journal", 
      desc: "Clear your head of worries", 
      color: "bg-amber-500/10 text-amber-400",
      path: "/journal"
    }
  ];

  const handleStartWindDown = () => {
    setIsStarting(true);
    setTimeout(() => {
      setIsStarting(false);
      setIsActive(true);
      toast.success(`Wind down started for ${timerValue[0]} minutes`);
      if (isLocked) {
        toast.info("Social media apps are now restricted.");
      }
      if (isDimming) {
        document.body.style.filter = "brightness(0.7)";
      }
    }, 2000);
  };

  const handleEmergencyOverride = () => {
    setIsLocked(false);
    setIsActive(false);
    document.body.style.filter = "brightness(1)";
    toast.warning("Emergency override activated. App locks disabled.");
  };

  const handleActivityClick = (path: string, id: string) => {
    if (completedRituals.includes(id)) {
      toast.info(`${id.charAt(0).toUpperCase() + id.slice(1)} already completed! Great job.`);
      return;
    }
    navigate(path);
  };

  return (
    <div className="flex flex-col gap-8 pb-12 px-1">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Wind Down</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Prepare your mind for sleep.</p>
      </header>

      {/* Digital Sunset Card */}
      <section className={cn(
        "bg-card border-2 rounded-[2.5rem] p-8 flex flex-col gap-8 relative overflow-hidden transition-all duration-500",
        isActive ? "border-primary shadow-[0_0_80px_rgba(167,139,250,0.2)]" : "border-primary/20 shadow-[0_0_50px_rgba(167,139,250,0.1)]"
      )}>
        <div className="absolute top-0 right-0 p-6 opacity-10 transition-transform group-hover:scale-110">
          <Moon className="w-16 h-16 text-primary fill-current" />
        </div>

        <div className="flex flex-col gap-2 relative z-10">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold tracking-tight leading-none italic uppercase tracking-widest">🌇 Digital Sunset</span>
          </div>
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-relaxed mt-1 italic">
            Reduce distractions {timerValue[0]} minutes before bed.
          </p>
        </div>

        {!isActive ? (
          <div className="flex flex-col gap-6 relative z-10">
            <div className="flex justify-between items-center px-1">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest leading-none italic">Timer</span>
              <span className="text-lg font-bold text-primary leading-none italic">{timerValue[0]} min</span>
            </div>
            
            <Slider.Root
              className="relative flex items-center select-none touch-none w-full h-6"
              value={timerValue}
              max={60}
              min={15}
              step={5}
              onValueChange={setTimerValue}
            >
              <Slider.Track className="bg-border/20 relative grow rounded-full h-2 overflow-hidden border border-white/5 shadow-inner">
                <Slider.Range className="absolute bg-primary rounded-full h-full transition-all" />
              </Slider.Track>
              <Slider.Thumb className="block w-7 h-7 bg-primary shadow-xl rounded-2xl hover:scale-110 focus:outline-none transition-transform cursor-grab active:cursor-grabbing border-4 border-card" />
            </Slider.Root>

            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center justify-between bg-background/40 border border-border/50 p-4 rounded-2xl group transition-all hover:bg-background/60">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary group-hover:rotate-6 transition-transform">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-bold tracking-tight leading-none italic">Dim screen</span>
                    <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none italic mt-1">Auto-adjust brightness</p>
                  </div>
                </div>
                <Switch.Root
                  checked={isDimming}
                  onCheckedChange={setIsDimming}
                  className="w-12 h-7 bg-border/40 rounded-full relative shadow-inner focus:outline-none data-[state=checked]:bg-primary transition-colors"
                >
                  <Switch.Thumb className="block w-5 h-5 bg-white rounded-full transition-transform duration-200 translate-x-1 will-change-transform data-[state=checked]:translate-x-6 shadow-md" />
                </Switch.Root>
              </div>

              <div className="flex items-center justify-between bg-background/40 border border-border/50 p-4 rounded-2xl group transition-all hover:bg-background/60">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-secondary/10 rounded-xl flex items-center justify-center text-secondary group-hover:rotate-6 transition-transform">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-bold tracking-tight leading-none italic">Lock social apps</span>
                    <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none italic mt-1">No-scroll reinforcement</p>
                  </div>
                </div>
                <Switch.Root
                  checked={isLocked}
                  onCheckedChange={setIsLocked}
                  className="w-12 h-7 bg-border/40 rounded-full relative shadow-inner focus:outline-none data-[state=checked]:bg-secondary transition-colors"
                >
                  <Switch.Thumb className="block w-5 h-5 bg-white rounded-full transition-transform duration-200 translate-x-1 will-change-transform data-[state=checked]:translate-x-6 shadow-md" />
                </Switch.Root>
              </div>
            </div>

            <button 
              onClick={handleStartWindDown}
              className={cn(
                "w-full h-16 bg-primary text-primary-foreground font-bold rounded-2xl flex items-center justify-center gap-3 transition-all hover:brightness-110 active:scale-95 shadow-lg",
                isStarting && "opacity-50 cursor-not-allowed"
              )}
            >
              {isStarting ? (
                <div className="w-6 h-6 border-3 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  <Timer className="w-6 h-6" />
                  <span className="uppercase tracking-widest italic font-black">Start Ritual</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-8 py-4 relative z-10">
            <div className="relative flex items-center justify-center w-48 h-48">
              <motion.div 
                animate={{ scale: [1, 1.1, 1], rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 border-4 border-dashed border-primary/40 rounded-full"
              />
              <div className="text-center">
                <span className="text-5xl font-black italic text-foreground leading-none">{timerValue[0]}</span>
                <p className="text-[10px] font-bold uppercase tracking-widest text-primary mt-2 italic">MIN REMAINING</p>
              </div>
            </div>

            {isLocked && (
              <div className="flex flex-col gap-4 w-full">
                <div className="bg-amber-400/10 border border-amber-400/20 p-4 rounded-2xl flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs font-bold text-amber-600/80 italic leading-relaxed uppercase tracking-widest">
                    Social apps are currently locked to help you focus on rest.
                  </p>
                </div>
                
                <button 
                  onClick={() => setShowOverride(true)}
                  className="text-[10px] font-black text-muted-foreground uppercase tracking-widest underline underline-offset-4 italic opacity-60 hover:opacity-100 transition-opacity"
                >
                  I have an emergency
                </button>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Emergency Override Modal */}
      <AnimatePresence>
        {showOverride && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-card border-2 border-red-500/20 p-8 rounded-[3rem] shadow-2xl max-w-sm w-full flex flex-col items-center text-center gap-6"
            >
              <div className="w-16 h-16 bg-red-500/10 rounded-[1.5rem] flex items-center justify-center text-red-500 shadow-sm">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-2xl font-black italic tracking-tight uppercase tracking-widest">Emergency Access</h3>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest leading-relaxed italic opacity-80">
                  Are you sure you need to override the sleep lock? This should only be used in true emergencies.
                </p>
              </div>
              <div className="flex flex-col gap-3 w-full">
                <button 
                  onClick={handleEmergencyOverride}
                  className="w-full h-14 bg-red-500 text-white font-black rounded-2xl flex items-center justify-center gap-3 transition-all hover:bg-red-600 active:scale-95 uppercase tracking-widest italic"
                >
                  <ShieldCheck className="w-5 h-5" />
                  Override Lock
                </button>
                <button 
                  onClick={() => setShowOverride(false)}
                  className="w-full h-14 bg-card border border-border text-foreground font-black rounded-2xl flex items-center justify-center transition-all hover:bg-border/20 active:scale-95 uppercase tracking-widest italic"
                >
                  Return to Rest
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pre-Sleep Ritual Activities */}
      <section className="flex flex-col gap-4">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">Personalized Ritual</h3>
        <div className="grid grid-cols-1 gap-3">
          <button 
            onClick={() => navigate("/kids-mode")}
            className="flex items-center gap-4 p-5 rounded-3xl border border-pink-500/20 bg-pink-500/5 hover:bg-pink-500/10 transition-all active:scale-[0.98] text-left group"
          >
            <div className="w-12 h-12 rounded-2xl bg-pink-500/10 text-pink-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform shadow-sm">
              <Heart className="w-6 h-6 fill-current" />
            </div>
            <div className="flex-1 flex flex-col gap-1 min-w-0">
              <span className="font-bold tracking-tight leading-none italic">Baby Sleep Mode</span>
              <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic truncate opacity-70">Lullabies & visuals for little ones</span>
            </div>
            <ChevronRight className="w-4 h-4 text-pink-400 opacity-30 group-hover:opacity-100 transition-opacity" />
          </button>
          
          {activities.map((act) => {
            const isCompleted = completedRituals.includes(act.id);
            return (
              <button 
                key={act.id}
                onClick={() => handleActivityClick(act.path, act.id)}
                className={cn(
                  "flex items-center gap-4 p-5 rounded-3xl border transition-all active:scale-[0.98] text-left group",
                  isCompleted 
                    ? "bg-primary/5 border-primary/20 opacity-70" 
                    : "bg-card border-border hover:bg-border/20"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform shadow-sm",
                  isCompleted ? "bg-primary text-primary-foreground" : act.color
                )}>
                  {isCompleted ? <Check className="w-6 h-6" /> : act.icon}
                </div>
                <div className="flex-1 flex flex-col gap-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold tracking-tight leading-none italic">{act.title}</span>
                    {isCompleted && <span className="text-[8px] font-black uppercase text-primary tracking-tighter italic">Completed</span>}
                  </div>
                  <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic truncate opacity-70">{act.desc}</span>
                </div>
                {!isCompleted && <ChevronRight className="w-4 h-4 text-muted-foreground opacity-30 group-hover:opacity-100 transition-opacity" />}
              </button>
            );
          })}
        </div>
      </section>

      {/* Nightmare Prevention Advice */}
      <div className="bg-purple-500/10 border border-purple-500/20 p-6 rounded-3xl flex items-start gap-4 transition-all hover:bg-purple-500/15">
        <Sparkles className="w-6 h-6 text-purple-400 shrink-0 mt-0.5" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-bold text-foreground italic leading-relaxed uppercase tracking-widest">
            "High anxiety today detected. Research suggests imagery rehearsal lowers nightmare risk."
          </p>
          <button 
            onClick={() => navigate("/journal")}
            className="text-[10px] font-black text-purple-400 uppercase tracking-widest mt-2 hover:text-purple-300 transition-colors underline underline-offset-4 italic"
          >
            Start Dream Rehearsal →
          </button>
        </div>
      </div>
    </div>
  );
}
