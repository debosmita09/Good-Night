import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Wind, Scan, Sparkles, Check, Moon, Play, ArrowLeft, Heart, Zap, ShieldCheck } from "lucide-react";
import { useNavigate } from "react-router";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { useRewards } from "../RewardContext";

type ExerciseType = "stretching" | "calming" | null;

interface Step {
  id: string;
  part: string;
  instruction: string;
  stretching: string;
  calming: string;
}

const steps: Step[] = [
  {
    id: "toes",
    part: "Toes",
    instruction: "Focus all your attention on your toes.",
    stretching: "Curl your toes tightly for 5 seconds, then spread them as wide as you can.",
    calming: "Simply acknowledge any sensation in your toes. Imagine a warm light softening them."
  },
  {
    id: "feet",
    part: "Feet & Ankles",
    instruction: "Move your awareness up to your feet.",
    stretching: "Point your toes away from you, then flex them back towards your shins.",
    calming: "Feel the weight of your feet against the surface. Let go of any remaining tension."
  },
  {
    id: "calves",
    part: "Calves",
    instruction: "Focus on your lower legs.",
    stretching: "Tense your calf muscles for a moment, then release and feel them melt into the bed.",
    calming: "Visualize your calves becoming heavy and relaxed, like sandbags."
  },
  {
    id: "thighs",
    part: "Thighs & Glutes",
    instruction: "Shift to your upper legs.",
    stretching: "Squeeze your thighs and glutes firmly, hold for 3 seconds, and let go completely.",
    calming: "Notice the large muscles in your thighs. Breath into them and watch them soften."
  },
  {
    id: "back",
    part: "Back & Spine",
    instruction: "Bring awareness to your entire back.",
    stretching: "Gently arch your back off the bed, then press it flat against the surface.",
    calming: "Imagine each vertebra of your spine slowly settling, one by one, into a deep rest."
  },
  {
    id: "shoulders",
    part: "Shoulders",
    instruction: "Now, focus on your shoulders.",
    stretching: "Shrug your shoulders up to your ears, then drop them heavily with a deep exhale.",
    calming: "Let your shoulders fall away from your ears. Feel them spreading wide and soft."
  },
  {
    id: "arms",
    part: "Arms & Hands",
    instruction: "Move down to your arms and fingers.",
    stretching: "Make tight fists, then slowly open your hands and wiggle your fingers.",
    calming: "Feel a sense of weightlessness in your arms. Your hands are still and calm."
  },
  {
    id: "neck",
    part: "Neck",
    instruction: "Gently notice your neck.",
    stretching: "Slowly tilt your head from left to right, feeling the gentle stretch.",
    calming: "Let your neck muscles go limp. Your head is perfectly supported by the pillow."
  },
  {
    id: "face",
    part: "Jaw & Face",
    instruction: "Focus on your facial muscles.",
    stretching: "Open your mouth wide in a silent yawn, then let your jaw go completely slack.",
    calming: "Let your jaw unhinge slightly. Feel the space between your teeth. Your tongue is soft."
  },
  {
    id: "eyebrows",
    part: "Eyebrows & Forehead",
    instruction: "Finally, reach the top of your head.",
    stretching: "Raise your eyebrows high, then smooth your forehead like a still lake.",
    calming: "Imagine a gentle hand smoothing out any lines on your forehead. Your eyes are heavy."
  }
];

export function SnuggleStretch() {
  const navigate = useNavigate();
  const { completeRitual } = useRewards();
  const [exerciseType, setExerciseType] = useState<ExerciseType>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Recommendation logic
  const suggestion = {
    stretching: "Best if you feel restless, have excess energy, or physical tightness.",
    calming: "Best if you're feeling anxious, overthinking, or just want to drift off immediately."
  };

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
      completeRitual("scan");
      toast.success("Snuggle stretch complete. You're ready for rest.", {
        icon: "🌙"
      });
    }
  };

  const handleBack = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    } else {
      setExerciseType(null);
    }
  };

  const currentStep = steps[currentStepIndex];

  if (isFinished) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center gap-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center text-primary"
        >
          <Moon className="w-12 h-12 fill-current" />
        </motion.div>
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black italic uppercase tracking-widest text-foreground">Deeply Relaxed</h1>
          <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
            Your body is now prepared for a restorative sleep.
          </p>
        </div>
        <button 
          onClick={() => navigate("/wind-down")}
          className="w-full max-w-xs h-16 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all"
        >
          Return to Ritual
        </button>
      </div>
    );
  }

  if (!exerciseType) {
    return (
      <div className="flex flex-col gap-8 pb-12 px-1">
        <header className="flex items-center gap-4">
          <button onClick={() => navigate("/wind-down")} className="p-2 hover:bg-muted rounded-full transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Snuggle Stretch</h1>
            <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Release tension from toe to brow.</p>
          </div>
        </header>

        
        <section className="flex flex-col gap-6">
          <div className="bg-primary/5 border border-primary/20 p-6 rounded-[2.5rem] flex items-start gap-4">
            <Sparkles className="w-6 h-6 text-primary shrink-0 mt-0.5" />
            <div className="flex flex-col gap-1">
              <span className="text-[10px] font-black text-primary uppercase tracking-widest italic">Luma's Guidance</span>
              <p className="text-xs font-bold text-foreground italic leading-relaxed uppercase tracking-widest">
                "Choose the ritual that matches your current energy state for the best rest."
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <button 
              onClick={() => setExerciseType("stretching")}
              className="flex flex-col gap-4 p-8 rounded-[3rem] border-2 border-border bg-card hover:border-primary/40 transition-all group text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <Zap className="w-20 h-20 text-primary" />
              </div>
              <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                <Zap className="w-7 h-7" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-xl font-black italic uppercase tracking-widest">Stretching Ritual</h3>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
                  {suggestion.stretching}
                </p>
              </div>
              <div className="flex items-center gap-2 mt-2 text-[10px] font-black text-primary uppercase tracking-widest italic">
                <span>Start Stretching</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </button>

            <button 
              onClick={() => setExerciseType("calming")}
              className="flex flex-col gap-4 p-8 rounded-[3rem] border-2 border-border bg-card hover:border-secondary/40 transition-all group text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <ShieldCheck className="w-20 h-20 text-secondary" />
              </div>
              <div className="w-14 h-14 rounded-2xl bg-secondary/10 text-secondary flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-xl font-black italic uppercase tracking-widest">Calming Stretch</h3>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed">
                  {suggestion.calming}
                </p>
              </div>
              <div className="flex items-center gap-2 mt-2 text-[10px] font-black text-secondary uppercase tracking-widest italic">
                <span>Start Calming</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col p-6">
      <header className="flex justify-between items-center mb-12">
        <button onClick={handleBack} className="p-2 hover:bg-muted rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground italic">
            {exerciseType === "stretching" ? "Active Snuggle" : "Mindful Snuggle"}
          </span>
          <div className="flex gap-1 mt-1">
            {steps.map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "w-1.5 h-1.5 rounded-full transition-all duration-500",
                  i === currentStepIndex ? "bg-primary w-4" : i < currentStepIndex ? "bg-primary/40" : "bg-muted"
                )} 
              />
            ))}
          </div>
        </div>
        <div className="w-10" /> {/* Spacer */}
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center gap-12 max-w-md mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex flex-col items-center gap-8 w-full"
          >
            <div className="w-48 h-48 bg-primary/5 rounded-[3rem] flex items-center justify-center text-primary relative group">
              <motion.div 
                animate={{ scale: [1, 1.05, 1], opacity: [0.1, 0.2, 0.1] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute inset-0 bg-primary/20 rounded-[3.5rem] -z-10"
              />
              <StretchAnimation part={currentStep.id} active={exerciseType === "stretching"} />
            </div>

            <div className="flex flex-col gap-4">
              <h2 className="text-4xl font-black italic uppercase tracking-tighter text-foreground">{currentStep.part}</h2>
              <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest italic leading-relaxed px-4">
                {currentStep.instruction}
              </p>
            </div>

            <div className="bg-card border-2 border-primary/20 p-8 rounded-[2.5rem] shadow-xl relative w-full">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-[8px] font-black uppercase tracking-widest italic">
                Snuggle Tip
              </div>
              <p className="text-lg font-bold italic text-foreground leading-relaxed">
                "{exerciseType === "stretching" ? currentStep.stretching : currentStep.calming}"
              </p>
            </div>
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="mt-auto pt-12">
        <button 
          onClick={handleNext}
          className="w-full h-18 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-3xl shadow-2xl flex items-center justify-center gap-3 active:scale-95 transition-all"
        >
          <span>{currentStepIndex === steps.length - 1 ? "Complete Snuggle" : "Next Snuggle"}</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </footer>
    </div>
  );
}

function StretchAnimation({ part, active }: { part: string; active: boolean }) {
  return (
    <svg viewBox="0 0 100 100" className="w-32 h-32 fill-current">
      <motion.circle 
        cx="50" cy="50" r="40" 
        className="text-primary/10" 
        initial={{ scale: 1, opacity: 0.1 }}
        animate={active ? { scale: [1, 1.1, 1], opacity: [0.1, 0.3, 0.1] } : { scale: 1, opacity: 0.1 }}
        transition={{ duration: 2, repeat: Infinity }}
      />
      <g className="text-primary">
        {part === "toes" && (
           <motion.path 
             d="M30,70 Q40,65 50,70 Q60,65 70,70" 
             fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round"
             initial={{ scaleY: 1, y: 0, opacity: 1 }}
             animate={active ? { scaleY: [1, 1.5, 1], y: [0, -5, 0], opacity: 1 } : { scaleY: 1, y: 0, opacity: 0.5 }}
             transition={{ duration: 2, repeat: Infinity }}
           />
        )}
        {part === "feet" && (
          <motion.path 
            d="M40,30 L60,30 L70,80 L30,80 Z" 
            fill="none" stroke="currentColor" strokeWidth="3" 
            initial={{ rotate: 0, scale: 1, opacity: 1 }}
            animate={active ? { rotate: [-10, 10, -10], scale: 1, opacity: 1 } : { rotate: 0, scale: 1, opacity: 0.5 }}
            transition={{ duration: 3, repeat: Infinity }}
          />
        )}
        {part === "calves" && (
          <motion.rect 
            x="40" y="20" width="20" height="60" rx="10"
            fill="none" stroke="currentColor" strokeWidth="3"
            initial={{ width: 20, x: 40, opacity: 1 }}
            animate={active ? { width: [20, 25, 20], x: [40, 37.5, 40], opacity: 1 } : { width: 20, x: 40, opacity: 0.5 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
        {part === "thighs" && (
          <motion.path 
            d="M30,20 Q50,15 70,20 L65,80 Q50,85 35,80 Z" 
            fill="none" stroke="currentColor" strokeWidth="3"
            initial={{ scale: 1, opacity: 1 }}
            animate={active ? { scale: [1, 1.1, 1], opacity: 1 } : { scale: 1, opacity: 0.5 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
        {part === "back" && (
          <motion.path 
            d="M50,10 Q60,50 50,90" 
            fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round"
            initial={{ d: "M50,10 Q60,50 50,90", strokeWidth: 6 }}
            animate={active ? { d: ["M50,10 Q60,50 50,90", "M50,10 Q40,50 50,90", "M50,10 Q60,50 50,90"], strokeWidth: 6 } : { d: "M50,10 Q60,50 50,90", strokeWidth: 4 }}
            transition={{ duration: 3, repeat: Infinity }}
          />
        )}
        {part === "shoulders" && (
          <motion.path 
            d="M20,50 Q50,40 80,50" 
            fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round"
            initial={{ y: 0, opacity: 1 }}
            animate={active ? { y: [0, -15, 0], opacity: 1 } : { y: 0, opacity: 0.5 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
        {part === "arms" && (
          <motion.path 
            d="M10,50 L40,50 M60,50 L90,50" 
            stroke="currentColor" strokeWidth="4" strokeLinecap="round"
            initial={{ x: 0, opacity: 1 }}
            animate={active ? { x: [-5, 5, -5], opacity: 1 } : { x: 0, opacity: 0.5 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
        {part === "neck" && (
          <motion.path 
            d="M50,30 L50,70" 
            stroke="currentColor" strokeWidth="8" strokeLinecap="round"
            initial={{ rotate: 0, opacity: 1 }}
            animate={active ? { rotate: [-15, 15, -15], opacity: 1 } : { rotate: 0, opacity: 0.5 }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
        {part === "face" && (
          <motion.ellipse 
            cx="50" cy="50" rx="20" ry="30" 
            fill="none" stroke="currentColor" strokeWidth="3"
            initial={{ ry: 30, opacity: 1 }}
            animate={active ? { ry: [30, 45, 30], opacity: 1 } : { ry: 30, opacity: 0.5 }}
            transition={{ duration: 3, repeat: Infinity }}
          />
        )}
        {part === "eyebrows" && (
          <g>
            <motion.path 
              d="M35,40 Q40,35 45,40" 
              fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
              initial={{ y: 0, opacity: 1 }}
              animate={active ? { y: [0, -10, 0], opacity: 1 } : { y: 0, opacity: 0.5 }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.path 
              d="M55,40 Q60,35 65,40" 
              fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
              initial={{ y: 0, opacity: 1 }}
              animate={active ? { y: [0, -10, 0], opacity: 1 } : { y: 0, opacity: 0.5 }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.1 }}
            />
          </g>
        )}
      </g>
    </svg>
  );
}
