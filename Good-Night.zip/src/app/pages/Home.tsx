import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router";
import { Moon, MessageSquare, Settings, Plus, Play, Brain, Sparkles, ShieldCheck, Info, Bell, Phone, Heart, X, AlertTriangle, AlertCircle, Star, Cat, Clock, Mic } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { calculateSleepRecommendation, calculateScreenLimit, calculateNightmareRisk, generateSuggestions, DailySleepInput, UserProfile, getDailyWisdom, calculateDailyPoints } from "../lib/sleep-logic";
import * as Slider from "@radix-ui/react-slider";
import { useRewards } from "../RewardContext";
import { toast } from "sonner";
import { DailySleepGraph } from "../components/charts/DailySleepGraph";
import { MoodFrequencyGraph } from "../components/charts/MoodFrequencyGraph";

function BigClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const seconds = time.getSeconds();
  const minutes = time.getMinutes();
  const hours = time.getHours();

  return (
    <div className="flex flex-col items-center justify-center py-6">
      <div className="relative w-48 h-48 rounded-full border-4 border-primary/20 bg-card shadow-[0_0_50px_rgba(167,139,250,0.1)] flex items-center justify-center overflow-hidden group">
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
        
        {/* Clock Center */}
        <div className="w-2 h-2 bg-primary rounded-full z-30 shadow-sm" />
        
        {/* Hour Hand */}
        <motion.div 
          className="absolute w-1 h-12 bg-foreground rounded-full origin-bottom z-20"
          style={{ bottom: "50%", transformOrigin: "bottom" }}
          animate={{ rotate: (hours % 12) * 30 + minutes * 0.5 }}
          transition={{ type: "spring", stiffness: 50 }}
        />
        
        {/* Minute Hand */}
        <motion.div 
          className="absolute w-1 h-16 bg-foreground/60 rounded-full origin-bottom z-10"
          style={{ bottom: "50%", transformOrigin: "bottom" }}
          animate={{ rotate: minutes * 6 }}
          transition={{ type: "spring", stiffness: 50 }}
        />
        
        {/* Second Hand */}
        <motion.div 
          className="absolute w-0.5 h-18 bg-primary rounded-full origin-bottom z-10"
          style={{ bottom: "50%", transformOrigin: "bottom" }}
          animate={{ rotate: seconds * 6 }}
          transition={{ type: "linear", duration: 0 }}
        />

        {/* Hour markers */}
        {[...Array(12)].map((_, i) => (
          <div 
            key={i}
            className="absolute w-1 h-3 bg-muted-foreground/20"
            style={{ 
              top: '4px',
              left: '50%',
              transformOrigin: '50% 92px',
              transform: `translateX(-50%) rotate(${i * 30}deg)` 
            }}
          />
        ))}

        {/* Digital Time Overlay */}
        <div className="absolute bottom-10 left-0 right-0 text-center">
          <span className="text-sm font-black italic tracking-widest text-primary/60">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-[0.2em] italic mt-4 opacity-60">Nightlight Rhythm</p>
    </div>
  );
}

export function Home() {
  const navigate = useNavigate();
  const { points, addPoints, lumaLevel, isTalkUnlocked } = useRewards();
  
  // Load user's preferred display name from localStorage
  const [userName, setUserName] = useState(() => {
    return localStorage.getItem("nightlight_display_name") || "";
  });

  // Time-specific greeting that updates every minute
  const [greeting, setGreeting] = useState(() => getTimeGreeting());

  useEffect(() => {
    const interval = setInterval(() => {
      setGreeting(getTimeGreeting());
      // Also refresh name in case it was changed in Settings
      setUserName(localStorage.getItem("nightlight_display_name") || "");
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  // Microphone permission state
  const [micPermission, setMicPermission] = useState<"prompt" | "granted" | "denied">(() => {
    const saved = localStorage.getItem("nightlight_mic_permission");
    return (saved as any) || "prompt";
  });

  const requestMicPermission = () => {
    // Mocking the permission request
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1500)),
      {
        loading: "Requesting microphone access...",
        success: () => {
          setMicPermission("granted");
          localStorage.setItem("nightlight_mic_permission", "granted");
          return "Microphone access granted for sleep talking recording! 🎙️";
        },
        error: "Permission denied",
      }
    );
  };

  // Medication and Appointment Reminders (Mocked from health profile)
  const healthReminders = useMemo(() => {
    return [
      { id: "med1", title: "Take Melatonin (5mg)", time: "9:30 PM", type: "medicine", hour: 21, minute: 30 },
      { id: "med2", title: "Take Magnesium (200mg)", time: "8:00 PM", type: "medicine", hour: 20, minute: 0 },
      { id: "app1", title: "Sleep Clinic Follow-up", date: "Mar 10", time: "10:30 AM", type: "appointment" }
    ];
  }, []);

  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      healthReminders.forEach(rem => {
        if (rem.type === "medicine" && rem.hour === now.getHours() && rem.minute === now.getMinutes()) {
          toast.info(`Time to take your ${rem.title}!`, {
            icon: "💊",
            description: "Consistency is key for better sleep rhythms.",
            id: rem.id
          });
        }
      });
    };

    const interval = setInterval(checkReminders, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [healthReminders]);

  // Daily wisdom (fun fact)
  const [dailyWisdom] = useState(getDailyWisdom());
  const [showWisdom, setShowWisdom] = useState(true);

  // Mock data for user profile
  const [profile, setProfile] = useState<UserProfile>({
    age: 19,
    healthConditions: ["Insomnia"],
    workLifestyle: "Student / Office Work"
  });

  // Track if user logged in today
  const [hasLoggedToday, setHasLoggedToday] = useState(false);
  const [showReminder, setShowReminder] = useState(true);

  // Daily context state
  const [dailyData, setDailyData] = useState<DailySleepInput>({
    hoursSlept: 6,
    screenTime: 6,
    anxietyLevel: 5,
    moodLevel: 7,
    exerciseMinutes: 10,
    lateCaffeine: true,
    nightmare: true
  });

  const sleepNeeded = calculateSleepRecommendation(profile, dailyData);
  const screenLimit = calculateScreenLimit(dailyData, sleepNeeded);
  const nightmareRisk = calculateNightmareRisk(dailyData);
  const suggestions = generateSuggestions(profile, dailyData, sleepNeeded, nightmareRisk);

  // Interaction state for the cat
  const [isPetting, setIsPetting] = useState(false);
  const [isForcedSleep, setIsForcedSleep] = useState(false);

  const handlePetCat = () => {
    if (isPetting) return; // Prevent spamming while animation is active
    
    setIsPetting(true);
    const petPoints = 5;
    addPoints(petPoints, "Petted Luma");
    
    if (isTalkUnlocked) {
      toast.success("Luma says: '*Purrr*... That feels so good, meow!'", { icon: "💬", id: "luma-pet" });
    } else {
      toast.success("Luma meows happily! *Purrr*", { icon: "", id: "luma-pet" });
    }
    
    // Slightly boost mood if it's not already maxed (visual feedback only for this session)
    if (dailyData.moodLevel < 10) {
      setDailyData(prev => ({ ...prev, moodLevel: Math.min(10, prev.moodLevel + 0.1) }));
    }
    
    setTimeout(() => setIsPetting(false), 2000);
  };

  const toggleCatSleep = () => {
    setIsForcedSleep(!isForcedSleep);
    if (!isForcedSleep) {
      if (isTalkUnlocked) {
        toast.info("Luma says: 'I'm so sleepy... Goodnight!'", { icon: "💬" });
      } else {
        toast.info("Luma is drifting off to sleep...");
      }
    } else {
      if (isTalkUnlocked) {
        toast.info("Luma says: 'I'm awake! Ready to help you!'", { icon: "💬" });
      } else {
        toast.info("Luma is waking up!");
      }
    }
  };

  // Determine cat state based on mood, sleep debt, and forced sleep
  const catState = useMemo(() => {
    if (isForcedSleep) return "exhausted"; // Use exhausted visuals for deep sleep
    if (dailyData.moodLevel <= 3 || dailyData.hoursSlept < 5) return "exhausted";
    if (dailyData.moodLevel <= 6 || dailyData.hoursSlept < 7) return "sleepy";
    return "happy";
  }, [dailyData.moodLevel, dailyData.hoursSlept, isForcedSleep]);

  return (
    <div className="flex flex-col gap-8 pb-12">
      {/* Missing Log Reminder */}
      <AnimatePresence>
        {!hasLoggedToday && showReminder && (
          <motion.div 
            initial={{ opacity: 0, height: 0, marginBottom: 0 }}
            animate={{ opacity: 1, height: "auto", marginBottom: 32 }}
            exit={{ opacity: 0, height: 0, marginBottom: 0 }}
            className="bg-amber-400/10 border-2 border-amber-400/20 rounded-3xl p-5 relative overflow-hidden group shadow-[0_10px_30px_rgba(251,191,36,0.1)]"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-amber-400 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg">
                <Bell className="w-6 h-6 animate-ring" />
              </div>
              <div className="flex-1 flex flex-col gap-1">
                <h3 className="text-lg font-bold text-foreground tracking-tight leading-none italic">Missing Sleep Log</h3>
                <p className="text-xs text-amber-600/80 font-bold uppercase tracking-widest leading-none mt-1 italic">Personalization is currently less accurate.</p>
                <button 
                  onClick={() => navigate("/journal")}
                  className="mt-3 bg-amber-400 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest italic w-fit transition-all hover:scale-105 active:scale-95"
                >
                  Enter Log Now
                </button>
              </div>
              <button 
                onClick={() => setShowReminder(false)}
                className="text-amber-600/40 hover:text-amber-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="flex justify-between items-center px-1">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic">
            {greeting}{userName ? `, ${userName}` : ""}
          </h1>
          <p className="text-muted-foreground mt-1 text-sm font-normal leading-relaxed">
            {getTimeSubtitle()}
          </p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => navigate("/therapists")}
            className="p-3 bg-red-500/10 text-red-500 rounded-full border border-red-500/20 transition-all hover:bg-red-500/20 active:scale-95 shadow-sm"
          >
            <Phone className="w-5 h-5" />
          </button>
          <button 
            onClick={() => navigate("/notifications")}
            className="p-3 bg-card rounded-full border border-border transition-all hover:bg-border/20 active:scale-95 relative"
          >
            <Bell className="w-5 h-5 text-muted-foreground" />
            <div className="absolute top-2.5 right-2.5 w-2 h-2 bg-primary rounded-full animate-pulse shadow-[0_0_10px_rgba(167,139,250,0.5)]" />
          </button>
          <button 
            onClick={() => navigate("/settings")}
            className="p-3 bg-card rounded-full border border-border transition-all hover:bg-border/20 active:scale-95"
          >
            <Settings className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </header>

      {/* Big Round Clock */}
      <BigClock />

      {/* Graphs Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DailySleepGraph />
        <MoodFrequencyGraph />
      </section>

      {/* Sleepy Cat Dashboard Buddy */}
      <section className="bg-card border-2 border-primary/10 rounded-[2.5rem] p-6 flex items-center justify-between relative overflow-hidden group">
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
        <div className="flex flex-col gap-3 relative z-10">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-primary uppercase tracking-widest italic">
                {lumaLevel === "kitten" ? "Baby Kitten" : lumaLevel === "young" ? "Young Cat" : "Big Cat"} Luma
              </span>
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
            </div>
            <h3 className="text-xl font-black italic uppercase tracking-tighter">
              {isForcedSleep ? "Luma is fast asleep" : catState === "exhausted" ? "Luma is passed out" : catState === "sleepy" ? "Luma is napping" : "Luma is wide awake"}
            </h3>
            <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic mt-1">
              Reflecting your current energy & mood
            </p>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={handlePetCat}
              className="px-3 py-1.5 bg-primary/10 text-primary border border-primary/20 rounded-full text-[8px] font-black uppercase tracking-widest italic hover:bg-primary/20 transition-all active:scale-95 flex items-center gap-1.5"
            >
              <Heart className="w-3 h-3 fill-current" />
              Pet Luma
            </button>
            <button 
              onClick={toggleCatSleep}
              className={cn(
                "px-3 py-1.5 border rounded-full text-[8px] font-black uppercase tracking-widest italic transition-all active:scale-95 flex items-center gap-1.5",
                isForcedSleep 
                  ? "bg-amber-400/10 text-amber-500 border-amber-400/20" 
                  : "bg-background border-border text-muted-foreground hover:bg-muted"
              )}
            >
              <Moon className="w-3 h-3 fill-current" />
              {isForcedSleep ? "Wake Up" : "Put to Sleep"}
            </button>
          </div>
        </div>
        
        <div 
          onMouseEnter={handlePetCat}
          className="relative w-28 h-28 flex items-center justify-center shrink-0 z-10 cursor-pointer"
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={isPetting ? "petting" : catState}
              initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
              animate={{ 
                opacity: 1, 
                scale: (lumaLevel === "kitten" ? 0.8 : lumaLevel === "young" ? 1.1 : 1.4) * (isPetting ? 1.1 : 1), 
                rotate: isPetting ? [0, 5, -5, 0] : 0 
              }}
              exit={{ opacity: 0, scale: 0.8, rotate: 10 }}
              className="relative w-full h-full flex items-center justify-center"
            >
              <CatSVG state={isPetting ? "happy" : catState} variant={lumaLevel} />
              <AnimatePresence>
                {isPetting && (
                  <>
                    <motion.div
                      initial={{ opacity: 0, y: 10, x: 0, scale: 0.5 }}
                      animate={{ opacity: 1, y: -50, x: -20, scale: 1.2 }}
                      exit={{ opacity: 0, y: -70, scale: 1.5 }}
                      className="absolute inset-0 flex items-center justify-center pointer-events-none"
                    >
                      <Heart className="w-6 h-6 text-primary fill-current shadow-lg" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10, x: 0, scale: 0.5 }}
                      animate={{ opacity: 1, y: -60, x: 20, scale: 1.2 }}
                      exit={{ opacity: 0, y: -80, scale: 1.5 }}
                      className="absolute inset-0 flex items-center justify-center pointer-events-none"
                    >
                      <Heart className="w-4 h-4 text-primary fill-current shadow-lg" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10, x: 0, scale: 0.5 }}
                      animate={{ opacity: 1, y: -40, x: 0, scale: 1.5 }}
                      exit={{ opacity: 0, y: -60, scale: 1.8 }}
                      className="absolute inset-0 flex items-center justify-center pointer-events-none"
                    >
                      <Heart className="w-8 h-8 text-primary fill-current shadow-lg" />
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
              {isTalkUnlocked && !isForcedSleep && (
                <div className="absolute -top-6 -right-6 bg-primary text-primary-foreground text-[8px] font-black uppercase px-2 py-1 rounded-full animate-bounce shadow-lg flex items-center gap-1">
                  <MessageSquare className="w-2 h-2" />
                  Can Talk!
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* Daily Wisdom Banner */}
      <AnimatePresence>
        {showWisdom && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-primary/10 border-2 border-primary/20 rounded-[2.5rem] p-6 relative overflow-hidden group shadow-[0_20px_40px_rgba(167,139,250,0.1)]"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              <Sparkles className="w-12 h-12 text-primary" />
            </div>
            <div className="flex flex-col gap-3 relative z-10">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-[8px] font-black uppercase tracking-widest italic">
                    {dailyWisdom.type === 'fact' ? '💡 Fun Fact' : '🧠 Healthy Tip'}
                  </div>
                  <span className="text-[10px] text-primary/60 font-bold uppercase tracking-widest italic">{dailyWisdom.category}</span>
                </div>
                <button 
                  onClick={() => setShowWisdom(false)}
                  className="text-primary/40 hover:text-primary transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm font-bold text-foreground italic leading-relaxed">
                "{dailyWisdom.text}"
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Microphone Permission Request */}
      <AnimatePresence>
        {micPermission === "prompt" && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-primary/10 border-2 border-primary/20 rounded-3xl p-5 mb-8 relative overflow-hidden group shadow-[0_10px_30px_rgba(167,139,250,0.1)]"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-primary-foreground shrink-0 shadow-lg">
                <Mic className="w-6 h-6" />
              </div>
              <div className="flex-1 flex flex-col gap-1">
                <h3 className="text-lg font-bold text-foreground tracking-tight leading-none italic">Record Sleep Talking</h3>
                <p className="text-[10px] text-primary/80 font-bold uppercase tracking-widest leading-none mt-1 italic">Detect sleep-talking & night sounds.</p>
                <div className="flex gap-3 mt-3">
                  <button 
                    onClick={requestMicPermission}
                    className="bg-primary text-primary-foreground px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest italic transition-all hover:scale-105 active:scale-95"
                  >
                    Enable Mic
                  </button>
                  <button 
                    onClick={() => {
                      setMicPermission("denied");
                      localStorage.setItem("nightlight_mic_permission", "denied");
                    }}
                    className="text-muted-foreground/60 hover:text-muted-foreground px-2 py-2 text-[10px] font-black uppercase tracking-widest italic transition-all"
                  >
                    Maybe Later
                  </button>
                </div>
              </div>
              <Info className="w-5 h-5 text-primary/40 mt-1 cursor-help" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Health Reminders (Meds & Appointments) */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest italic">Health Reminders</h3>
          <button 
            onClick={() => navigate("/health-profile")}
            className="text-[10px] font-black text-primary uppercase tracking-widest italic hover:underline"
          >
            Manage health
          </button>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {healthReminders.map((rem) => (
            <motion.div 
              key={rem.id}
              whileHover={{ scale: 1.01 }}
              className={cn(
                "p-4 rounded-3xl border flex items-center gap-4 transition-all",
                rem.type === "medicine" ? "bg-amber-400/5 border-amber-400/20" : "bg-blue-500/5 border-blue-500/20"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm",
                rem.type === "medicine" ? "bg-amber-400/10 text-amber-500" : "bg-blue-500/10 text-blue-500"
              )}>
                {rem.type === "medicine" ? <Clock className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
              </div>
              <div className="flex-1 flex flex-col gap-0.5">
                <span className="text-sm font-bold italic tracking-tight">{rem.title}</span>
                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic opacity-60">
                  {rem.type === "medicine" ? `Due @ ${rem.time}` : `${rem.date} @ ${rem.time}`}
                </span>
              </div>
              <div className="px-2 py-1 bg-background/50 rounded-lg text-[8px] font-black text-muted-foreground uppercase tracking-widest italic">
                {rem.type === "medicine" ? "Medication" : "Appointment"}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Prediction Dashboard */}
      <section className="bg-card border-2 border-primary/20 rounded-[2.5rem] p-8 relative overflow-hidden shadow-[0_0_50px_rgba(167,139,250,0.1)]">
        <div className="absolute top-0 right-0 p-6 opacity-5">
          <Brain className="w-20 h-20 text-primary" />
        </div>
        
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-start">
            <div className="flex flex-col gap-1">
              <h3 className="text-sm font-bold text-primary uppercase tracking-widest leading-none">AI Predictions</h3>
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest leading-none italic mt-1">Tomorrow's Targets</p>
            </div>
            <div className="bg-primary/10 px-3 py-1.5 rounded-full flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
              <span className="text-[10px] font-bold text-primary uppercase tracking-widest leading-none italic">Calibrating</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="flex flex-col gap-2">
              <div className="w-10 h-10 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-1">
                <Moon className="w-5 h-5" />
              </div>
              <span className="text-3xl font-bold tracking-tight leading-none italic">{sleepNeeded}h</span>
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest leading-none italic">Sleep Goal</span>
            </div>
            <div className="flex flex-col gap-2">
              <div className="w-10 h-10 bg-secondary/10 rounded-2xl flex items-center justify-center text-secondary mb-1">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span className="text-3xl font-bold tracking-tight leading-none italic">{screenLimit}h</span>
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest leading-none italic">Screen Limit</span>
            </div>
          </div>

          <div className="bg-background/40 border border-border/50 p-4 rounded-2xl flex items-start gap-3">
            <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground font-normal leading-relaxed italic">
              "Your high anxiety today increased your sleep requirement by 30 mins."
            </p>
          </div>

          {/* Reward Points Badge */}
          <div className="flex items-center justify-between mt-2 pt-4 border-t border-border/20">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-amber-400/10 rounded-lg flex items-center justify-center text-amber-500">
                <Star className="w-4 h-4 fill-current" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic leading-none">Total Reward Points</span>
                <span className="text-lg font-black italic tracking-tighter text-foreground leading-none mt-1">{points} PTS</span>
              </div>
            </div>
            <button
              onClick={() => {
                const daily = calculateDailyPoints(dailyData, sleepNeeded, screenLimit);
                addPoints(daily, "Daily Goals Achieved");
              }}
              className="px-4 py-2 bg-primary/20 text-primary border border-primary/30 rounded-xl text-[8px] font-black uppercase tracking-widest italic hover:bg-primary hover:text-primary-foreground transition-all active:scale-95"
            >
              Claim Today's Points
            </button>
          </div>
        </div>
      </section>

      {/* Main CTA: Nightmare Support */}
      <div className="grid grid-cols-2 gap-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/nightmare")}
          className="w-full h-32 bg-background border-2 border-primary/20 rounded-[2.5rem] flex flex-col items-center justify-center gap-3 shadow-[0_0_40px_rgba(167,139,250,0.15)] relative overflow-hidden group transition-all duration-500 hover:border-primary/40"
        >
          <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-500 shadow-[0_0_20px_rgba(167,139,250,0.2)]">
            <Moon className="w-6 h-6 fill-current" />
          </div>
          <span className="text-sm font-bold text-foreground tracking-tight leading-none italic">
            Nightmare
          </span>
          <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest leading-none italic">
            Emergency
          </p>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/kids-mode")}
          className="w-full h-32 bg-pink-500/5 border-2 border-pink-500/20 rounded-[2.5rem] flex flex-col items-center justify-center gap-3 shadow-[0_0_40px_rgba(236,72,153,0.1)] relative overflow-hidden group transition-all duration-500 hover:border-pink-500/40"
        >
          <div className="absolute inset-0 bg-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="w-12 h-12 bg-pink-500/10 rounded-full flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform duration-500 shadow-[0_0_20px_rgba(236,72,153,0.2)]">
            <Heart className="w-6 h-6 fill-current" />
          </div>
          <span className="text-sm font-bold text-foreground tracking-tight leading-none italic">
            Baby Sleep
          </span>
          <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest leading-none italic">
            Lullabies & TV
          </p>
          <div className="absolute -bottom-2 -right-2 opacity-10 group-hover:opacity-20 transition-opacity">
             <Star className="w-16 h-16 text-yellow-400 fill-current rotate-12" />
          </div>
        </motion.button>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-2 gap-4">
        <QuickAction 
          icon={<Plus className="w-5 h-5" />} 
          label="Log Sleep" 
          onClick={() => navigate("/journal")}
          color="bg-secondary/10 text-secondary"
        />
        <QuickAction 
          icon={<Play className="w-5 h-5" />} 
          label="Wind Down" 
          onClick={() => navigate("/wind-down")}
          color="bg-primary/10 text-primary"
        />
        <QuickAction 
          icon={<Cat className="w-5 h-5" />} 
          label="Chat with Luma" 
          onClick={() => navigate("/chatbot")}
          color="bg-purple-500/10 text-purple-400"
        />
        <QuickAction 
          icon={<Heart className="w-5 h-5" />} 
          label="Community" 
          onClick={() => navigate("/community")}
          color="bg-red-500/10 text-red-400"
        />
      </div>

      {/* Emergency Contact Shortcut */}
      <section className="bg-red-500/5 border-2 border-dashed border-red-500/20 p-6 rounded-[2.5rem] flex items-center justify-between group cursor-pointer hover:bg-red-500/10 transition-all active:scale-98"
        onClick={() => navigate("/health-profile")}
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 shadow-sm group-hover:scale-110 transition-transform">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-foreground tracking-tight leading-none italic">Emergency Contact</h3>
            <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic">Setup family alert system</p>
          </div>
        </div>
        <Plus className="w-4 h-4 text-red-500 transition-transform group-hover:rotate-90" />
      </section>

      {/* Mood & Anxiety Check (Mini version) */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-6">
        <div className="flex justify-between items-center px-1">
          <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest leading-none italic">Daily Mood</h3>
          <span className="text-2xl font-bold leading-none">{dailyData.moodLevel <= 3 ? "😢" : dailyData.moodLevel <= 7 ? "😐" : "😌"}</span>
        </div>
        <Slider.Root
          className="relative flex items-center select-none touch-none w-full h-5"
          value={[dailyData.moodLevel]}
          max={10}
          min={1}
          step={1}
          onValueChange={(v) => setDailyData({...dailyData, moodLevel: v[0]})}
        >
          <Slider.Track className="bg-border/20 relative grow rounded-full h-1.5 overflow-hidden">
            <Slider.Range className="absolute bg-primary rounded-full h-full" />
          </Slider.Track>
          <Slider.Thumb className="block w-6 h-6 bg-primary shadow-lg rounded-full hover:scale-110 focus:outline-none transition-transform cursor-grab active:cursor-grabbing border-4 border-card" />
        </Slider.Root>
      </section>

      {/* Lifestyle Suggestions */}
      <section className="flex flex-col gap-4">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">Personalized Plan</h3>
        <div className="flex flex-col gap-3">
          {suggestions.slice(0, 2).map((s, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-card border border-border p-4 rounded-3xl flex items-center gap-4 group hover:bg-border/20 transition-all"
            >
              <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0 group-hover:rotate-6 transition-transform">
                <Sparkles className="w-4 h-4" />
              </div>
              <p className="text-xs font-semibold text-foreground italic leading-relaxed">{s}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}

function QuickAction({ icon, label, onClick, color }: { icon: React.ReactNode; label: string; onClick: () => void; color: string }) {
  return (
    <button
      onClick={onClick}
      className="bg-card border border-border p-5 rounded-[2rem] flex flex-col items-center gap-3 transition-all hover:bg-border/20 active:scale-95 text-center group"
    >
      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300 shadow-sm", color)}>
        {icon}
      </div>
      <span className="text-[10px] font-bold text-foreground tracking-widest leading-none italic uppercase">{label}</span>
    </button>
  );
}

function CatSVG({ state, variant = "kitten" }: { state: "exhausted" | "sleepy" | "happy", variant?: "kitten" | "young" | "big" }) {
  const isBig = variant === "big";
  const isYoung = variant === "young";
  
  return (
    <svg viewBox="0 0 100 100" className="w-full h-full text-foreground fill-current">
      {/* Whiskers for grown cat */}
      {(isBig || isYoung) && (
        <g stroke="currentColor" strokeWidth="0.5" opacity="0.6">
          <line x1="15" y1="50" x2="30" y2="52" />
          <line x1="15" y1="55" x2="30" y2="55" />
          <line x1="85" y1="50" x2="70" y2="52" />
          <line x1="85" y1="55" x2="70" y2="55" />
        </g>
      )}

      {/* Ears */}
      <motion.path 
        d="M20,30 L35,10 L45,30 Z" 
        animate={state === 'happy' ? { rotate: [0, -5, 0] } : { rotate: 0 }}
        transition={{ duration: 2, repeat: Infinity }}
        className="text-primary/40" 
      />
      <motion.path 
        d="M80,30 L65,10 L55,30 Z" 
        animate={state === 'happy' ? { rotate: [0, 5, 0] } : { rotate: 0 }}
        transition={{ duration: 2, repeat: Infinity, delay: 0.1 }}
        className="text-primary/40" 
      />
      
      {/* Face - Size increases with growth */}
      <circle cx="50" cy="50" r={isBig ? 42 : isYoung ? 38 : 35} className="fill-card stroke-primary/20" strokeWidth="1" />
      
      {/* Eyes */}
      {state === "exhausted" ? (
        <>
          <path d="M35,45 L45,45" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M55,45 L65,45" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </>
      ) : state === "sleepy" ? (
        <>
          <path d="M35,48 Q40,43 45,48" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M55,48 Q60,43 65,48" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </>
      ) : (
        <>
          <motion.circle 
            cx="40" cy="45" r={isBig ? 4 : 3} 
            animate={{ scaleY: [1, 0.1, 1] }} 
            transition={{ duration: 3, repeat: Infinity, times: [0, 0.1, 0.2] }}
          />
          <motion.circle 
            cx="60" cy="45" r={isBig ? 4 : 3} 
            animate={{ scaleY: [1, 0.1, 1] }} 
            transition={{ duration: 3, repeat: Infinity, times: [0, 0.1, 0.2], delay: 0.1 }}
          />
        </>
      )}

      {/* Nose */}
      <circle cx="50" cy="53" r={isBig ? 2 : 1.5} className="text-pink-400" />

      {/* Mouth */}
      {state === "happy" ? (
        <path d="M45,58 Q50,63 55,58" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      ) : (
        <path d="M48,58 L52,58" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      )}

      {/* Tail */}
      <motion.path 
        d="M85,50 Q95,40 90,30" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth={isBig ? 5 : isYoung ? 4 : 3} 
        strokeLinecap="round"
        initial={{ rotate: 0, x: 0, opacity: 1 }}
        animate={state === 'happy' ? { rotate: [0, 10, 0], x: [0, 5, 0], opacity: 1 } : { rotate: 0, x: 0, opacity: 0.5 }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      
      {/* Zzz for sleepy cat */}
      {(state === "exhausted" || state === "sleepy") && (
        <motion.text
          x="75" y="25"
          className="text-[10px] font-bold fill-primary/40 select-none pointer-events-none"
          initial={{ opacity: 0, y: 25, x: 75 }}
          animate={{ opacity: [0, 1, 0], y: [25, 15], x: [75, 80] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          Z
        </motion.text>
      )}
    </svg>
  );
}

function getTimeGreeting() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return "Good Morning";
  if (hour >= 12 && hour < 17) return "Good Afternoon";
  if (hour >= 17 && hour < 21) return "Good Evening";
  return "Good Night";
}

function getTimeSubtitle() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return "Start your day refreshed and energized.";
  if (hour >= 12 && hour < 17) return "Remember to wind down as the day goes on.";
  if (hour >= 17 && hour < 21) return "Time to start your bedtime routine.";
  return "Sweet dreams — Luma is here with you.";
}