import React, { useState, useEffect, useContext } from "react";
import { toast } from "sonner";
import { calculateDailyPoints, analyzeJournalForRewards } from "./lib/sleep-logic";
import { Sparkles, Star, Heart, X } from "lucide-react";
import { RewardContext } from "./RewardContext";

export function RewardProvider({ children }: { children: React.ReactNode }) {
  const [points, setPoints] = useState(() => {
    if (typeof window === "undefined") return 0;
    const saved = localStorage.getItem("nightlight_points");
    return saved ? parseInt(saved, 10) : 0;
  });
  
  const [showCelebration, setShowCelebration] = useState(false);
  const [completedRituals, setCompletedRituals] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    const saved = localStorage.getItem("nightlight_rituals");
    return saved ? JSON.parse(saved) : [];
  });

  const lumaLevel = points > 500 ? "big" : points > 200 ? "young" : "kitten";
  const isTalkUnlocked = points >= 750;

  useEffect(() => {
    localStorage.setItem("nightlight_points", points.toString());
  }, [points]);

  useEffect(() => {
    localStorage.setItem("nightlight_rituals", JSON.stringify(completedRituals));
  }, [completedRituals]);

  const addPoints = (amount: number, reason: string) => {
    setPoints(prev => {
      const newPoints = prev + amount;
      if (Math.floor(newPoints / 100) > Math.floor(prev / 100)) {
        setShowCelebration(true);
      }
      
      // Evolution notifications
      if (prev <= 200 && newPoints > 200) {
        toast.success("Luma has grown into a Young Cat!", { icon: "🐱" });
      }
      if (prev <= 500 && newPoints > 500) {
        toast.success("Luma is now a Big Cat!", { icon: "🐈" });
      }
      if (prev < 750 && newPoints >= 750) {
        toast.success("Luma learned to talk!", { icon: "💬" });
      }
      
      return newPoints;
    });
    
    if (amount > 0) {
      const isBonus = reason.toLowerCase().includes("positive") || reason.toLowerCase().includes("mindset");
      
      toast.success(isBonus ? "We love to see it!" : `+${amount} points: ${reason}`, {
        icon: isBonus ? "✨" : "🏆",
        description: isBonus ? `You earned ${amount} bonus points for that positive update!` : `Keep up the great work!`
      });
    }
  };

  const completeRitual = (id: string) => {
    if (!completedRituals.includes(id)) {
      setCompletedRituals(prev => [...prev, id]);
      addPoints(20, `${id.charAt(0).toUpperCase() + id.slice(1)} Completed`);
    }
  };

  const processJournalEntry = (text: string) => {
    const analysis = analyzeJournalForRewards(text);
    if (analysis) {
      addPoints(analysis.bonus, "Positive Journaling");
    }
    completeRitual("journal");
  };

  return (
    <RewardContext.Provider value={{ 
      points, 
      addPoints, 
      processJournalEntry, 
      showCelebration, 
      setShowCelebration,
      completedRituals,
      completeRitual,
      lumaLevel,
      isTalkUnlocked
    }}>
      {children}
      <SleepyCatCelebrationOverlay />
    </RewardContext.Provider>
  );
}

function SleepyCatCelebrationOverlay() {
  const context = useContext(RewardContext);
  if (!context) return null;
  const { showCelebration, setShowCelebration, points } = context;

  if (!showCelebration) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-sm px-6"
    >
      <div
        className="bg-card border-4 border-primary/20 rounded-[3rem] p-10 flex flex-col items-center gap-6 relative shadow-[0_20px_50px_rgba(167,139,250,0.3)] max-w-sm w-full"
      >
        <button 
          onClick={() => setShowCelebration(false)}
          className="absolute top-6 right-6 p-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-[3rem]">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute"
              style={{
                left: `${50 + (Math.random() * 40 - 20)}%`,
                top: `${50 + (Math.random() * 40 - 20)}%`
              }}
            >
              <Sparkles className="w-8 h-8 text-primary/40 fill-current" />
            </div>
          ))}
        </div>

        <div className="relative w-40 h-40 flex items-center justify-center">
          <svg viewBox="0 0 100 100" className="w-full h-full text-foreground fill-current">
            <path d="M20,30 L35,10 L45,30 Z" className="text-muted-foreground/20" />
            <path d="M80,30 L65,10 L55,30 Z" className="text-muted-foreground/20" />
            <circle cx="50" cy="50" r="35" className="fill-card border border-border" />
            <path d="M35,45 Q40,40 45,45" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <path d="M55,45 Q60,40 65,45" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            <circle cx="50" cy="53" r="2" fill="currentColor" />
            <path 
              d="M25,70 Q20,60 30,55" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="6" 
              strokeLinecap="round" 
            />
            <path 
              d="M75,70 Q80,60 70,55" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="6" 
              strokeLinecap="round" 
            />
          </svg>
          
          <div className="absolute -top-4 -right-2 text-primary">
            <Star className="w-8 h-8 fill-current" />
          </div>
          <div className="absolute -bottom-2 -left-4 text-pink-400">
            <Heart className="w-6 h-6 fill-current" />
          </div>
        </div>

        <div className="flex flex-col items-center gap-2 text-center">
          <h2 className="text-2xl font-black italic uppercase tracking-widest text-primary">Milestone Reached!</h2>
          <p className="text-sm font-bold text-muted-foreground italic leading-relaxed uppercase tracking-wider">
            You've earned <span className="text-foreground">{points}</span> points.
            The Sleepy Cat is so proud of you!
          </p>
        </div>

        <button 
          onClick={() => setShowCelebration(false)}
          className="mt-4 w-full h-14 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl shadow-lg active:scale-95 transition-all"
        >
          Keep it up!
        </button>
      </div>
    </div>
  );
}

export default RewardProvider;
