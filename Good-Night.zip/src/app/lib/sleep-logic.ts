export interface DailySleepInput {
  hoursSlept: number;
  screenTime: number;
  anxietyLevel: number;
  moodLevel: number;
  exerciseMinutes: number;
  lateCaffeine: boolean;
  nightmare: boolean;
}

export interface UserProfile {
  age: number;
  healthConditions: string[];
  workLifestyle: string;
}

export function calculateSleepRecommendation(profile: UserProfile, data: DailySleepInput) {
  let baseSleep = 8;

  if (profile.age < 18) baseSleep = 9;
  else if (profile.age > 25 && profile.age < 65) baseSleep = 8;
  else if (profile.age >= 65) baseSleep = 7;

  let adjustment = 0;

  // Sleep debt recovery
  if (data.hoursSlept < 6) adjustment += 1;
  
  // Anxiety increases need for rest
  if (data.anxietyLevel > 7) adjustment += 0.5;
  
  // Excessive screen time delays melatonin
  if (data.screenTime > 6) adjustment += 0.5;
  
  // Nightmare recovery
  if (data.nightmare) adjustment += 0.75;
  
  // Late caffeine affects depth
  if (data.lateCaffeine) adjustment += 0.5;
  
  // Exercise reduces need/improves quality
  if (data.exerciseMinutes >= 30) adjustment -= 0.25;

  // Conditions
  if (profile.healthConditions.includes("Insomnia")) adjustment += 0.5;
  if (profile.healthConditions.includes("Pregnancy")) adjustment += 1;

  return parseFloat((baseSleep + adjustment).toFixed(1));
}

export function calculateScreenLimit(data: DailySleepInput, sleepNeeded: number) {
  // Base allowed is 6 hours for a healthy student
  let baseAllowed = 6;
  
  const sleepRatio = data.hoursSlept / sleepNeeded;
  let allowed = baseAllowed * sleepRatio;

  // Reduce if anxiety is high
  if (data.anxietyLevel > 7) allowed -= 1;
  
  // Cap at 8, minimum 1 (essential only)
  return Math.min(Math.max(parseFloat(allowed.toFixed(1)), 1), 8);
}

export function calculateNightmareRisk(data: DailySleepInput) {
  let risk = 0;

  if (data.anxietyLevel > 7) risk += 0.4;
  if (data.screenTime > 6) risk += 0.2;
  if (data.lateCaffeine) risk += 0.2;
  if (data.hoursSlept < 6) risk += 0.2;

  return Math.min(risk, 1);
}

export function generateSuggestions(profile: UserProfile, data: DailySleepInput, sleepNeeded: number, nightmareRisk: number) {
  const suggestions: string[] = [];

  if (data.hoursSlept < sleepNeeded) {
    suggestions.push("You're in a sleep debt. Avoid caffeine after 2 PM today.");
    suggestions.push("Try to start your wind-down routine 1 hour earlier than usual.");
  }

  if (data.anxietyLevel > 7) {
    suggestions.push("Your mind seems busy. Try Luma's guided breathing for 5 minutes.");
    suggestions.push("High anxiety can trigger vivid dreams; journaling your worries might help.");
  }

  if (nightmareRisk > 0.6) {
    suggestions.push("Your nightmare risk is elevated. Avoid intense media or news before bed.");
    suggestions.push("Try Imagery Rehearsal: rewrite a positive ending to a recent dream.");
  }

  if (data.exerciseMinutes < 20) {
    suggestions.push("A quick 20-minute walk in daylight can help reset your circadian rhythm.");
  }

  if (profile.healthConditions.includes("Pregnancy")) {
    suggestions.push("Try using a pregnancy pillow for better spinal alignment tonight.");
  }

  return suggestions;
}

export function detectMentalState(message: string) {
  const lower = message.toLowerCase();

  if (lower.includes("stress") || lower.includes("exam") || lower.includes("work"))
    return "Performance Stress";

  if (lower.includes("lonely") || lower.includes("sad") || lower.includes("alone"))
    return "Emotional Isolation";

  if (lower.includes("can't sleep") || lower.includes("awake") || lower.includes("tired"))
    return "Sleep-Onset Anxiety";

  if (lower.includes("nightmare") || lower.includes("scared") || lower.includes("dream"))
    return "Parasomnia Distress";

  return "General Anxiety";
}

export function getDailyWisdom() {
  const wisdom = [
    { type: "fact", text: "Humans are the only mammals that willingly delay sleep, often ignoring their biological clocks.", category: "Biology" },
    { type: "tip", text: "Sleeping on your left side can help with digestion and reduce acid reflux during the night.", category: "Health" },
    { type: "fact", text: "17 hours of sustained wakefulness leads to a performance decrease equal to a blood alcohol level of 0.05%.", category: "Science" },
    { type: "fact", text: "Your brain is actually more active during REM sleep than it is while you are awake.", category: "Neurology" },
    { type: "tip", text: "The '20-20-20 rule': every 20 minutes, look at something 20 feet away for 20 seconds to reduce eye strain.", category: "Wellness" },
    { type: "fact", text: "The average person spends about 26 years of their life sleeping and 7 years trying to get to sleep.", category: "Lifestyle" },
    { type: "tip", text: "A 'power nap' should be exactly 20 minutes; any longer and you might wake up feeling groggy.", category: "Performance" },
    { type: "fact", text: "Blue light from phones mimics sunlight and can suppress melatonin production for up to 3 hours.", category: "Technology" },
    { type: "tip", text: "The ideal room temperature for deep sleep is surprisingly cool—around 65°F (18.3°C).", category: "Environment" },
    { type: "tip", text: "Vitamin D is essential for sleep regulation—try to get at least 15 minutes of direct sunlight daily.", category: "Nutrition" },
    { type: "fact", text: "Most dreams are forgotten within just 10 minutes of waking up unless they are recorded immediately.", category: "Psychology" },
    { type: "tip", text: "Regular exercise improves sleep quality, but avoid high-intensity workouts within 3 hours of bedtime.", category: "Fitness" }
  ];
  
  return wisdom[Math.floor(Math.random() * wisdom.length)];
}

export interface RewardPoints {
  total: number;
  level: number;
  streak: number;
  lastUpdate: string;
}

export function calculateDailyPoints(data: DailySleepInput, sleepNeeded: number, screenLimit: number) {
  let points = 0;
  
  // Points for sleep duration
  if (data.hoursSlept >= sleepNeeded) points += 50;
  else if (data.hoursSlept >= sleepNeeded - 1) points += 25;
  
  // Points for screen time discipline
  if (data.screenTime <= screenLimit) points += 40;
  else if (data.screenTime <= screenLimit + 1) points += 15;
  
  // Points for health habits
  if (data.exerciseMinutes >= 30) points += 30;
  if (!data.lateCaffeine) points += 20;
  if (data.moodLevel >= 8) points += 10;
  
  return points;
}

export function analyzeJournalForRewards(note: string) {
  const positiveWords = ["happy", "good", "great", "excellent", "productive", "calm", "peaceful", "better", "accomplished", "love", "joy"];
  const lowerNote = note.toLowerCase();
  
  const matches = positiveWords.filter(word => lowerNote.includes(word));
  
  if (matches.length >= 2) {
    return {
      bonus: 25,
      message: "Your journal shows such a positive mindset today! +25 bonus points."
    };
  }
  
  return null;
}

export function getRecommendedInterests(journalText: string, healthData: any) {
  const interests: string[] = [];
  
  const lowerJournal = journalText.toLowerCase();
  
  if (lowerJournal.includes("nightmare") || lowerJournal.includes("bad dream")) {
    interests.push("Nightmares");
  }
  if (lowerJournal.includes("stress") || lowerJournal.includes("anxiety") || lowerJournal.includes("worried")) {
    interests.push("Stress Management");
  }
  if (lowerJournal.includes("tired") || lowerJournal.includes("exhausted") || (healthData?.hoursSlept < 6)) {
    interests.push("Sleep Optimization");
  }
  if (lowerJournal.includes("noise") || lowerJournal.includes("loud")) {
    interests.push("Ambient Sound");
  }
  if (lowerJournal.includes("breath") || lowerJournal.includes("calm") || lowerJournal.includes("meditation")) {
    interests.push("Breathing Techniques");
  }
  
  return interests;
}
