import { RouterProvider } from "react-router";
import { router } from "./routes";
import { Toaster } from "sonner";
import RewardProvider from "./RewardProvider";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AccountSetup } from "./components/AccountSetup";

// Luma sleeping SVG logo with star background
function LumaLogo({ size = 120 }: { size?: number }) {
  return (
    <svg viewBox="0 0 200 200" width={size} height={size} className="drop-shadow-2xl">
      {/* Background Circle with gradient */}
      <defs>
        <radialGradient id="lumaGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#A78BFA" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#0F1220" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="starGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FBBF24" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#FBBF24" stopOpacity="0" />
        </radialGradient>
      </defs>
      
      {/* Background glow */}
      <circle cx="100" cy="100" r="95" fill="url(#lumaGlow)" />
      
      {/* Star in background */}
      <g transform="translate(145, 35)">
        <circle cx="0" cy="0" r="20" fill="url(#starGlow)" />
        <polygon 
          points="0,-15 4,-5 15,-5 6,2 9,13 0,7 -9,13 -6,2 -15,-5 -4,-5" 
          fill="#FBBF24" 
          opacity="0.9"
        >
          <animateTransform attributeName="transform" type="rotate" values="0;10;0;-10;0" dur="4s" repeatCount="indefinite" />
        </polygon>
      </g>
      
      {/* Small stars */}
      <circle cx="40" cy="45" r="2" fill="#FBBF24" opacity="0.4">
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="3s" repeatCount="indefinite" />
      </circle>
      <circle cx="160" cy="75" r="1.5" fill="#FBBF24" opacity="0.3">
        <animate attributeName="opacity" values="0.3;0.7;0.3" dur="2.5s" repeatCount="indefinite" />
      </circle>
      <circle cx="55" cy="155" r="1.5" fill="#FBBF24" opacity="0.3">
        <animate attributeName="opacity" values="0.1;0.5;0.1" dur="3.5s" repeatCount="indefinite" />
      </circle>
      
      {/* Cat body (curled up sleeping) */}
      <ellipse cx="100" cy="120" rx="55" ry="40" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" opacity="0.9" />
      
      {/* Cat head */}
      <circle cx="75" cy="95" r="30" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      
      {/* Cat ears */}
      <polygon points="52,75 60,50 72,72" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      <polygon points="52,75 60,50 72,72" fill="#A78BFA" opacity="0.15" />
      <polygon points="88,72 80,50 68,75" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      <polygon points="88,72 80,50 68,75" fill="#A78BFA" opacity="0.15" />
      
      {/* Closed eyes (sleeping) */}
      <path d="M62,92 Q67,88 72,92" fill="none" stroke="#A78BFA" strokeWidth="2" strokeLinecap="round" />
      <path d="M78,92 Q83,88 88,92" fill="none" stroke="#A78BFA" strokeWidth="2" strokeLinecap="round" />
      
      {/* Nose */}
      <ellipse cx="75" cy="98" rx="2.5" ry="2" fill="#F9A8D4" />
      
      {/* Tiny smile */}
      <path d="M72,102 Q75,105 78,102" fill="none" stroke="#A78BFA" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
      
      {/* Tail curling around */}
      <path d="M150,110 Q170,95 160,80 Q155,70 148,78" fill="none" stroke="#A78BFA" strokeWidth="4" strokeLinecap="round" opacity="0.7" />
      
      {/* Paws tucked in */}
      <ellipse cx="60" cy="125" rx="8" ry="5" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1" opacity="0.8" />
      <ellipse cx="90" cy="128" rx="8" ry="5" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1" opacity="0.8" />
      
      {/* Zzz */}
      <text x="100" y="68" fill="#A78BFA" opacity="0.5" fontSize="12" fontWeight="bold" fontStyle="italic">
        z
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="2s" repeatCount="indefinite" />
        <animateTransform attributeName="transform" type="translate" values="0,0;5,-8;10,-16" dur="3s" repeatCount="indefinite" />
      </text>
      <text x="112" y="58" fill="#A78BFA" opacity="0.4" fontSize="16" fontWeight="bold" fontStyle="italic">
        z
        <animate attributeName="opacity" values="0.1;0.5;0.1" dur="2.5s" repeatCount="indefinite" />
        <animateTransform attributeName="transform" type="translate" values="0,0;5,-10;10,-20" dur="3.5s" repeatCount="indefinite" />
      </text>
    </svg>
  );
}

// Splash Screen
function SplashScreen({ onFinish }: { onFinish: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onFinish, 3000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[500] bg-[#0F1220] flex flex-col items-center justify-center gap-6"
    >
      {/* Subtle star field background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.6, 0] }}
            transition={{ duration: 2 + Math.random() * 3, repeat: Infinity, delay: Math.random() * 2 }}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
          />
        ))}
      </div>

      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <LumaLogo size={180} />
      </motion.div>
      
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="flex flex-col items-center gap-2"
      >
        <h1 className="text-3xl font-black italic uppercase tracking-widest text-[#E6E8F2]">Good Night</h1>
        <p className="text-[10px] font-bold text-[#A78BFA] uppercase tracking-[0.3em] italic">Sleep Well, Dream Softly</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-16"
      >
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-[#A78BFA] rounded-full animate-pulse" />
          <span className="text-[9px] text-[#A78BFA]/60 font-bold uppercase tracking-widest italic">Loading your sanctuary...</span>
        </div>
      </motion.div>
    </motion.div>
  );
}

function App() {
  const [showSplash, setShowSplash] = useState(true);
  // Only show the account setup on first launch (never again once completed)
  const [needsSetup, setNeedsSetup] = useState(() => {
    return !localStorage.getItem("nightlight_onboarded");
  });

  return (
    <RewardProvider>
      <AnimatePresence>
        {showSplash && (
          <SplashScreen onFinish={() => setShowSplash(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!showSplash && needsSetup && (
          <AccountSetup onComplete={() => setNeedsSetup(false)} />
        )}
      </AnimatePresence>

      {!showSplash && !needsSetup && (
        <>
          <RouterProvider router={router} />
          <Toaster 
            position="top-center" 
            toastOptions={{
              style: {
                background: "#1A1E33",
                color: "#E6E8F2",
                border: "1px solid rgba(230, 232, 242, 0.1)",
              }
            }}
          />
        </>
      )}
    </RewardProvider>
  );
}

export default App;
