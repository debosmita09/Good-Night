import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';

const data = [
  { day: 'Mon', hours: 6.5 },
  { day: 'Tue', hours: 7.2 },
  { day: 'Wed', hours: 5.8 },
  { day: 'Thu', hours: 8.0 },
  { day: 'Fri', hours: 6.9 },
  { day: 'Sat', hours: 9.0 },
  { day: 'Sun', hours: 7.5 },
];

export function DailySleepGraph() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full bg-card border-2 border-primary/10 rounded-[2.5rem] p-6 shadow-sm"
    >
      <div className="flex flex-col gap-1 mb-6">
        <h3 className="text-sm font-bold text-foreground uppercase tracking-widest italic">Sleep Rhythm</h3>
        <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic opacity-60">Last 7 Days</p>
      </div>
      
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorSleep" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#A78BFA" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#A78BFA" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(167,139,250,0.1)" />
            <XAxis 
              dataKey="day" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1A1E33', 
                borderRadius: '12px', 
                border: '1px solid rgba(167,139,250,0.2)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
              }}
              itemStyle={{ color: '#E6E8F2', fontSize: '12px', fontWeight: 'bold' }}
              labelStyle={{ color: '#A78BFA', fontSize: '10px', fontWeight: 'bold', marginBottom: '4px' }}
            />
            <Area 
              type="monotone" 
              dataKey="hours" 
              stroke="#A78BFA" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorSleep)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
