import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion } from 'motion/react';

const data = [
  { mood: '1-2', frequency: 2, label: 'Low' },
  { mood: '3-4', frequency: 5, label: 'Meh' },
  { mood: '5-6', frequency: 12, label: 'Okay' },
  { mood: '7-8', frequency: 8, label: 'Good' },
  { mood: '9-10', frequency: 4, label: 'Great' },
];

export function MoodFrequencyGraph() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="w-full bg-card border-2 border-primary/10 rounded-[2.5rem] p-6 shadow-sm"
    >
      <div className="flex flex-col gap-1 mb-6">
        <h3 className="text-sm font-bold text-foreground uppercase tracking-widest italic">Mood Density</h3>
        <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic opacity-60">Past Month Distribution</p>
      </div>
      
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <XAxis 
              dataKey="label" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
            />
            <Tooltip 
              cursor={{ fill: 'rgba(167,139,250,0.05)' }}
              contentStyle={{ 
                backgroundColor: '#1A1E33', 
                borderRadius: '12px', 
                border: '1px solid rgba(167,139,250,0.2)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
              }}
              itemStyle={{ color: '#E6E8F2', fontSize: '12px', fontWeight: 'bold' }}
              labelStyle={{ color: '#A78BFA', fontSize: '10px', fontWeight: 'bold', marginBottom: '4px' }}
            />
            <Bar dataKey="frequency" radius={[6, 6, 6, 6]}>
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={index === 2 ? '#A78BFA' : 'rgba(167,139,250,0.3)'} 
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
