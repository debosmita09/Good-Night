import { Outlet, NavLink, useLocation } from "react-router";
import { Home, Moon, BarChart3, Users, Settings, BookOpen, Clock } from "lucide-react";
import { cn } from "../lib/utils";
import { useState, useEffect } from "react";

export function Layout() {
  const location = useLocation();
  const hideNav = ["/nightmare", "/chatbot", "/kids-mode"].includes(location.pathname);
  const isHomePage = location.pathname === "/";
  
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (hideNav) return <Outlet />;

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground pb-24 transition-colors duration-500">
      {/* Global Top Header with Clock (Hidden on Home as it has a Big Clock) */}
      <div className="w-full max-w-lg mx-auto px-4 pt-4 flex justify-between items-center z-40 h-12">
        {!isHomePage && (
          <div className="flex items-center gap-2 px-4 py-2 bg-card/50 backdrop-blur-md rounded-2xl border border-border shadow-sm">
            <Clock className="w-3.5 h-3.5 text-primary animate-pulse" />
            <span className="text-xs font-black italic tracking-widest text-foreground">
              {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        )}
      </div>

      <main className="flex-1 w-full max-w-lg mx-auto px-4 pt-2">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-lg border-t border-border px-4">
        <div className="max-w-lg mx-auto flex justify-between items-center py-3">
          <NavItem to="/" icon={<Home className="w-5 h-5" />} label="Home" />
          <NavItem to="/wind-down" icon={<Moon className="w-5 h-5" />} label="Wind Down" />
          <NavItem to="/library" icon={<BookOpen className="w-5 h-5" />} label="Library" />
          <NavItem to="/community" icon={<Users className="w-5 h-5" />} label="Community" />
          <NavItem to="/settings" icon={<Settings className="w-5 h-5" />} label="Settings" />
        </div>
      </nav>
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex flex-col items-center gap-1 transition-all duration-300 px-2 py-1 rounded-xl",
          isActive ? "text-primary scale-110" : "text-muted-foreground hover:text-foreground"
        )
      }
    >
      {icon}
      <span className="text-[9px] font-bold uppercase tracking-widest leading-none italic">{label}</span>
    </NavLink>
  );
}
