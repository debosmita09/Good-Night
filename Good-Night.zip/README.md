
  # Good_Night (Copy)

  This is a code bundle for Good_Night (Copy). The original project is available at https://www.figma.com/design/Je9W1zAm8T1ZZLJdlq1vhz/Good_Night--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  