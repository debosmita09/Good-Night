from django.contrib import admin
from django.urls import path, include
from Backend.views import (
    luna_chat_view, 
    transcribe_audio_view, 
    sync_app_usage, 
    update_app_limit
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Backend.urls')),
    # Luna Chatbot Endpoint
    path("luna-chat/", luna_chat_view, name="luna_chat"),
    
    # ElevenLabs Transcription Endpoint
    path("transcribe/", transcribe_audio_view, name="transcribe_audio"),
    
    # App Tracking & Limits (ScreenZen-style features)
    path("sync-usage/", sync_app_usage, name="sync_app_usage"),
    path("update-limit/", update_app_limit, name="update_app_limit"),
]