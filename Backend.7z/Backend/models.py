from django.db import models
from django.contrib.auth.models import User

class AppLimit(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    app_package_name = models.CharField(max_length=255)  # e.g., "com.instagram.android"
    allotted_time_minutes = models.PositiveIntegerField(default=30)
    current_usage_minutes = models.PositiveIntegerField(default=0)
    is_blocked = models.BooleanField(default=False)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.app_package_name} - {self.user.username}"
    
    
from django.db import models
from django.contrib.auth.models import User

class UserAppPreference(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    app_package_name = models.CharField(max_length=255)
    app_display_name = models.CharField(max_length=100, blank=True)
    max_time_allowed = models.PositiveIntegerField(default=30)
    daily_usage_minutes = models.PositiveIntegerField(default=0)
    
    class Meta:
        unique_together = ('user', 'app_package_name')

    def __str__(self):
        return f"{self.user.username}'s limit for {self.app_display_name}"