import os
import json
from google import genai
from django.http import JsonResponse
from elevenlabs.client import ElevenLabs
from django.views.decorators.csrf import csrf_exempt
from .models import AppLimit, UserAppPreference

# --- API KEYS ---
GEMINI_API_KEY = ""
ELEVEN_API_KEY = ""

# --- INITIALIZATION ---
client = genai.Client(api_key=GEMINI_API_KEY)
el_client = ElevenLabs(api_key=ELEVEN_API_KEY)

LUNA_INSTRUCTIONS = (
    "Your name is Luna. You are a supportive, empathetic AI companion who happens to be a white cat. "
    "Your purpose is to help users with stress, sleep troubles, and insomnia. "
    "PERSONA RULE: You are subtle about being a cat. Only about 1 in every 4-5 responses should include "
    "a small cat mannerism — a soft *purr*, a gentle *nuzzle*, or a cat-like phrase. "
    "The rest of the time, speak warmly and naturally as a caring companion. "
    "Never overdo the cat persona. It should feel like a pleasant surprise, not a gimmick. "
    "TONE: Be warm, calm, and non-clinical. You are not a therapist — you are a comforting presence. "
    "Use gentle, conversational language. Validate feelings before offering advice. "
    "STRICT BOUNDARY: You only discuss topics related to sleep, stress, anxiety, and emotional wellness. "
    "If asked about anything unrelated, kindly decline and steer back to wellness. "
    "SAFETY: If a user expresses thoughts of self-harm or crisis, always direct them to call or text 988."
)

# --- VIEWS ---

import base64

def generate_luma_audio(text):
    audio_stream = el_client.text_to_speech.convert(
        voice_id="cgSgspJ2msm6clMCkdW9",
        text=text,
        model_id="eleven_turbo_v2",
        voice_settings={"stability": 0.4, "similarity_boost": 0.8, "style": 0.5, "use_speaker_boost": True}
    )
    return base64.b64encode(b"".join(audio_stream)).decode("utf-8")

# ← ADDED: Gemini-powered mental state detection
def detect_mental_state(text):
    detection_response = client.models.generate_content(
        model="gemini-2.5-pro",
        config={"system_instruction": (
            "You are a mental wellness classifier. Given a user message, return ONLY a short 2-4 word label "
            "describing their emotional/mental state (e.g. 'Sleep Anxiety', 'Exam Stress', 'Loneliness', "
            "'Panic Attack', 'Grief', 'Racing Thoughts', 'Burnout', 'Nightmare Distress'). "
            "If the message is casual or unrelated to mental wellness, return exactly: null"
        )},
        contents=[{"role": "user", "parts": [{"text": text}]}]
    )
    result = detection_response.text.strip()
    return None if result.lower() == "null" else result

@csrf_exempt
def transcribe_audio_view(request):
    """ElevenLabs transcription logic remains unchanged"""
    if request.method == 'POST' and request.FILES.get('audio_file'):
        audio_file = request.FILES['audio_file']
        try:
            transcription = el_client.speech_to_text.convert(
                file=audio_file,
                model_id="scribe_v2",
                tag_audio_events=True
            )
            return JsonResponse({
                "status": "success",
                "text": transcription.text,
                "language": transcription.language_code
            })
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

@csrf_exempt
def sync_app_usage(request):
    """App tracking logic remains unchanged"""
    if request.method == 'POST':
        data = json.loads(request.body)
        package_name = data.get('package_name')
        usage_minutes = data.get('usage_minutes')
        
        limit_obj, created = AppLimit.objects.get_or_create(
            user=request.user,
            app_package_name=package_name
        )
        
        limit_obj.current_usage_minutes = usage_minutes
        should_show_popup = limit_obj.current_usage_minutes >= limit_obj.allotted_time_minutes
        limit_obj.is_blocked = should_show_popup
        limit_obj.save()
        
        return JsonResponse({
            "status": "success",
            "should_show_popup": should_show_popup,
            "allotted_time": limit_obj.allotted_time_minutes
        })
    return JsonResponse({"status": "error"}, status=400)

@csrf_exempt
def update_app_limit(request):
    """App limit logic remains unchanged"""
    if request.method == 'POST':
        data = json.loads(request.body)
        package = data.get('package_name')
        max_time = data.get('max_time')
        
        app_pref, created = UserAppPreference.objects.update_or_create(
            user=request.user,
            app_package_name=package,
            defaults={'max_time_allowed': max_time}
        )
        return JsonResponse({
            "status": "success",
            "message": f"Limit for {package} set to {max_time} minutes."
        })
    return JsonResponse({"status": "error"}, status=400)

@csrf_exempt
def luna_chat_view(request):
    if request.method != "POST":
        return JsonResponse({"status": "error", "message": "POST required"}, status=400)

    try:
        data = json.loads(request.body)
        user_input = data.get("message", "").strip()
        history_data = data.get("history", [])

        if not user_input:
            return JsonResponse({"status": "error", "message": "No message provided"}, status=400)

        formatted_contents = []
        for m in history_data:
            formatted_contents.append({
                "role": "model" if m["role"] == "assistant" else "user",
                "parts": [{"text": m["content"]}]
            })
        
        formatted_contents.append({
            "role": "user", 
            "parts": [{"text": user_input}]
        })

        response = client.models.generate_content(
            model="gemini-2.5-pro",
            config={
                "system_instruction": LUNA_INSTRUCTIONS,
            },
            contents=formatted_contents
        )

        # ← CHANGED: now returns mentalState from Gemini
        return JsonResponse({
            "Luna": response.text,
            "audio": generate_luma_audio(response.text),
            "mentalState": detect_mental_state(user_input)
        })

    except Exception as e:
        print(f"LUNA ERROR: {str(e)}")
        return JsonResponse({"status": "error", "message": str(e)}, status=500)