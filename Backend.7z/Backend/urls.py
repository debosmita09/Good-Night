from django.urls import path

# This can remain empty for now since your routes are in the root urls.py
urlpatterns = []