import { useState, useRef, useEffect } from "react";
import { Play, Pause, Square, Music, Apple, BookOpen, Smartphone, Upload, FileText, ChevronRight, X, Volume2, SkipBack, SkipForward, Headphones, Wind, Zap, Waves, Sparkles, AlertCircle, Heart, Trophy, Clock, Mic, Speaker } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import * as Progress from "@radix-ui/react-progress";
import * as Slider from "@radix-ui/react-slider";
import { useRewards } from "../RewardContext";

type LibraryTab = "music" | "ambient" | "books" | "audiobooks";

// Mock audiobooks data
const audiobookLibrary = [
  { id: "ab1", title: "The Night Garden", author: "Luna Wells", duration: 180, cover: "📖", genre: "Fantasy" },
  { id: "ab2", title: "Whispers in the Wind", author: "Sage Monroe", duration: 240, cover: "🌬️", genre: "Relaxation" },
  { id: "ab3", title: "Starlight Stories", author: "Celeste Dawn", duration: 120, cover: "⭐", genre: "Children" },
  { id: "ab4", title: "The Calm Before Sleep", author: "Dr. Serenity", duration: 90, cover: "🌙", genre: "Meditation" },
  { id: "ab5", title: "Ocean of Dreams", author: "Marina Blue", duration: 150, cover: "🌊", genre: "Nature" },
];

// Mock book content for TTS
const bookSampleTexts: Record<string, string> = {
  ab1: "In the quiet corners of the Night Garden, where moonflowers bloom and fireflies dance in silver trails, there lived a small creature named Moth. Every evening, as the sun dipped below the hills, Moth would unfold her wings and begin her gentle journey through the garden paths...",
  ab2: "The wind carried stories from distant lands, whispering secrets to the tall grasses and singing lullabies to the sleeping earth. If you listened carefully, you could hear the tales of ancient trees, of rivers that remembered the beginning of time...",
  ab3: "Once upon a time, in a land made entirely of starlight, there lived a young star who hadn't yet learned how to shine. Every night, she watched the other stars twinkling and sparkling across the sky, wondering when her own light would finally appear...",
  ab4: "Close your eyes now, and imagine you are floating on a cloud. This cloud is soft and warm, and it carries you gently through a sky painted in the softest shades of lavender and gold. With each breath, you feel lighter, calmer, more at peace...",
  ab5: "The ocean breathes with a rhythm as old as the world itself. In and out, the waves whisper against the shore, carrying with them the dreams of sailors and the songs of whales. Let the rhythm of the water carry your thoughts away to a place of deep, peaceful rest...",
};

export function Library() {
  const { addPoints } = useRewards();
  const [tab, setTab] = useState<LibraryTab>("music");
  const [activeItem, setActiveItem] = useState<{ id: string, title: string, artist?: string, duration: number, type: 'music' | 'book' | 'ambient' | 'audiobook' } | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState([80]);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  
  // Reading tracking
  const [isReading, setIsReading] = useState(false);
  const [readingTime, setReadingTime] = useState(0);

  // Voice synthesizer states
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState<"warm" | "soft" | "gentle">("warm");
  const [ttsSpeed, setTtsSpeed] = useState([0.8]);
  const [currentBookId, setCurrentBookId] = useState<string | null>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && progress < 100) {
      interval = setInterval(() => {
        setProgress(p => {
          const next = Math.min(p + 0.1, 100);
          if (next === 100) {
            setIsPlaying(false);
            if (activeItem?.type === 'music') addPoints(5, "Completed Track");
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, progress, activeItem]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isReading) {
      interval = setInterval(() => {
        setReadingTime(t => {
          const next = t + 1;
          if (next % 60 === 0) {
            addPoints(5, "Focused Reading Progress");
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isReading]);

  const handleConnect = (service: string) => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 2000)),
      {
        loading: `Connecting to ${service}...`,
        success: `Successfully connected to ${service}!`,
        error: `Could not connect to ${service}`,
      }
    );
  };

  const handlePlay = (item: any) => {
    if (activeItem?.id === item.id) {
      setIsPlaying(!isPlaying);
    } else {
      setActiveItem(item);
      setIsPlaying(true);
      setProgress(0);
    }
  };

  // TTS Functions
  const startTTS = (bookId: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const text = bookSampleTexts[bookId] || "Story content loading...";
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = ttsSpeed[0];
      utterance.pitch = selectedVoice === "warm" ? 1.0 : selectedVoice === "soft" ? 0.8 : 1.2;
      utterance.volume = volume[0] / 100;
      
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => {
        setIsSpeaking(false);
        addPoints(10, "Completed Audiobook Chapter");
        toast.success("Chapter complete! Sweet dreams ahead.");
      };
      utterance.onerror = () => setIsSpeaking(false);
      
      synthRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      setCurrentBookId(bookId);
      toast.info("Reading aloud... Let the words carry you to sleep.", { icon: "🔊" });
    } else {
      toast.error("Voice synthesis not available on this device.");
    }
  };

  const stopTTS = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
    setCurrentBookId(null);
  };

  const voiceOptions = [
    { id: "warm", name: "Warm", desc: "Soothing bedtime voice", emoji: "🌙" },
    { id: "soft", name: "Soft", desc: "Gentle whisper tone", emoji: "🤫" },
    { id: "gentle", name: "Gentle", desc: "Calm nurturing voice", emoji: "💜" },
  ];

  return (
    <div className="flex flex-col gap-8 pb-32">
      <header className="flex flex-col gap-1 px-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Calm Library</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Curated for your peaceful night.</p>
      </header>

      {/* Tab Selector */}
      <div className="flex bg-card border border-border p-1.5 rounded-3xl">
        <button
          onClick={() => setTab("music")}
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-[9px]",
            tab === "music" ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Music className="w-3 h-3" />
          Music
        </button>
        <button
          onClick={() => setTab("ambient")}
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-[9px]",
            tab === "ambient" ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Waves className="w-3 h-3" />
          Ambient
        </button>
        <button
          onClick={() => setTab("books")}
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-[9px]",
            tab === "books" ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <BookOpen className="w-3 h-3" />
          Books
        </button>
        <button
          onClick={() => setTab("audiobooks")}
          className={cn(
            "flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-[9px]",
            tab === "audiobooks" ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Speaker className="w-3 h-3" />
          Listen
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          className="flex flex-col gap-8"
        >
          {tab === "music" && (
            <div className="flex flex-col gap-8">
              {/* Connect Services */}
              <div className="grid grid-cols-2 gap-4">
                <ServiceButton 
                  icon={<div className="w-6 h-6 bg-[#1DB954] rounded-full flex items-center justify-center text-white p-1"><Music className="w-4 h-4" /></div>}
                  label="Spotify"
                  onClick={() => handleConnect("Spotify")}
                />
                <ServiceButton 
                  icon={<div className="w-6 h-6 bg-[#FA57C1] rounded-full flex items-center justify-center text-white p-1"><Apple className="w-4 h-4 fill-current" /></div>}
                  label="Apple Music"
                  onClick={() => handleConnect("Apple Music")}
                />
              </div>

              {/* Recommendations */}
              <section className="flex flex-col gap-4">
                <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">Calm Tracks</h3>
                <div className="flex flex-col gap-3">
                  <PlaylistItem 
                    id="piano"
                    title="Soft Piano Dreams" 
                    artist="Lofi Sleep" 
                    duration={84}
                    isPlaying={activeItem?.id === "piano" && isPlaying}
                    isActive={activeItem?.id === "piano"}
                    onClick={() => handlePlay({ id: "piano", title: "Soft Piano Dreams", artist: "Lofi Sleep", duration: 84, type: 'music' })}
                  />
                  <PlaylistItem 
                    id="acoustic"
                    title="Night Strings" 
                    artist="Acoustic Ambient" 
                    duration={120}
                    isPlaying={activeItem?.id === "acoustic" && isPlaying}
                    isActive={activeItem?.id === "acoustic"}
                    onClick={() => handlePlay({ id: "acoustic", title: "Night Strings", artist: "Acoustic Ambient", duration: 120, type: 'music' })}
                  />
                  <PlaylistItem 
                    id="baby-lullaby"
                    icon={<div className="w-10 h-10 bg-pink-500/20 text-pink-400 rounded-xl flex items-center justify-center shadow-inner"><Heart className="w-5 h-5 fill-current" /></div>}
                    title="Baby's First Dream" 
                    artist="Soft Lullaby" 
                    duration={60}
                    isPlaying={activeItem?.id === "baby-lullaby" && isPlaying}
                    isActive={activeItem?.id === "baby-lullaby"}
                    onClick={() => handlePlay({ id: "baby-lullaby", title: "Baby's First Dream", artist: "Soft Lullaby", duration: 60, type: 'music' })}
                  />
                </div>
              </section>
            </div>
          )}

          {tab === "ambient" && (
            <div className="flex flex-col gap-8">
              <section className="flex flex-col gap-4">
                <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">White & Brown Noise</h3>
                <div className="grid grid-cols-1 gap-3">
                  <PlaylistItem 
                    id="brown"
                    icon={<div className="w-10 h-10 bg-amber-900/20 text-amber-700 rounded-xl flex items-center justify-center shadow-inner"><Waves className="w-5 h-5" /></div>}
                    title="Deep Brown Noise" 
                    artist="Earth Rumbles" 
                    duration={480}
                    isPlaying={activeItem?.id === "brown" && isPlaying}
                    isActive={activeItem?.id === "brown"}
                    onClick={() => handlePlay({ id: "brown", title: "Deep Brown Noise", artist: "Earth Rumbles", duration: 480, type: 'ambient' })}
                  />
                  <PlaylistItem 
                    id="white"
                    icon={<div className="w-10 h-10 bg-gray-400/20 text-gray-500 rounded-xl flex items-center justify-center shadow-inner"><Wind className="w-5 h-5" /></div>}
                    title="Pure White Noise" 
                    artist="Fan Static" 
                    duration={480}
                    isPlaying={activeItem?.id === "white" && isPlaying}
                    isActive={activeItem?.id === "white"}
                    onClick={() => handlePlay({ id: "white", title: "Pure White Noise", artist: "Fan Static", duration: 480, type: 'ambient' })}
                  />
                  <PlaylistItem 
                    id="pink"
                    icon={<div className="w-10 h-10 bg-pink-400/20 text-pink-500 rounded-xl flex items-center justify-center shadow-inner"><Sparkles className="w-5 h-5" /></div>}
                    title="Soft Pink Noise" 
                    artist="Gentle Rainfall" 
                    duration={480}
                    isPlaying={activeItem?.id === "pink" && isPlaying}
                    isActive={activeItem?.id === "pink"}
                    onClick={() => handlePlay({ id: "pink", title: "Soft Pink Noise", artist: "Gentle Rainfall", duration: 480, type: 'ambient' })}
                  />
                </div>
              </section>
            </div>
          )}

          {tab === "books" && (
            <div className="flex flex-col gap-8">
              {/* Kindle Link */}
              <button 
                onClick={() => handleConnect("Amazon Kindle")}
                className="bg-[#FF9900]/10 border border-[#FF9900]/20 p-8 rounded-[2.5rem] flex items-center justify-between group transition-all hover:bg-[#FF9900]/20 active:scale-[0.98]"
              >
                <div className="flex items-center gap-5 text-left">
                  <div className="w-14 h-14 bg-[#232F3E] rounded-2xl flex items-center justify-center text-white shadow-lg transition-transform group-hover:-rotate-6">
                    <Smartphone className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-foreground tracking-tight leading-none italic">Sync Amazon Kindle</h3>
                    <p className="text-[10px] text-[#FF9900] font-bold uppercase tracking-widest mt-1 italic">Read your library in app</p>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-[#FF9900] transition-transform group-hover:translate-x-1" />
              </button>

              {/* Reading Progress */}
              <div className="bg-card border-2 border-primary/20 p-8 rounded-[2.5rem] flex flex-col gap-6 relative overflow-hidden group shadow-[0_20px_40px_rgba(167,139,250,0.1)]">
                <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform">
                  <BookOpen className="w-16 h-16 text-primary" />
                </div>
                <div className="flex justify-between items-start relative z-10">
                  <div className="flex flex-col gap-1">
                    <h3 className="text-sm font-bold text-primary uppercase tracking-widest leading-none">Reading Session</h3>
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest leading-none italic mt-1">Earn points by reading</p>
                  </div>
                  <div className="bg-primary/10 px-3 py-1.5 rounded-full flex items-center gap-2">
                    <div className={cn("w-1.5 h-1.5 bg-primary rounded-full", isReading && "animate-pulse")} />
                    <span className="text-[10px] font-bold text-primary uppercase tracking-widest leading-none italic">{isReading ? "Active" : "Paused"}</span>
                  </div>
                </div>

                <div className="flex flex-col items-center gap-2 py-2">
                  <div className="text-4xl font-black italic tracking-tighter text-foreground font-mono">
                    {Math.floor(readingTime / 60).toString().padStart(2, '0')}:{ (readingTime % 60).toString().padStart(2, '0')}
                  </div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic opacity-60">Total Focused Time</span>
                </div>

                <button 
                  onClick={() => {
                    setIsReading(!isReading);
                    if (!isReading) toast.info("Reading session started! Points awarded every minute.", { icon: "📖" });
                  }}
                  className={cn(
                    "w-full h-14 font-black italic uppercase tracking-widest rounded-2xl flex items-center justify-center gap-3 transition-all active:scale-95 shadow-lg",
                    isReading ? "bg-muted text-foreground border border-border" : "bg-primary text-primary-foreground"
                  )}
                >
                  {isReading ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
                  <span>{isReading ? "Pause Session" : "Start Reading"}</span>
                </button>
              </div>

              {/* PDF Upload */}
              <div className="bg-card border border-dashed border-border rounded-[2.5rem] p-10 flex flex-col items-center gap-4 text-center group cursor-pointer hover:bg-card/80 transition-all border-secondary/20 bg-secondary/5">
                <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center text-secondary group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(107,140,255,0.1)]">
                  <FileText className="w-8 h-8" />
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-bold tracking-tight leading-none italic">Upload PDF / EPUB</h3>
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-1 italic">Maximum 50MB per file</p>
                </div>
              </div>
            </div>
          )}

          {tab === "audiobooks" && (
            <div className="flex flex-col gap-8">
              {/* Voice Synthesizer Header */}
              <div className="bg-card border-2 border-primary/20 p-6 rounded-[2.5rem] flex flex-col gap-5 relative overflow-hidden shadow-[0_20px_40px_rgba(167,139,250,0.1)]">
                <div className="absolute top-0 right-0 p-6 opacity-5">
                  <Volume2 className="w-16 h-16 text-primary" />
                </div>
                <div className="flex items-center gap-4 relative z-10">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                    <Speaker className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-primary uppercase tracking-widest leading-none">Voice Reader</h3>
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest leading-none italic mt-1">Listen to books read aloud</p>
                  </div>
                </div>

                {/* Voice Selection */}
                <div className="flex flex-col gap-3">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">Choose Voice</span>
                  <div className="grid grid-cols-3 gap-2">
                    {voiceOptions.map(v => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVoice(v.id as any)}
                        className={cn(
                          "p-3 rounded-2xl border text-center transition-all active:scale-95 flex flex-col items-center gap-1",
                          selectedVoice === v.id 
                            ? "bg-primary/10 border-primary/30 text-primary" 
                            : "bg-background/40 border-border text-muted-foreground hover:border-primary/20"
                        )}
                      >
                        <span className="text-lg">{v.emoji}</span>
                        <span className="text-[9px] font-black uppercase tracking-widest italic">{v.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* TTS Speed */}
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">Reading Speed</span>
                    <span className="text-xs font-bold text-primary italic">{ttsSpeed[0]}x</span>
                  </div>
                  <Slider.Root
                    className="relative flex items-center select-none touch-none w-full h-5"
                    value={ttsSpeed}
                    max={1.5}
                    min={0.5}
                    step={0.1}
                    onValueChange={setTtsSpeed}
                  >
                    <Slider.Track className="bg-border/20 relative grow rounded-full h-1.5 overflow-hidden">
                      <Slider.Range className="absolute bg-primary rounded-full h-full" />
                    </Slider.Track>
                    <Slider.Thumb className="block w-5 h-5 bg-primary shadow-lg rounded-full hover:scale-110 focus:outline-none transition-transform cursor-grab active:cursor-grabbing border-3 border-card" />
                  </Slider.Root>
                </div>

                {/* Speaking Indicator */}
                {isSpeaking && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="bg-primary/10 border border-primary/20 p-4 rounded-2xl flex items-center gap-3"
                  >
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <Volume2 className="w-5 h-5 text-primary" />
                    </motion.div>
                    <div className="flex-1">
                      <p className="text-xs font-bold text-primary italic">Reading aloud...</p>
                      <p className="text-[9px] text-muted-foreground uppercase tracking-widest italic mt-0.5">
                        {audiobookLibrary.find(b => b.id === currentBookId)?.title}
                      </p>
                    </div>
                    <button
                      onClick={stopTTS}
                      className="w-8 h-8 bg-primary text-primary-foreground rounded-lg flex items-center justify-center active:scale-95"
                    >
                      <Square className="w-4 h-4 fill-current" />
                    </button>
                  </motion.div>
                )}
              </div>

              {/* Audiobook List */}
              <section className="flex flex-col gap-4">
                <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">Audiobook Library</h3>
                <div className="flex flex-col gap-3">
                  {audiobookLibrary.map(book => (
                    <motion.div
                      key={book.id}
                      whileHover={{ scale: 1.01 }}
                      className={cn(
                        "bg-card border border-border p-5 rounded-[2rem] flex items-center gap-4 transition-all group",
                        currentBookId === book.id && isSpeaking && "border-primary bg-primary/5"
                      )}
                    >
                      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-2xl shrink-0">
                        {book.cover}
                      </div>
                      <div className="flex-1 flex flex-col gap-1 min-w-0">
                        <span className="font-bold tracking-tight leading-none italic truncate text-sm">{book.title}</span>
                        <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic truncate mt-0.5 opacity-70">{book.author}</span>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[8px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold uppercase tracking-widest italic">{book.genre}</span>
                          <span className="text-[8px] text-muted-foreground font-bold uppercase tracking-widest italic opacity-40">{book.duration}m</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            if (currentBookId === book.id && isSpeaking) {
                              stopTTS();
                            } else {
                              startTTS(book.id);
                            }
                          }}
                          className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-95 shadow-sm",
                            currentBookId === book.id && isSpeaking 
                              ? "bg-primary text-primary-foreground" 
                              : "bg-primary/10 text-primary hover:bg-primary/20"
                          )}
                        >
                          {currentBookId === book.id && isSpeaking ? (
                            <Pause className="w-5 h-5 fill-current" />
                          ) : (
                            <Volume2 className="w-5 h-5" />
                          )}
                        </button>
                        <button
                          onClick={() => handlePlay({ 
                            id: book.id, 
                            title: book.title, 
                            artist: book.author, 
                            duration: book.duration, 
                            type: 'audiobook' 
                          })}
                          className="w-10 h-10 rounded-xl bg-muted text-muted-foreground flex items-center justify-center transition-all active:scale-95 hover:bg-muted/80"
                        >
                          <Play className="w-5 h-5 ml-0.5 fill-current" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* Upload your own book for TTS */}
              <div className="bg-card border border-dashed border-border rounded-[2.5rem] p-8 flex flex-col items-center gap-4 text-center group cursor-pointer hover:bg-card/80 transition-all border-primary/20 bg-primary/5">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <Upload className="w-7 h-7" />
                </div>
                <div className="flex flex-col gap-1">
                  <h3 className="text-base font-bold tracking-tight leading-none italic">Upload Your Book</h3>
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-1 italic">Upload PDF/EPUB to listen with voice reader</p>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Persistent Media Player */}
      <AnimatePresence>
        {activeItem && (
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-[88px] left-4 right-4 z-40"
          >
            <div className="bg-card/95 backdrop-blur-xl border border-border rounded-[2rem] p-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col gap-3">
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center relative overflow-hidden shrink-0",
                  activeItem.type === 'music' ? "bg-primary/20 text-primary" : activeItem.type === 'ambient' ? "bg-amber-500/10 text-amber-500" : activeItem.type === 'audiobook' ? "bg-purple-500/10 text-purple-500" : "bg-secondary/20 text-secondary"
                )}>
                  {activeItem.type === 'music' ? <Music className="w-6 h-6" /> : activeItem.type === 'ambient' ? <Waves className="w-6 h-6" /> : activeItem.type === 'audiobook' ? <Volume2 className="w-6 h-6" /> : <BookOpen className="w-6 h-6" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold text-foreground truncate italic tracking-tight uppercase tracking-widest">{activeItem.title}</h4>
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest truncate leading-none italic mt-1">
                    {activeItem.type === 'music' ? activeItem.artist : activeItem.type === 'ambient' ? 'Ambient Calm' : activeItem.type === 'audiobook' ? 'Voice Reader' : 'Text-to-Speech Audiobook'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center shadow-lg transition-all active:scale-95"
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 ml-1 fill-current" />}
                  </button>
                  <button 
                    onClick={() => setActiveItem(null)}
                    className="w-10 h-10 bg-muted/50 text-muted-foreground rounded-xl flex items-center justify-center transition-all hover:bg-muted active:scale-95"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center text-[8px] font-bold text-muted-foreground uppercase tracking-widest italic opacity-60">
                  <span>{Math.floor(progress * activeItem.duration / 100)}m</span>
                  <span>{activeItem.duration}m</span>
                </div>
                <Progress.Root
                  className="bg-border/20 relative overflow-hidden h-1.5 rounded-full w-full"
                  value={progress}
                >
                  <Progress.Indicator
                    className={cn(
                      "h-full w-full transition-all duration-300",
                      activeItem.type === 'music' ? "bg-primary" : activeItem.type === 'audiobook' ? "bg-purple-500" : "bg-secondary"
                    )}
                    style={{ transform: `translateX(-${100 - progress}%)` }}
                  />
                </Progress.Root>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ServiceButton({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="bg-card border border-border p-5 rounded-[2rem] flex items-center gap-3 transition-all hover:bg-border/20 active:scale-95 text-left group"
    >
      <div className="shrink-0 transition-transform group-hover:scale-110">{icon}</div>
      <span className="text-[10px] font-bold tracking-widest leading-none italic uppercase">{label}</span>
    </button>
  );
}

function PlaylistItem({ id, title, artist, duration, isPlaying, isActive, onClick, icon }: { id: string, title: string, artist: string, duration: number, isPlaying: boolean, isActive: boolean, onClick: () => void, icon?: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "bg-card border border-border p-5 rounded-[2rem] flex items-center gap-5 transition-all hover:bg-border/20 active:scale-98 text-left group",
        isActive && "border-primary bg-primary/5"
      )}
    >
      <div className={cn(
        "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all shadow-sm",
        isPlaying ? "bg-primary text-primary-foreground scale-110 shadow-[0_0_20px_rgba(167,139,250,0.3)]" : isActive ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
      )}>
        {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : icon ? icon : <Play className="w-5 h-5 ml-1 fill-current" />}
      </div>
      <div className="flex-1 flex flex-col gap-0.5 min-w-0">
        <span className="font-bold tracking-tight leading-none italic truncate uppercase tracking-widest text-sm">{title}</span>
        <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic truncate mt-1 opacity-70">{artist}</span>
      </div>
      <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic opacity-40 shrink-0">{duration}m</span>
    </button>
  );
}
