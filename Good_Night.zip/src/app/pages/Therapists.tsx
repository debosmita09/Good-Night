import { useState } from "react";
import { Stethoscope, Star, Phone, Mail, Video, ChevronRight, Info, Heart, Award, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";

export function Therapists() {
  const [filter, setFilter] = useState<"all" | "sleep" | "trauma">("all");

  const therapists = [
    {
      name: "Dr. Sarah Miller",
      specialization: "Sleep Medicine Specialist",
      rating: 4.9,
      reviews: 124,
      image: "SM",
      type: "sleep",
      bio: "Helping individuals overcome chronic insomnia through CBT-I for over 12 years."
    },
    {
      name: "Mark Thompson, LCSW",
      specialization: "Trauma & Nightmare Therapy",
      rating: 4.8,
      reviews: 89,
      image: "MT",
      type: "trauma",
      bio: "Specializing in Imagery Rehearsal Therapy (IRT) for recurring trauma-based nightmares."
    },
    {
      name: "Dr. Elena Rodriguez",
      specialization: "Holistic Sleep Coach",
      rating: 5.0,
      reviews: 215,
      image: "ER",
      type: "sleep",
      bio: "Integrating mindfulness and lifestyle modifications to achieve deep, restorative sleep."
    }
  ];

  const filteredTherapists = filter === "all" ? therapists : therapists.filter(t => t.type === filter);

  return (
    <div className="flex flex-col gap-8 pb-12">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold text-foreground tracking-tight leading-none">Specialist Support</h1>
        <p className="text-muted-foreground font-normal leading-relaxed">Connect with professional help.</p>
      </header>

      {/* Emergency Card */}
      <section className="bg-red-500/10 border border-red-500/30 p-6 rounded-[2.5rem] flex flex-col gap-6 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-6 opacity-10 transition-transform group-hover:scale-110">
          <Heart className="w-16 h-16 text-red-400 fill-current" />
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-red-400">
            <Info className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-widest leading-none italic">In Crisis?</span>
          </div>
          <h3 className="text-xl font-bold text-foreground tracking-tight leading-tight italic">988 Suicide & Crisis Lifeline</h3>
          <p className="text-sm text-muted-foreground font-normal leading-relaxed">
            Free, confidential, 24/7 support for anyone in emotional distress or crisis.
          </p>
        </div>
        <a 
          href="tel:988" 
          className="w-full h-14 bg-red-500 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(239,68,68,0.4)] transition-all hover:bg-red-600 active:scale-95"
        >
          <Phone className="w-5 h-5 fill-current" />
          <span>Call 988</span>
        </a>
      </section>

      {/* Filters */}
      <div className="flex bg-card border border-border p-1.5 rounded-3xl">
        <FilterButton active={filter === "all"} onClick={() => setFilter("all")} label="All" />
        <FilterButton active={filter === "sleep"} onClick={() => setFilter("sleep")} label="Sleep" />
        <FilterButton active={filter === "trauma"} onClick={() => setFilter("trauma")} label="Trauma" />
      </div>

      {/* Therapist List */}
      <div className="flex flex-col gap-4">
        <AnimatePresence mode="popLayout">
          {filteredTherapists.map((t, idx) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-card border border-border rounded-[2.5rem] p-6 flex flex-col gap-6 group hover:border-primary/20 transition-all"
            >
              <div className="flex gap-4">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary font-bold text-xl transition-transform group-hover:scale-110">
                  {t.image}
                </div>
                <div className="flex-1 flex flex-col gap-1">
                  <div className="flex justify-between items-start">
                    <h4 className="text-lg font-bold tracking-tight leading-none italic">{t.name}</h4>
                    <div className="flex items-center gap-1 text-primary">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="text-xs font-bold leading-none">{t.rating}</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground font-medium uppercase tracking-widest leading-none mt-1">{t.specialization}</p>
                  <div className="flex gap-2 mt-2">
                    <Award className="w-3 h-3 text-blue-400" />
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  </div>
                </div>
              </div>

              <p className="text-sm text-muted-foreground font-normal leading-relaxed italic px-1">
                "{t.bio}"
              </p>

              <div className="grid grid-cols-3 gap-3">
                <ContactButton icon={<Phone className="w-4 h-4" />} />
                <ContactButton icon={<Mail className="w-4 h-4" />} />
                <ContactButton icon={<Video className="w-4 h-4" />} />
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Professional Advice Disclaimer */}
      <div className="p-4 rounded-2xl border border-dashed border-border flex gap-3 items-start bg-card/20 group hover:bg-card transition-colors">
        <ShieldCheck className="w-4 h-4 text-muted-foreground mt-1 shrink-0" />
        <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest leading-relaxed">
          The information provided in this app is for educational purposes only and does not constitute professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider.
        </p>
      </div>
    </div>
  );
}

function FilterButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex-1 py-2.5 rounded-2xl transition-all font-semibold tracking-tight leading-none italic text-xs uppercase tracking-widest",
        active ? "bg-background text-foreground shadow-sm scale-[1.02]" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {label}
    </button>
  );
}

function ContactButton({ icon }: { icon: React.ReactNode }) {
  return (
    <button className="h-12 bg-background border border-border rounded-2xl flex items-center justify-center text-muted-foreground transition-all hover:bg-border/20 active:scale-95 group">
      <div className="group-hover:text-primary transition-colors">{icon}</div>
    </button>
  );
}
