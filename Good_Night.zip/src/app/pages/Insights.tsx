import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area, Cell, PieChart, Pie } from 'recharts';
import { TrendingUp, AlertCircle, Info, Star, ChevronRight, Zap, Brain, Activity, Moon, Smartphone, Sparkles, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

const sleepData = [
  { day: 'Mon', hours: 7.2, debt: 0.8 },
  { day: 'Tue', hours: 6.8, debt: 1.2 },
  { day: 'Wed', hours: 8.1, debt: -0.1 },
  { day: 'Thu', hours: 7.5, debt: 0.5 },
  { day: 'Fri', hours: 6.5, debt: 1.5 },
  { day: 'Sat', hours: 9.0, debt: -1.0 },
  { day: 'Sun', hours: 7.8, debt: 0.2 },
];

const nightmareData = [
  { week: 'W1', count: 3, anxiety: 8 },
  { week: 'W2', count: 2, anxiety: 6 },
  { week: 'W3', count: 4, anxiety: 9 },
  { week: 'W4', count: 1, anxiety: 4 },
];

const moodSleepCorrelation = [
  { mood: 1, sleep: 5 },
  { mood: 3, sleep: 5.5 },
  { mood: 5, sleep: 7 },
  { mood: 7, sleep: 7.8 },
  { mood: 9, sleep: 8.5 },
];

export function Insights() {
  return (
    <div className="flex flex-col gap-8 pb-12 px-1">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Analytics Hub</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">Data-driven sleep intelligence.</p>
      </header>

      {/* Sleep Debt Trend */}
      <section className="bg-card border-2 border-primary/20 rounded-[2.5rem] p-8 flex flex-col gap-6 relative overflow-hidden shadow-[0_0_50px_rgba(167,139,250,0.1)]">
        <div className="flex justify-between items-center">
          <div className="flex flex-col gap-1">
            <h3 className="text-lg font-bold tracking-tight leading-none italic uppercase tracking-widest">Sleep Debt</h3>
            <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic opacity-60">Hours missed vs target</span>
          </div>
          <div className="flex items-center gap-2 text-primary bg-primary/10 px-4 py-2 rounded-2xl">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-widest leading-none italic">Improving</span>
          </div>
        </div>

        <div className="h-48 w-full mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sleepData}>
              <defs>
                <linearGradient id="colorDebt" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#A78BFA" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#A78BFA" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(230, 232, 242, 0.05)" />
              <XAxis 
                dataKey="day" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
                dy={10}
              />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1A1E33', 
                  border: '1px solid rgba(230, 232, 242, 0.1)',
                  borderRadius: '16px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                }}
                itemStyle={{ color: '#E6E8F2', fontSize: '12px', fontWeight: 'bold' }}
              />
              <Area 
                type="monotone" 
                dataKey="debt" 
                stroke="#A78BFA" 
                strokeWidth={3}
                fillOpacity={1} 
                fill="url(#colorDebt)" 
                animationDuration={2000}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Mood vs Sleep Correlation */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-6 relative overflow-hidden group">
        <div className="flex justify-between items-center">
          <div className="flex flex-col gap-1">
            <h3 className="text-lg font-bold tracking-tight leading-none italic uppercase tracking-widest">Mood & Sleep</h3>
            <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic opacity-60">Correlation analysis</span>
          </div>
          <div className="w-10 h-10 bg-secondary/10 rounded-xl flex items-center justify-center text-secondary">
            <Activity className="w-5 h-5" />
          </div>
        </div>

        <div className="h-40 w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={moodSleepCorrelation}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(230, 232, 242, 0.05)" />
              <XAxis 
                dataKey="mood" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
                dy={10}
              />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1A1E33', 
                  border: '1px solid rgba(230, 232, 242, 0.1)',
                  borderRadius: '16px'
                }}
              />
              <Line 
                type="step" 
                dataKey="sleep" 
                stroke="#6B8CFF" 
                strokeWidth={3}
                dot={{ r: 4, fill: '#6B8CFF', strokeWidth: 2, stroke: '#1A1E33' }}
                animationDuration={2000}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-relaxed mt-2 italic text-center opacity-60">
          "You average 1.5h more sleep on days rated 7+ for mood."
        </p>
      </section>

      {/* Nightmare vs Anxiety Heatmap */}
      <section className="bg-card border border-border rounded-[2.5rem] p-8 flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div className="flex flex-col gap-1">
            <h3 className="text-lg font-bold tracking-tight leading-none italic uppercase tracking-widest">Parasomnia Risk</h3>
            <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-none mt-1 italic opacity-60">Nightmares vs Anxiety level</span>
          </div>
          <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center text-red-400">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="h-40 w-full mt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={nightmareData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(230, 232, 242, 0.05)" />
              <XAxis 
                dataKey="week" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 700 }}
                dy={10}
              />
              <YAxis hide />
              <Bar 
                dataKey="anxiety" 
                fill="#EF4444" 
                radius={[8, 8, 0, 0]} 
                barSize={24}
                opacity={0.3}
              />
              <Bar 
                dataKey="count" 
                fill="#EF4444" 
                radius={[8, 8, 0, 0]} 
                barSize={12}
                animationDuration={2500}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-background/40 border border-border/50 p-4 rounded-2xl flex items-start gap-3 mt-2">
          <Sparkles className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground font-bold italic leading-relaxed uppercase tracking-widest">
            "Anxiety spikes in Week 3 correlated with 4 nightmare events."
          </p>
        </div>
      </section>

      {/* AI Intelligence Cards */}
      <section className="flex flex-col gap-4">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-widest px-1 italic">AI Behavioral Insights</h3>
        <div className="flex flex-col gap-3">
          <InsightCard 
            icon={<Smartphone className="w-5 h-5 text-amber-400" />}
            title="Digital Sunset Impact"
            description="Limiting social media after 10 PM reduced your sleep debt by 40% this week."
            color="bg-amber-500/10 border-amber-500/20"
          />
          <InsightCard 
            icon={<Brain className="w-5 h-5 text-purple-400" />}
            title="Dream Processing"
            description="Your REM cycles are 20% more stable when using Luma for 5 minutes pre-sleep."
            color="bg-purple-500/10 border-purple-500/20"
          />
          <InsightCard 
            icon={<Heart className="w-5 h-5 text-red-400" />}
            title="Health Correlation"
            description="Your insomnia triggers appear linked to late-afternoon caffeine intake."
            color="bg-red-500/10 border-red-500/20"
          />
        </div>
      </section>

      {/* Predictive Tip */}
      <div className="bg-primary/10 border-2 border-primary/20 p-8 rounded-[2.5rem] flex flex-col gap-3 group transition-all hover:bg-primary/15 relative overflow-hidden shadow-lg">
        <div className="absolute top-0 right-0 p-6 opacity-5 transition-transform group-hover:scale-110">
          <Zap className="w-16 h-16 text-primary fill-current" />
        </div>
        <div className="flex items-center gap-3 text-primary relative z-10">
          <Info className="w-5 h-5" />
          <span className="text-xs font-black uppercase tracking-widest leading-none italic">AI PREDICTIVE TIP</span>
        </div>
        <p className="text-sm font-bold text-foreground italic leading-relaxed relative z-10">
          "Based on your 19-year-old student profile and current stress, aiming for 9.5h sleep tonight will reduce anxiety by 15% tomorrow."
        </p>
      </div>
    </div>
  );
}

function InsightCard({ icon, title, description, color }: { icon: React.ReactNode; title: string; description: string; color: string }) {
  return (
    <div className={cn("p-6 rounded-[2rem] border flex gap-5 items-start transition-all hover:scale-[1.01] hover:bg-card group cursor-pointer", color)}>
      <div className="w-12 h-12 rounded-2xl bg-card border border-border flex items-center justify-center shrink-0 group-hover:rotate-6 transition-transform">
        {icon}
      </div>
      <div className="flex-1 flex flex-col gap-1">
        <h4 className="text-base font-bold tracking-tight leading-none italic">{title}</h4>
        <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest leading-relaxed mt-1 italic">{description}</p>
      </div>
      <ChevronRight className="w-5 h-5 text-muted-foreground/30 self-center group-hover:translate-x-1 transition-transform" />
    </div>
  );
}
