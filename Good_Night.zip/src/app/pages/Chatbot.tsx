import { useState, useRef, useEffect } from "react";
import { Send, Moon, Sparkles, Brain, Info, ShieldCheck, X, Heart, Wind, MessageSquare, ChevronLeft, Cat, Mic, MicOff, Volume2, VolumeX } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { detectMentalState } from "../lib/sleep-logic";
import { useNavigate } from "react-router";
import { toast } from "sonner";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  mentalState?: string;
  timestamp: Date;
}

export function Chatbot() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "*Purrr*... Hello there. I'm Luma, your night companion. I've been watching the moon waiting for you. Meow... tell me, what's rustling in your mind tonight? I'm here to listen with all my nine lives.",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Voice input/output states
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Speak Luma's response using TTS
  const speakLuma = (text: string) => {
    if (!voiceEnabled) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      // Clean up asterisks and special formatting for natural speech
      const cleanText = text.replace(/\*/g, "").replace(/\.\.\./g, ",");
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 0.85;
      utterance.pitch = 1.2; // Slightly higher for a cute cat voice
      utterance.volume = 0.9;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  // Start voice recognition
  const startListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Voice input is not supported in this browser. Try Chrome or Safari.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
      toast.info("Listening... Speak to Luma", { icon: "🎙️" });
    };

    recognition.onresult = (event: any) => {
      let finalTranscript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += t;
        } else {
          setTranscript(t);
        }
      }
      if (finalTranscript) {
        setInput(finalTranscript);
        setTranscript("");
      }
    };

    recognition.onerror = () => {
      setIsListening(false);
      setTranscript("");
    };

    recognition.onend = () => {
      setIsListening(false);
      setTranscript("");
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
    setTranscript("");
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    const detectedState = detectMentalState(input);

    // Mock AI response
    setTimeout(() => {
      const responseText = getAIResponse(input, detectedState);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: responseText,
        mentalState: detectedState,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
      
      // Auto-speak Luma's response
      speakLuma(responseText);
    }, 1500);
  };

  const getAIResponse = (input: string, state: string) => {
    const lower = input.toLowerCase();
    
    if (state === "Performance Stress") {
      return "*Slowly kneading paws*... I hear the weight in your meow. High expectations can feel like a heavy blanket that just won't settle. Science shows our feline—and human—brains process these tangles best during deep rest. Purrr... would you like to try a 'mental grooming' exercise to offload those worries?";
    }
    if (state === "Sleep-Onset Anxiety") {
      return "*Curling up comfortably*... Meow, I see you're chasing your own tail with those thoughts. Trying to catch sleep is like trying to catch a laser pointer—the harder you pounce, the more it slips away. Let's just focus on resting our whiskers. Your territory is safe. Shall we try a rhythmic breathing purr together?";
    }
    if (state === "Parasomnia Distress") {
      return "*Alert ears, gentle gaze*... Those shadow-mice in your dreams can feel very real, but I'm right here with you. *Nuzzles*... You're safe in your nest now. Let's ground ourselves: can you name three things your paws can touch in your room right now?";
    }
    
    return "*Gently tilting head*... Purrr... thank you for sharing that with me. Uncurling those thoughts is the first step toward a calm nap. Meow... how does that feel in your body right now? Do you feel any tightness in your shoulders, or perhaps your tail is a bit twitchy?";
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0F1220] flex flex-col">
      {/* Chat Header */}
      <header className="bg-card/80 backdrop-blur-lg border-b border-border p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => {
              stopSpeaking();
              navigate("/");
            }}
            className="p-2 hover:bg-white/5 rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-muted-foreground" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/10 rounded-2xl flex items-center justify-center text-primary border border-primary/20 shadow-[0_0_20px_rgba(168,85,247,0.1)] relative">
              <Cat className="w-6 h-6 fill-current" />
              {isSpeaking && (
                <motion.div
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ duration: 0.8, repeat: Infinity }}
                  className="absolute -bottom-1 -right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center"
                >
                  <Volume2 className="w-2.5 h-2.5 text-primary-foreground" />
                </motion.div>
              )}
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight leading-none italic">Chat with Luma</h1>
              <p className="text-[10px] text-primary font-bold uppercase tracking-widest leading-none mt-1 italic animate-pulse">
                {isSpeaking ? "Speaking..." : isListening ? "Listening..." : "Your Guardian Cat"}
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setVoiceEnabled(!voiceEnabled);
              if (voiceEnabled) stopSpeaking();
              toast.info(voiceEnabled ? "Luma's voice muted" : "Luma can speak again!");
            }}
            className={cn(
              "p-2 rounded-xl border transition-all active:scale-95",
              voiceEnabled 
                ? "bg-primary/10 border-primary/20 text-primary" 
                : "bg-muted border-border text-muted-foreground"
            )}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button 
            onClick={() => navigate("/therapists")}
            className="bg-primary/10 border border-primary/20 text-primary px-3 py-2 rounded-xl text-[9px] font-bold uppercase tracking-widest transition-all hover:bg-primary/20"
          >
            Human Specialist
          </button>
        </div>
      </header>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 flex flex-col gap-6 scroll-smooth"
      >
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex flex-col gap-2 max-w-[85%]",
                msg.role === "user" ? "self-end items-end" : "self-start items-start"
              )}
            >
              {msg.mentalState && (
                <div className="flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 px-3 py-1 rounded-full mb-1">
                  <Brain className="w-3 h-3 text-purple-400" />
                  <span className="text-[10px] font-bold text-purple-300 uppercase tracking-widest leading-none italic">Detected: {msg.mentalState}</span>
                </div>
              )}
              <div className={cn(
                "p-4 rounded-[1.5rem] text-sm font-medium leading-relaxed shadow-sm italic relative",
                msg.role === "user" 
                  ? "bg-primary text-primary-foreground rounded-tr-none" 
                  : "bg-card border border-border text-foreground rounded-tl-none pl-10"
              )}>
                {msg.role === "assistant" && (
                  <Cat className="absolute left-3 top-4 w-4 h-4 text-primary opacity-40" />
                )}
                {msg.content}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest opacity-40">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                {msg.role === "assistant" && voiceEnabled && (
                  <button
                    onClick={() => {
                      if (isSpeaking) {
                        stopSpeaking();
                      } else {
                        speakLuma(msg.content);
                      }
                    }}
                    className="text-primary/40 hover:text-primary transition-colors"
                  >
                    <Volume2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border p-4 rounded-3xl rounded-tl-none self-start flex gap-1.5"
            >
              <div className="w-1.5 h-1.5 bg-muted-foreground/30 rounded-full animate-bounce [animation-delay:-0.3s]" />
              <div className="w-1.5 h-1.5 bg-muted-foreground/30 rounded-full animate-bounce [animation-delay:-0.15s]" />
              <div className="w-1.5 h-1.5 bg-muted-foreground/30 rounded-full animate-bounce" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Voice input indicator */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="px-6 pb-2"
          >
            <div className="bg-primary/10 border border-primary/20 p-3 rounded-2xl flex items-center gap-3">
              <motion.div
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
                className="w-8 h-8 bg-primary rounded-full flex items-center justify-center"
              >
                <Mic className="w-4 h-4 text-primary-foreground" />
              </motion.div>
              <div className="flex-1">
                <p className="text-xs font-bold text-primary italic">Listening...</p>
                {transcript && (
                  <p className="text-[10px] text-muted-foreground italic mt-0.5">"{transcript}"</p>
                )}
              </div>
              <button
                onClick={stopListening}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Suggestion Chips */}
      <div className="px-6 pb-2 flex gap-2 overflow-x-auto no-scrollbar">
        {["I feel anxious", "I had a nightmare", "Can't fall asleep", "Exam stress"].map((tip) => (
          <button
            key={tip}
            onClick={() => setInput(tip)}
            className="whitespace-nowrap bg-card border border-border px-4 py-2 rounded-xl text-xs font-bold text-muted-foreground hover:text-primary hover:border-primary transition-all active:scale-95 italic"
          >
            {tip}
          </button>
        ))}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-card/40 border-t border-border backdrop-blur-md">
        <div className="relative flex items-center gap-2">
          {/* Mic Button */}
          <button
            onClick={() => {
              if (isListening) {
                stopListening();
              } else {
                startListening();
              }
            }}
            className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-all active:scale-95 shrink-0 border",
              isListening 
                ? "bg-primary text-primary-foreground border-primary animate-pulse" 
                : "bg-background border-border text-muted-foreground hover:text-primary hover:border-primary/30"
            )}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <div className="relative flex-1">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Talk to Luma..."
              className="w-full h-14 bg-background border border-border rounded-2xl pl-5 pr-14 py-4 text-sm font-medium text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all resize-none italic"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:scale-100"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex items-center justify-center gap-2 mt-3">
          <ShieldCheck className="w-3.5 h-3.5 text-muted-foreground/40" />
          <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest leading-none italic opacity-40">
            Luma is an AI, not a therapist. Crisis help: 988
          </p>
        </div>
      </div>
    </div>
  );
}
