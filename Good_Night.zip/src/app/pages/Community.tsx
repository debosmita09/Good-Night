import { useState, useEffect, useMemo } from "react";
import { Users, MessageSquare, Heart, ShieldCheck, Plus, Search, Filter, Info, ChevronRight, UserCircle, Zap, Sparkles, TrendingUp, Flame, Clock, Star } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";
import { toast } from "sonner";
import { getRecommendedInterests } from "../lib/sleep-logic";

interface Discussion {
  id: string;
  user: string;
  time: string;
  title: string;
  replies: number;
  likes: number;
  tags: string[];
  isLiked?: boolean;
  userPoints: number;
}

interface Group {
  id: string;
  name: string;
  members: number;
  description: string;
  tags: string[];
  activeUsers: number;
}

const groups: Group[] = [
  { id: "1", name: "Nightmare Survivors", members: 1240, description: "Safe space to discuss IRT techniques and recovery.", tags: ["Support", "Nightmares"], activeUsers: 45 },
  { id: "2", name: "The 8-Hour Club", members: 3500, description: "Accountability group for consistent sleep schedules.", tags: ["Productivity", "Consistent", "Sleep Optimization"], activeUsers: 120 },
  { id: "3", name: "Deep Sleep Seekers", members: 890, description: "Sharing tips on magnesium, blankets, and noise.", tags: ["Tips", "Biohacking", "Ambient Sound"], activeUsers: 12 },
  { id: "4", name: "Early Birds", members: 2100, description: "Waking up before 6 AM with shared morning routines.", tags: ["Routine", "AM"], activeUsers: 67 },
  { id: "5", name: "Zen Masters", members: 1540, description: "Breathing techniques and meditation for deep rest.", tags: ["Breathing Techniques", "Meditation", "Stress Management"], activeUsers: 32 }
];

const initialDiscussions: Discussion[] = [
  { 
    id: "d1",
    user: "SleepyDev_GSU",
    time: "2h ago",
    title: "Has anyone tried the 4-7-8 method for exam stress?",
    replies: 24,
    likes: 89,
    tags: ["Breathing Techniques", "Stress Management"],
    userPoints: 1250
  },
  { 
    id: "d2",
    user: "NightOwl99",
    time: "5h ago",
    title: "Best brown noise settings for masking street traffic?",
    replies: 12,
    likes: 45,
    tags: ["Ambient Sound", "Tips"],
    userPoints: 420
  },
  { 
    id: "d3",
    user: "Luma_Fan",
    time: "1d ago",
    title: "The Imagery Rehearsal Therapy actually worked for me last night!",
    replies: 56,
    likes: 230,
    tags: ["Nightmares", "Support"],
    userPoints: 2100
  },
  {
    id: "d4",
    user: "RestfulMind",
    time: "4h ago",
    title: "How to deal with late night anxiety without screen time?",
    replies: 31,
    likes: 112,
    tags: ["Stress Management", "Routine"],
    userPoints: 850
  }
];

export function Community() {
  const [activeTab, setActiveTab] = useState<"groups" | "discussions">("groups");
  const [search, setSearch] = useState("");
  const [discussions, setDiscussions] = useState<Discussion[]>(initialDiscussions);
  const [sortBy, setSortBy] = useState<"top" | "new">("top");

  const userInterests = useMemo(() => {
    // Dynamically generate interests based on recent journal sentiment & sleep data
    const mockJournal = "I had a terrible nightmare last night and feel very stressed about work.";
    const mockHealth = { hoursSlept: 5 };
    const interests = getRecommendedInterests(mockJournal, mockHealth);
    return interests.length > 0 ? interests : ["Sleep Optimization", "Stress Management", "Ambient Sound"];
  }, []);

  const sortedDiscussions = useMemo(() => {
    let list = [...discussions];
    if (sortBy === "top") {
      // Smart Upvoting Score: Likes have higher weight than replies
      list.sort((a, b) => {
        const scoreA = (a.likes * 2) + a.replies;
        const scoreB = (b.likes * 2) + b.replies;
        return scoreB - scoreA;
      });
    } else {
      list.sort((a, b) => b.id.localeCompare(a.id));
    }
    return list;
  }, [discussions, sortBy]);

  const recommendedDiscussions = useMemo(() => {
    return discussions.filter(d => 
      d.tags.some(tag => userInterests.includes(tag))
    ).slice(0, 2);
  }, [discussions, userInterests]);

  const handleJoin = (name: string) => {
    toast.success(`Requested to join ${name}`);
  };

  const handleLike = (id: string) => {
    setDiscussions(prev => prev.map(d => {
      if (d.id === id) {
        const isLiked = !d.isLiked;
        if (isLiked) toast.success("Upvoted & Liked!", { icon: "💖" });
        return {
          ...d,
          likes: isLiked ? d.likes + 1 : d.likes - 1,
          isLiked: isLiked
        };
      }
      return d;
    }));
  };

  return (
    <div className="flex flex-col gap-8 pb-32 px-1">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground tracking-tight leading-none italic uppercase tracking-widest">Support Groups</h1>
        <p className="text-muted-foreground font-medium text-sm uppercase tracking-widest leading-none mt-1 italic opacity-80">You're not alone in the night.</p>
      </header>

      {!search && (
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500 fill-current" />
              <h3 className="text-[10px] font-black uppercase tracking-widest italic text-foreground">For Your Wellness</h3>
            </div>
            <span className="text-[8px] text-muted-foreground font-bold uppercase tracking-widest italic">Matches your journal</span>
          </div>
          
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-1 px-1">
            {userInterests.slice(0, 2).map(interest => (
              <motion.div 
                key={interest} 
                whileHover={{ scale: 1.02 }}
                className="flex-shrink-0 bg-primary/10 border border-primary/20 px-6 py-4 rounded-[1.5rem] flex flex-col gap-1 min-w-[160px]"
              >
                <span className="text-[8px] font-black text-primary uppercase tracking-widest italic opacity-60">Insight Match</span>
                <span className="text-xs font-bold text-foreground italic">{interest}</span>
                <div className="flex items-center gap-1 mt-1 text-[8px] text-primary/80 font-bold uppercase tracking-widest italic">
                  <TrendingUp className="w-2.5 h-2.5" />
                  <span>Popular now</span>
                </div>
              </motion.div>
            ))}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="flex-shrink-0 bg-purple-500/5 border border-purple-500/20 px-6 py-4 rounded-[1.5rem] flex flex-col gap-1 min-w-[200px] border-dashed"
            >
              <span className="text-[8px] font-black text-purple-400 uppercase tracking-widest italic opacity-60">Top Group Match</span>
              <span className="text-xs font-bold text-foreground italic truncate">Nightmare Survivors</span>
              <button className="mt-2 text-[8px] font-black text-purple-400 uppercase tracking-widest italic flex items-center gap-1 hover:underline">
                Join Group <ChevronRight className="w-2 h-2" />
              </button>
            </motion.div>
          </div>
        </section>
      )}

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/40" />
        <input 
          type="text" 
          placeholder="Search topics, groups..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full h-14 bg-card border border-border rounded-2xl pl-12 pr-4 text-sm font-bold italic placeholder:text-muted-foreground/30 focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all"
        />
      </div>

      <div className="flex bg-card border border-border p-1.5 rounded-3xl">
        <button
          onClick={() => setActiveTab("groups")}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-xs",
            activeTab === "groups" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Users className="w-4 h-4" />
          Groups
        </button>
        <button
          onClick={() => setActiveTab("discussions")}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl transition-all font-bold tracking-tight leading-none italic uppercase tracking-widest text-xs",
            activeTab === "discussions" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
          )}
        >
          <MessageSquare className="w-4 h-4" />
          Discussions
        </button>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="flex flex-col gap-6"
        >
          {activeTab === "groups" ? (
            <div className="flex flex-col gap-4">
              {groups.filter(g => g.name.toLowerCase().includes(search.toLowerCase()) || g.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))).map((group) => (
                <motion.div 
                  key={group.id} 
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-card border border-border p-6 rounded-[2.5rem] flex flex-col gap-5 group transition-all hover:border-primary/20"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex flex-col gap-1">
                      <h3 className="text-xl font-bold tracking-tight leading-none italic">{group.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Users className="w-3.5 h-3.5 text-muted-foreground/60" />
                        <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest italic">{group.members} members</span>
                        <div className="w-1 h-1 bg-border rounded-full" />
                        <div className="flex items-center gap-1">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                          <span className="text-[10px] text-green-500 font-bold uppercase tracking-widest italic">{group.activeUsers} active now</span>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleJoin(group.name)}
                      className="bg-primary/10 text-primary px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest italic transition-all hover:bg-primary/20 active:scale-95"
                    >
                      Join
                    </button>
                  </div>

                  <p className="text-sm font-medium text-muted-foreground italic leading-relaxed">
                    {group.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {group.tags.map(tag => (
                      <span key={tag} className="bg-muted/50 px-3 py-1 rounded-full text-[9px] font-bold text-muted-foreground uppercase tracking-widest italic">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              <div className="flex items-center gap-2 px-1">
                <button 
                  onClick={() => setSortBy("top")}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest italic transition-all",
                    sortBy === "top" ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "bg-card text-muted-foreground border border-border"
                  )}
                >
                  <Flame className="w-3.5 h-3.5 fill-current" />
                  Top
                </button>
                <button 
                  onClick={() => setSortBy("new")}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest italic transition-all",
                    sortBy === "new" ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "bg-card text-muted-foreground border border-border"
                  )}
                >
                  <DiscussionClock className="w-3.5 h-3.5" />
                  New
                </button>
              </div>

              {recommendedDiscussions.length > 0 && !search && (
                <div className="flex flex-col gap-3">
                   <div className="flex items-center gap-2 px-1 mb-1">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span className="text-[10px] font-black uppercase tracking-widest italic text-muted-foreground">Pick for you</span>
                  </div>
                  {recommendedDiscussions.map(d => (
                    <DiscussionCard 
                      key={`rec-${d.id}`}
                      id={d.id}
                      user={d.user}
                      time={d.time}
                      title={d.title}
                      replies={d.replies}
                      likes={d.likes}
                      isLiked={d.isLiked}
                      userPoints={d.userPoints}
                      onLike={() => handleLike(d.id)}
                      featured
                    />
                  ))}
                </div>
              )}

              <div className="flex flex-col gap-4">
                {!search && (
                  <div className="flex items-center gap-2 px-1 mb-1">
                    <TrendingUp className="w-3 h-3 text-primary" />
                    <span className="text-[10px] font-black uppercase tracking-widest italic text-muted-foreground">Trending Stories</span>
                  </div>
                )}
                {sortedDiscussions
                  .filter(d => d.title.toLowerCase().includes(search.toLowerCase()) || d.tags.some(t => t.toLowerCase().includes(search.toLowerCase())))
                  .map((d) => (
                    <DiscussionCard 
                      key={d.id}
                      id={d.id}
                      user={d.user}
                      time={d.time}
                      title={d.title}
                      replies={d.replies}
                      likes={d.likes}
                      isLiked={d.isLiked}
                      userPoints={d.userPoints}
                      onLike={() => handleLike(d.id)}
                    />
                  ))
                }
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Leaderboard Section */}
      {!search && activeTab === "discussions" && (
        <section className="bg-primary/5 border border-primary/10 p-8 rounded-[3rem] flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" />
              <h3 className="text-sm font-black uppercase tracking-widest italic">Hall of Rest</h3>
            </div>
            <span className="text-[8px] font-bold uppercase tracking-widest text-primary italic">This Week's Top Sleepers</span>
          </div>
          
          <div className="flex flex-col gap-3">
            {[...initialDiscussions].sort((a,b) => b.userPoints - a.userPoints).slice(0, 3).map((u, i) => (
              <div key={u.user} className="flex items-center justify-between bg-card p-4 rounded-2xl border border-border">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-xs font-black",
                    i === 0 ? "bg-amber-400 text-amber-900 shadow-[0_0_15px_rgba(251,191,36,0.5)]" : 
                    i === 1 ? "bg-slate-300 text-slate-700" : "bg-orange-300 text-orange-800"
                  )}>
                    {i + 1}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold italic">{u.user}</span>
                    <span className="text-[8px] font-black text-primary uppercase tracking-tighter italic">
                      {u.userPoints > 2000 ? "Big Cat" : "Young Cat"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-amber-500">
                  <Star className="w-3 h-3 fill-current" />
                  <span className="text-xs font-black italic">{u.userPoints}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <button className="fixed bottom-28 right-6 w-16 h-16 bg-primary text-primary-foreground rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 z-50">
        <Plus className="w-8 h-8" />
      </button>
    </div>
  );
}

function Trophy(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
      <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
      <path d="M4 22h16" />
      <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
      <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
      <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z" />
    </svg>
  );
}

function DiscussionCard({ 
  id, 
  user, 
  time, 
  title, 
  replies, 
  likes, 
  isLiked, 
  onLike,
  userPoints,
  featured 
}: { 
  id: string; 
  user: string; 
  time: string; 
  title: string; 
  replies: number; 
  likes: number;
  isLiked?: boolean;
  onLike: () => void;
  userPoints: number;
  featured?: boolean;
}) {
  const level = userPoints > 2000 ? "Big Cat" : userPoints > 1000 ? "Young Cat" : "Kitten";
  
  return (
    <motion.div 
      layout
      className={cn(
        "bg-card border p-6 rounded-[2.5rem] flex flex-col gap-4 group cursor-pointer hover:bg-border/10 transition-all",
        featured ? "border-amber-500/30 bg-amber-500/5" : "border-border"
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center overflow-hidden border border-primary/20">
            <UserCircle className="w-5 h-5 text-muted-foreground/60" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold italic">{user}</span>
              <span className={cn(
                "text-[7px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-tighter",
                level === "Big Cat" ? "bg-primary text-primary-foreground" : 
                level === "Young Cat" ? "bg-amber-400 text-amber-900" : "bg-muted text-muted-foreground"
              )}>
                {level}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold italic">{time}</span>
              <div className="w-1 h-1 bg-border rounded-full" />
              <div className="flex items-center gap-0.5 text-amber-500">
                <Star className="w-2 h-2 fill-current" />
                <span className="text-[9px] font-black">{userPoints} pts</span>
              </div>
            </div>
          </div>
        </div>
        {featured && (
          <div className="bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest italic flex items-center gap-1">
            <Flame className="w-2.5 h-2.5 fill-current" />
            Hot Topic
          </div>
        )}
      </div>
      
      <h3 className="text-base font-bold tracking-tight leading-relaxed italic">{title}</h3>
      
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-4">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onLike();
            }}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all active:scale-90",
              isLiked ? "bg-rose-500/20 text-rose-500" : "hover:bg-muted"
            )}
          >
            <Heart className={cn("w-3.5 h-3.5", isLiked && "fill-current")} />
            <span className="text-[10px] font-bold">{likes}</span>
          </button>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full hover:bg-muted transition-colors">
            <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-[10px] font-bold text-muted-foreground">{replies}</span>
          </div>
        </div>
        
        <button className="text-muted-foreground/40 hover:text-primary transition-colors">
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
}

function DiscussionClock(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
