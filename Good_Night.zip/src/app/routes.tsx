import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { WindDown } from "./pages/WindDown";
import { Nightmare } from "./pages/Nightmare";
import { Insights } from "./pages/Insights";
import { Journal } from "./pages/Journal";
import { HealthProfile } from "./pages/HealthProfile";
import { Library } from "./pages/Library";
import { Therapists } from "./pages/Therapists";
import { Chatbot } from "./pages/Chatbot";
import { KidsMode } from "./pages/KidsMode";
import { Community } from "./pages/Community";
import { Settings } from "./pages/Settings";
import { Notifications } from "./pages/Notifications";
import { SnuggleStretch } from "./pages/SnuggleStretch";
import { Breathing } from "./pages/Breathing";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: "wind-down", element: <WindDown /> },
      { path: "insights", element: <Insights /> },
      { path: "journal", element: <Journal /> },
      { path: "health-profile", element: <HealthProfile /> },
      { path: "library", element: <Library /> },
      { path: "therapists", element: <Therapists /> },
      { path: "community", element: <Community /> },
      { path: "settings", element: <Settings /> },
      { path: "notifications", element: <Notifications /> },
      { path: "snuggle-stretch", element: <SnuggleStretch /> },
      { path: "body-scan", element: <SnuggleStretch /> },
      { path: "breathing", element: <Breathing /> },
    ],
  },
  {
    path: "/nightmare",
    element: <Nightmare />,
  },
  {
    path: "/chatbot",
    element: <Chatbot />,
  },
  {
    path: "/kids-mode",
    element: <KidsMode />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);
