import React, { createContext, useContext } from "react";

interface RewardContextType {
  points: number;
  addPoints: (amount: number, reason: string) => void;
  processJournalEntry: (text: string) => void;
  showCelebration: boolean;
  setShowCelebration: (show: boolean) => void;
  completedRituals: string[];
  completeRitual: (id: string) => void;
  lumaLevel: "kitten" | "young" | "big";
  isTalkUnlocked: boolean;
}

export const RewardContext = createContext<RewardContextType | undefined>(undefined);

export const useRewards = () => {
  const context = useContext(RewardContext);
  if (!context) {
    throw new Error("useRewards must be used within a RewardProvider");
  }
  return context;
};
