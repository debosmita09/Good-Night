import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  Eye,
  Mic,
  Bell,
  Heart,
  MapPin,
  Activity,
  ChevronRight,
  Moon,
  User,
  Target,
  Sparkles,
  Star,
  Clock,
} from "lucide-react";

// Luma sleeping SVG logo with star background (compact version for setup)
function LumaLogo({ size = 80 }: { size?: number }) {
  return (
    <svg viewBox="0 0 200 200" width={size} height={size} className="drop-shadow-2xl">
      <defs>
        <radialGradient id="lumaGlowSetup" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#A78BFA" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#0F1220" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="starGlowSetup" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FBBF24" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#FBBF24" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="100" cy="100" r="95" fill="url(#lumaGlowSetup)" />
      <g transform="translate(145, 35)">
        <circle cx="0" cy="0" r="20" fill="url(#starGlowSetup)" />
        <polygon
          points="0,-15 4,-5 15,-5 6,2 9,13 0,7 -9,13 -6,2 -15,-5 -4,-5"
          fill="#FBBF24"
          opacity="0.9"
        >
          <animateTransform attributeName="transform" type="rotate" values="0;10;0;-10;0" dur="4s" repeatCount="indefinite" />
        </polygon>
      </g>
      <circle cx="40" cy="45" r="2" fill="#FBBF24" opacity="0.4">
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="3s" repeatCount="indefinite" />
      </circle>
      <circle cx="160" cy="75" r="1.5" fill="#FBBF24" opacity="0.3">
        <animate attributeName="opacity" values="0.3;0.7;0.3" dur="2.5s" repeatCount="indefinite" />
      </circle>
      <ellipse cx="100" cy="120" rx="55" ry="40" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" opacity="0.9" />
      <circle cx="75" cy="95" r="30" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      <polygon points="52,75 60,50 72,72" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      <polygon points="52,75 60,50 72,72" fill="#A78BFA" opacity="0.15" />
      <polygon points="88,72 80,50 68,75" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1.5" />
      <polygon points="88,72 80,50 68,75" fill="#A78BFA" opacity="0.15" />
      <path d="M62,92 Q67,88 72,92" fill="none" stroke="#A78BFA" strokeWidth="2" strokeLinecap="round" />
      <path d="M78,92 Q83,88 88,92" fill="none" stroke="#A78BFA" strokeWidth="2" strokeLinecap="round" />
      <ellipse cx="75" cy="98" rx="2.5" ry="2" fill="#F9A8D4" />
      <path d="M72,102 Q75,105 78,102" fill="none" stroke="#A78BFA" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
      <path d="M150,110 Q170,95 160,80 Q155,70 148,78" fill="none" stroke="#A78BFA" strokeWidth="4" strokeLinecap="round" opacity="0.7" />
      <ellipse cx="60" cy="125" rx="8" ry="5" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1" opacity="0.8" />
      <ellipse cx="90" cy="128" rx="8" ry="5" fill="#1A1E33" stroke="#A78BFA" strokeWidth="1" opacity="0.8" />
      <text x="100" y="68" fill="#A78BFA" opacity="0.5" fontSize="12" fontWeight="bold" fontStyle="italic">
        z
        <animate attributeName="opacity" values="0.2;0.6;0.2" dur="2s" repeatCount="indefinite" />
        <animateTransform attributeName="transform" type="translate" values="0,0;5,-8;10,-16" dur="3s" repeatCount="indefinite" />
      </text>
      <text x="112" y="58" fill="#A78BFA" opacity="0.4" fontSize="16" fontWeight="bold" fontStyle="italic">
        z
        <animate attributeName="opacity" values="0.1;0.5;0.1" dur="2.5s" repeatCount="indefinite" />
        <animateTransform attributeName="transform" type="translate" values="0,0;5,-10;10,-20" dur="3.5s" repeatCount="indefinite" />
      </text>
    </svg>
  );
}

function PermissionItem({
  icon,
  title,
  desc,
  enabled,
  onToggle,
  color,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  enabled: boolean;
  onToggle: () => void;
  color: string;
}) {
  return (
    <button
      onClick={onToggle}
      className={`p-4 rounded-2xl border flex items-center gap-4 transition-all active:scale-98 text-left group ${
        enabled ? "border-primary/30 bg-primary/5" : "border-border hover:border-border/60"
      }`}
    >
      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
          enabled ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
        } ${color}`}
      >
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <span className="text-sm font-bold tracking-tight italic block">{title}</span>
        <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest italic mt-0.5 block opacity-60">
          {desc}
        </span>
      </div>
      <div
        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
          enabled ? "border-primary bg-primary" : "border-border"
        }`}
      >
        {enabled && <div className="w-2 h-2 bg-white rounded-full" />}
      </div>
    </button>
  );
}

const sleepGoals = [
  { id: "fall-asleep", label: "Fall asleep faster", icon: <Moon className="w-5 h-5" /> },
  { id: "stay-asleep", label: "Stay asleep longer", icon: <Clock className="w-5 h-5" /> },
  { id: "nightmares", label: "Reduce nightmares", icon: <Star className="w-5 h-5" /> },
  { id: "routine", label: "Build a sleep routine", icon: <Target className="w-5 h-5" /> },
  { id: "screen-time", label: "Reduce screen time", icon: <Eye className="w-5 h-5" /> },
  { id: "relaxation", label: "Learn to relax", icon: <Sparkles className="w-5 h-5" /> },
];

export function AccountSetup({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState("");
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [permissions, setPermissions] = useState({
    tracking: false,
    health: false,
    microphone: false,
    notifications: false,
    location: false,
  });

  const toggleGoal = (id: string) => {
    setSelectedGoals((prev) =>
      prev.includes(id) ? prev.filter((g) => g !== id) : [...prev, id]
    );
  };

  const steps = [
    {
      title: "Welcome to Good Night",
      subtitle: "Let's set up your sleep sanctuary",
      content: (
        <div className="flex flex-col gap-6">
          <div className="flex justify-center">
            <LumaLogo size={100} />
          </div>
          <div className="bg-primary/10 border border-primary/20 p-5 rounded-2xl flex items-start gap-4">
            <Sparkles className="w-6 h-6 text-primary shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold italic text-foreground">Meet Luma, your Sleep Buddy!</p>
              <p className="text-xs text-muted-foreground italic mt-1 leading-relaxed">
                Luma grows as you build healthy sleep habits. Take good care of yourself and watch Luma thrive!
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">
              What should we call you?
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Your display name..."
              className="h-14 bg-card border border-border rounded-2xl px-5 text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all text-sm"
            />
          </div>
        </div>
      ),
    },
    {
      title: "Your Sleep Goals",
      subtitle: "Select what matters most to you",
      content: (
        <div className="flex flex-col gap-3">
          {sleepGoals.map((goal) => (
            <button
              key={goal.id}
              onClick={() => toggleGoal(goal.id)}
              className={`p-4 rounded-2xl border flex items-center gap-4 transition-all active:scale-98 text-left ${
                selectedGoals.includes(goal.id)
                  ? "border-primary/30 bg-primary/5"
                  : "border-border hover:border-border/60"
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  selectedGoals.includes(goal.id)
                    ? "bg-primary/20 text-primary"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {goal.icon}
              </div>
              <span className="text-sm font-bold tracking-tight italic flex-1">{goal.label}</span>
              <div
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                  selectedGoals.includes(goal.id) ? "border-primary bg-primary" : "border-border"
                }`}
              >
                {selectedGoals.includes(goal.id) && (
                  <div className="w-2 h-2 bg-white rounded-full" />
                )}
              </div>
            </button>
          ))}
        </div>
      ),
    },
    {
      title: "Your Privacy Matters",
      subtitle: "Before we begin, let's talk about your data",
      content: (
        <div className="flex flex-col gap-4">
          <div className="bg-primary/10 border border-primary/20 p-5 rounded-2xl flex items-start gap-4">
            <ShieldCheck className="w-6 h-6 text-primary shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold italic text-foreground">
                We believe in transparent data practices.
              </p>
              <p className="text-xs text-muted-foreground italic mt-1 leading-relaxed">
                Nightlight never sells your data. Your sleep logs, health info, and conversations
                with Luma stay on your device unless you choose to sync.
              </p>
            </div>
          </div>
          <div className="bg-amber-500/10 border border-amber-500/20 p-5 rounded-2xl flex items-start gap-4">
            <Eye className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold italic text-foreground">Ask App Not to Track</p>
              <p className="text-xs text-muted-foreground italic mt-1 leading-relaxed">
                We do not track your activity across other apps or websites. Your sleep journey is
                yours alone.
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-3 mt-2">
            <button
              onClick={() => setPermissions((p) => ({ ...p, tracking: false }))}
              className={`p-4 rounded-2xl border-2 flex items-start gap-4 transition-all active:scale-98 text-left ${
                !permissions.tracking ? "border-primary bg-primary/10" : "border-border"
              }`}
            >
              <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center text-primary shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold italic text-foreground">Ask App Not to Track</p>
                <p className="text-[10px] text-muted-foreground italic mt-1 uppercase tracking-widest">
                  Recommended for privacy
                </p>
              </div>
            </button>
            <button
              onClick={() => setPermissions((p) => ({ ...p, tracking: true }))}
              className={`p-4 rounded-2xl border-2 flex items-start gap-4 transition-all active:scale-98 text-left ${
                permissions.tracking ? "border-primary bg-primary/10" : "border-border"
              }`}
            >
              <div className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center text-muted-foreground shrink-0">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold italic text-foreground">Allow Tracking</p>
                <p className="text-[10px] text-muted-foreground italic mt-1 uppercase tracking-widest">
                  Personalized experience features
                </p>
              </div>
            </button>
          </div>
        </div>
      ),
    },
    {
      title: "App Permissions",
      subtitle: "Choose what Nightlight can access",
      content: (
        <div className="flex flex-col gap-3">
          <PermissionItem
            icon={<Activity className="w-5 h-5" />}
            title="Health Data (iPhone Health)"
            desc="Sync sleep, heart rate & activity data"
            enabled={permissions.health}
            onToggle={() => setPermissions((p) => ({ ...p, health: !p.health }))}
            color="text-red-400"
          />
          <PermissionItem
            icon={<Mic className="w-5 h-5" />}
            title="Microphone Access"
            desc="For sleep talking detection & Luma voice chat"
            enabled={permissions.microphone}
            onToggle={() => setPermissions((p) => ({ ...p, microphone: !p.microphone }))}
            color="text-blue-400"
          />
          <PermissionItem
            icon={<Bell className="w-5 h-5" />}
            title="Notifications"
            desc="Medication & sleep reminders"
            enabled={permissions.notifications}
            onToggle={() => setPermissions((p) => ({ ...p, notifications: !p.notifications }))}
            color="text-amber-400"
          />
          <PermissionItem
            icon={<MapPin className="w-5 h-5" />}
            title="Location (Optional)"
            desc="For sunrise/sunset-based scheduling"
            enabled={permissions.location}
            onToggle={() => setPermissions((p) => ({ ...p, location: !p.location }))}
            color="text-green-400"
          />

          <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-2xl flex items-start gap-3 mt-2">
            <Heart className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground italic leading-relaxed">
              You can change these permissions anytime in Settings. Nightlight is designed to be a
              safe space for your wellness journey.
            </p>
          </div>
        </div>
      ),
    },
    {
      title: "You're All Set!",
      subtitle: "Your sleep sanctuary is ready",
      content: (
        <div className="flex flex-col items-center gap-6 py-4">
          <LumaLogo size={120} />
          <div className="flex flex-col items-center gap-2 text-center">
            <p className="text-sm font-bold italic text-foreground">
              Welcome{displayName ? `, ${displayName}` : ""}!
            </p>
            <p className="text-xs text-muted-foreground italic leading-relaxed max-w-[280px]">
              Luma is ready to help you sleep better. Start logging your sleep, explore calming
              routines, and watch your sleep buddy grow!
            </p>
          </div>

          {selectedGoals.length > 0 && (
            <div className="w-full bg-primary/5 border border-primary/10 p-4 rounded-2xl">
              <p className="text-[10px] font-bold text-primary uppercase tracking-widest italic mb-3">
                Your Goals
              </p>
              <div className="flex flex-wrap gap-2">
                {selectedGoals.map((goalId) => {
                  const goal = sleepGoals.find((g) => g.id === goalId);
                  return (
                    <span
                      key={goalId}
                      className="px-3 py-1.5 bg-primary/10 border border-primary/20 rounded-xl text-[10px] font-bold text-primary italic"
                    >
                      {goal?.label}
                    </span>
                  );
                })}
              </div>
            </div>
          )}

          <div className="w-full bg-card border border-border p-4 rounded-2xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <p className="text-[10px] text-muted-foreground italic leading-relaxed">
              Your privacy settings are saved. You can review or change them anytime in{" "}
              <span className="text-foreground font-bold">Settings &gt; Account &amp; Data</span>.
            </p>
          </div>
        </div>
      ),
    },
  ];

  const currentStep = steps[step];
  const isLastStep = step === steps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      // Save all setup data to localStorage
      localStorage.setItem("nightlight_onboarded", "true");
      localStorage.setItem("nightlight_permissions", JSON.stringify(permissions));
      if (displayName) {
        localStorage.setItem("nightlight_display_name", displayName);
      }
      if (selectedGoals.length > 0) {
        localStorage.setItem("nightlight_sleep_goals", JSON.stringify(selectedGoals));
      }
      onComplete();
    } else {
      setStep((s) => s + 1);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[400] bg-background flex flex-col"
    >
      {/* Subtle star field background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.4, 0] }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
          />
        ))}
      </div>

      <div className="flex-1 w-full max-w-md mx-auto px-6 py-8 flex flex-col relative z-10 overflow-y-auto">
        {/* Progress */}
        <div className="flex gap-2 mb-6 shrink-0">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`flex-1 h-1.5 rounded-full transition-all duration-300 ${
                i <= step ? "bg-primary" : "bg-border"
              }`}
            />
          ))}
        </div>

        {/* Step indicator */}
        <div className="flex items-center justify-between mb-4 shrink-0">
          <span className="text-[9px] font-bold text-muted-foreground/50 uppercase tracking-widest italic">
            Step {step + 1} of {steps.length}
          </span>
          {step > 0 && step < steps.length - 1 && (
            <button
              onClick={handleNext}
              className="text-[9px] font-bold text-muted-foreground/50 uppercase tracking-widest italic hover:text-muted-foreground transition-colors"
            >
              Skip
            </button>
          )}
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col gap-5"
          >
            <div className="flex flex-col gap-1 shrink-0">
              <h2 className="text-2xl font-black italic uppercase tracking-widest text-foreground">
                {currentStep.title}
              </h2>
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-widest italic mt-1">
                {currentStep.subtitle}
              </p>
            </div>
            {currentStep.content}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex gap-3 mt-6 pt-4 border-t border-border/30 shrink-0">
          {step > 0 && (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="flex-1 h-14 bg-card border border-border text-foreground font-black italic uppercase tracking-widest rounded-2xl transition-all active:scale-95 text-sm"
            >
              Back
            </button>
          )}
          <button
            onClick={handleNext}
            className="flex-1 h-14 bg-primary text-primary-foreground font-black italic uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg text-sm"
          >
            {isLastStep ? "Let's Go!" : "Continue"}
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
