
  # Good_Night

  This is a code bundle for Good_Night. The original project is available at https://www.figma.com/design/Eryg5d3ICSw7CVUV5DBBEa/Good_Night.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  